-- TPC-H Table Analysis Script
-- Analyzes tables and updates statistics for optimal query performance

{% if system_kind == 'exasol' %}
-- Analyze database to estimate statistics for query optimization
ANALYZE DATABASE ESTIMATE STATISTICS;
COMMIT;
{% elif system_kind == 'clickhouse' %}
-- ClickHouse Statistics and Optimization
-- Statistics help the query optimizer make better join order decisions
-- Note: Statistics features are enabled globally in user profile (ClickHouse 24.6+)

-- Add statistics for join optimization (most critical columns)

-- Lineitem: Most critical table for complex queries
ALTER TABLE {{ schema }}.lineitem ADD STATISTICS IF NOT EXISTS l_orderkey TYPE count_min, tdigest, uniq;
ALTER TABLE {{ schema }}.lineitem ADD STATISTICS IF NOT EXISTS l_partkey TYPE count_min, tdigest, uniq;
ALTER TABLE {{ schema }}.lineitem ADD STATISTICS IF NOT EXISTS l_suppkey TYPE count_min, tdigest, uniq;
ALTER TABLE {{ schema }}.lineitem ADD STATISTICS IF NOT EXISTS l_quantity TYPE count_min, tdigest;
ALTER TABLE {{ schema }}.lineitem ADD STATISTICS IF NOT EXISTS l_receiptdate TYPE count_min;
ALTER TABLE {{ schema }}.lineitem ADD STATISTICS IF NOT EXISTS l_commitdate TYPE count_min;

-- Orders: Critical for joins
ALTER TABLE {{ schema }}.orders ADD STATISTICS IF NOT EXISTS o_orderkey TYPE count_min, tdigest, uniq;
ALTER TABLE {{ schema }}.orders ADD STATISTICS IF NOT EXISTS o_custkey TYPE count_min, tdigest, uniq;
ALTER TABLE {{ schema }}.orders ADD STATISTICS IF NOT EXISTS o_orderdate TYPE count_min, tdigest;
ALTER TABLE {{ schema }}.orders ADD STATISTICS IF NOT EXISTS o_orderstatus TYPE count_min, uniq;

-- Part: Used in filtered joins
ALTER TABLE {{ schema }}.part ADD STATISTICS IF NOT EXISTS p_partkey TYPE count_min, tdigest, uniq;
ALTER TABLE {{ schema }}.part ADD STATISTICS IF NOT EXISTS p_type TYPE count_min, uniq;
ALTER TABLE {{ schema }}.part ADD STATISTICS IF NOT EXISTS p_brand TYPE count_min, uniq;
ALTER TABLE {{ schema }}.part ADD STATISTICS IF NOT EXISTS p_container TYPE count_min, uniq;

-- Supplier: Join and filter columns
ALTER TABLE {{ schema }}.supplier ADD STATISTICS IF NOT EXISTS s_suppkey TYPE count_min, tdigest, uniq;
ALTER TABLE {{ schema }}.supplier ADD STATISTICS IF NOT EXISTS s_nationkey TYPE count_min, tdigest, uniq;

-- Customer: Join columns
ALTER TABLE {{ schema }}.customer ADD STATISTICS IF NOT EXISTS c_custkey TYPE count_min, tdigest, uniq;
ALTER TABLE {{ schema }}.customer ADD STATISTICS IF NOT EXISTS c_nationkey TYPE count_min, tdigest, uniq;
ALTER TABLE {{ schema }}.customer ADD STATISTICS IF NOT EXISTS c_mktsegment TYPE count_min, uniq;

-- Partsupp: Join columns
ALTER TABLE {{ schema }}.partsupp ADD STATISTICS IF NOT EXISTS ps_partkey TYPE count_min, tdigest, uniq;
ALTER TABLE {{ schema }}.partsupp ADD STATISTICS IF NOT EXISTS ps_suppkey TYPE count_min, tdigest, uniq;

-- Nation: Small table but frequently joined
ALTER TABLE {{ schema }}.nation ADD STATISTICS IF NOT EXISTS n_nationkey TYPE count_min, tdigest, uniq;
ALTER TABLE {{ schema }}.nation ADD STATISTICS IF NOT EXISTS n_name TYPE count_min, uniq;
ALTER TABLE {{ schema }}.nation ADD STATISTICS IF NOT EXISTS n_regionkey TYPE count_min, tdigest, uniq;

-- Region: Small table
ALTER TABLE {{ schema }}.region ADD STATISTICS IF NOT EXISTS r_regionkey TYPE count_min, tdigest, uniq;
ALTER TABLE {{ schema }}.region ADD STATISTICS IF NOT EXISTS r_name TYPE count_min, uniq;

-- Materialize statistics
ALTER TABLE {{ schema }}.lineitem MATERIALIZE STATISTICS l_orderkey, l_partkey, l_suppkey, l_quantity, l_receiptdate, l_commitdate;
ALTER TABLE {{ schema }}.orders MATERIALIZE STATISTICS o_orderkey, o_custkey, o_orderdate, o_orderstatus;
ALTER TABLE {{ schema }}.part MATERIALIZE STATISTICS p_partkey, p_type, p_brand, p_container;
ALTER TABLE {{ schema }}.supplier MATERIALIZE STATISTICS s_suppkey, s_nationkey;
ALTER TABLE {{ schema }}.customer MATERIALIZE STATISTICS c_custkey, c_nationkey, c_mktsegment;
ALTER TABLE {{ schema }}.partsupp MATERIALIZE STATISTICS ps_partkey, ps_suppkey;
ALTER TABLE {{ schema }}.nation MATERIALIZE STATISTICS n_nationkey, n_name, n_regionkey;
ALTER TABLE {{ schema }}.region MATERIALIZE STATISTICS r_regionkey, r_name;

-- Optimize tables to merge data parts and materialize skip indexes
OPTIMIZE TABLE {{ schema }}.nation FINAL;
OPTIMIZE TABLE {{ schema }}.region FINAL;
OPTIMIZE TABLE {{ schema }}.part FINAL;
OPTIMIZE TABLE {{ schema }}.supplier FINAL;
OPTIMIZE TABLE {{ schema }}.partsupp FINAL;
OPTIMIZE TABLE {{ schema }}.customer FINAL;
OPTIMIZE TABLE {{ schema }}.orders FINAL;
OPTIMIZE TABLE {{ schema }}.lineitem FINAL;

SELECT 'ClickHouse statistics collected and tables optimized';
{% else %}
{{ UNSUPPORTED_SYSTEM_KIND_ERROR_FOR[system_kind] }}
{% endif %}
