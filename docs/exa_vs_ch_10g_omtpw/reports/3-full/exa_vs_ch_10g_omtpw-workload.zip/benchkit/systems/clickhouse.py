"""ClickHouse database system implementation."""

from pathlib import Path
from typing import Any, cast

import clickhouse_connect

from ..util import Timer
from .base import SystemUnderTest


class ClickHouseSystem(SystemUnderTest):
    """ClickHouse database system implementation."""

    @classmethod
    def get_python_dependencies(cls) -> list[str]:
        """Return Python packages required by ClickHouse system."""
        return ["clickhouse-connect>=0.6.0"]

    @classmethod
    def extract_workload_connection_info(
        cls, setup_config: dict[str, Any], for_local_execution: bool = False
    ) -> dict[str, Any]:
        """
        Extract ClickHouse connection info with proper defaults.

        Args:
            setup_config: The setup section from system config
            for_local_execution: If True, use localhost (for packages running on DB machine).
                                If False, preserve configured host with env var resolution (for remote execution).
        """
        import os

        def resolve_env_var(value: str) -> str:
            """Resolve environment variable placeholders like $VAR_NAME."""
            if isinstance(value, str) and value.startswith("$"):
                var_name = value[1:]
                return os.environ.get(var_name, value)
            return value

        if for_local_execution:
            host = "localhost"
        else:
            host = resolve_env_var(setup_config.get("host", "localhost"))
        connection_info = {
            "host": host,
            "port": setup_config.get("port", 8123),
            "username": setup_config.get("username", "default"),
            "password": setup_config.get("password", ""),
            "database": setup_config.get("database", "benchmark"),
        }
        if setup_config.get("use_additional_disk", False):
            connection_info["use_additional_disk"] = True
        return connection_info

    @classmethod
    def get_required_ports(cls) -> dict[str, int]:
        """Return ports required by ClickHouse system."""
        return {
            "ClickHouse HTTP": 8123,
            "ClickHouse Native": 9000,
            "ClickHouse MySQL": 9004,
            "ClickHouse PostgreSQL": 9005,
        }

    def get_connection_string(self, public_ip: str, private_ip: str) -> str:
        """Get ClickHouse connection string with full CLI command."""
        port = self.setup_config.get("port", 8123)
        username = self.setup_config.get("username", "default")
        database = self.setup_config.get("database", "benchmark")
        password = self.setup_config.get("password", "")
        if port == 8123:
            cmd = f"clickhouse-client --host {public_ip} --port 9000 --user {username}"
        else:
            cmd = (
                f"clickhouse-client --host {public_ip} --port {port} --user {username}"
            )
        if database and database != "default":
            cmd += f" --database {database}"
        if password:
            cmd += " --password"
        return cmd

    def __init__(self, config: dict[str, Any]):
        super().__init__(config)
        self.setup_method = self.setup_config.get("method", "docker")
        self.container_name = f"clickhouse_{self.name}"
        self.config_profile = self.setup_config.get("extra", {}).get(
            "config_profile", "default"
        )
        self.http_port = 8123
        self.native_port = 9000
        raw_host = self.setup_config.get("host", "localhost")
        self.host = self._resolve_ip_addresses(raw_host)
        self.port = self.setup_config.get("port", 8123)
        self.username = self.setup_config.get("username", "default")
        self.password = self.setup_config.get("password", "")
        self.database = self.setup_config.get("database", "benchmark")
        self._client = None
        self._cloud_instance_manager: Any = None
        self._external_host: str | None = None

    def _get_client(self) -> Any:
        """Get a client connection to ClickHouse database using clickhouse-connect."""
        if clickhouse_connect is None:
            return None
        return clickhouse_connect.get_client(
            host=self.host,
            port=self.port,
            username=self.username,
            password=self.password,
            database=self.database,
            interface="http",
            secure=False,
        )

    def get_data_generation_directory(self, workload: Any) -> Path | None:
        """
        Get directory for TPC-H data generation on additional disk.

        Returns:
            Path to data generation directory on additional disk, or None for default
        """
        use_additional_disk = self.setup_config.get("use_additional_disk", False)
        if use_additional_disk:
            tpch_gen_dir = "/data/tpch_gen"
            self.execute_command(
                f"sudo mkdir -p {tpch_gen_dir} && sudo chown -R $(whoami):$(whoami) {tpch_gen_dir}",
                record=False,
            )
            data_gen_dir = (
                Path(tpch_gen_dir) / workload.name / f"sf{workload.scale_factor}"
            )
            print(
                f"ClickHouse: Using additional disk for data generation: {data_gen_dir}"
            )
            return cast(Path, data_gen_dir)
        return None

    def set_cloud_instance_manager(self, instance_manager: Any) -> None:
        """Set cloud instance manager for remote execution."""
        self._cloud_instance_manager = instance_manager
        if instance_manager and hasattr(instance_manager, "public_ip"):
            self._external_host = instance_manager.public_ip
            self.host = "localhost"
            password = self.setup_config.get("password")
            if password is not None:
                self.password = password

    def execute_command(
        self,
        command: str,
        timeout: float | None = None,
        record: bool = True,
        category: str = "setup",
    ) -> dict[str, Any]:
        """Execute command with remote execution support if cloud instance manager is available."""
        if self._cloud_instance_manager and self.setup_method == "native":
            result = self._cloud_instance_manager.run_remote_command(
                command, timeout=int(timeout) if timeout else 300
            )
            if record:
                self.setup_commands.append(
                    {
                        "command": self._sanitize_command_for_report(command),
                        "success": result.get("success", False),
                        "description": f"Execute {command.split()[0]} command on remote system",
                        "category": category,
                    }
                )
            return dict(result)
        else:
            return super().execute_command(command, timeout, record, category)

    def _resolve_ip_addresses(self, ip_config: str) -> str:
        """Resolve IP address placeholders with actual values from infrastructure."""
        if not ip_config:
            return "localhost"
        if ip_config.startswith("$"):
            from benchkit.infra.manager import InfraManager

            env_var = ip_config[1:]
            resolved = InfraManager.resolve_ip_from_infrastructure(env_var, self.name)
            if resolved:
                return resolved
            else:
                return ip_config
        return ip_config

    def _verify_preinstalled(self) -> bool:
        """Verify that ClickHouse is already installed and accessible."""
        return self.is_healthy()

    def start(self) -> bool:
        """Start the ClickHouse system."""
        if self.setup_method == "docker":
            result = self.execute_command(f"docker start {self.container_name}")
            if result["success"]:
                return self.wait_for_health()
            return False
        else:
            result = self.execute_command("sudo systemctl start clickhouse-server")
            return bool(result.get("success", False)) and self.wait_for_health()

    def is_healthy(self, quiet: bool = False) -> bool:
        """Check if ClickHouse is running and accepting connections."""
        try:
            health_check_host = getattr(self, "_external_host", None)
            if not health_check_host and self._cloud_instance_manager:
                health_check_host = getattr(
                    self._cloud_instance_manager, "public_ip", None
                )
            if not health_check_host:
                health_check_host = self.host
            if clickhouse_connect is None:
                print(
                    "Warning: clickhouse-connect not available, falling back to curl/client"
                )
                if self.setup_method == "docker":
                    result = self.execute_command(
                        f"curl -s http://localhost:{self.http_port}/ --max-time 5",
                        timeout=10.0,
                    )
                    return (
                        bool(result.get("success", False)) and "Ok." in result["stdout"]
                    )
                else:
                    result = self.execute_command(
                        f"clickhouse-client --user={self.username} --password={self.password} --query 'SELECT 1' --format TSV",
                        timeout=10.0,
                    )
                    return (
                        bool(result.get("success", False)) and "1" in result["stdout"]
                    )
            client = clickhouse_connect.get_client(
                host=health_check_host,
                port=self.port,
                username=self.username,
                password=self.password,
                database="default",
                interface="http",
                secure=False,
            )
            result = client.query("SELECT 1")
            client.close()
            return True
        except Exception as e:
            if not quiet:
                import traceback

                print(f"Health check failed: {type(e).__name__}: {e}")
                print(f"Full traceback:\n{traceback.format_exc()}")
            return False

    def create_schema(self, schema_name: str) -> bool:
        """Create a database in ClickHouse."""
        original_database = self.database
        self.database = "default"
        try:
            sql = f"CREATE DATABASE IF NOT EXISTS {schema_name}"
            result = self.execute_query(
                sql, query_name=f"create_database_{schema_name}"
            )
            success = bool(result.get("success", False))
            if success:
                self.database = schema_name
                print(f"✓ Using database: {schema_name}")
            else:
                error = result.get("error", "Unknown error")
                print(f"✗ Failed to create database '{schema_name}': {error}")
        except Exception as e:
            self.database = original_database
            print(f"✗ Failed to create database '{schema_name}': {e}")
            return False
        return success

    def load_data(self, table_name: str, data_path: Path, **kwargs: Any) -> bool:
        """Load data into ClickHouse table using native clickhouse-client for optimal performance."""
        schema_name = kwargs.get("schema", "default")
        try:
            print(f"Loading {data_path} into {table_name}...")
            import_cmd = f"""sed 's/|$//' {data_path} | clickhouse-client --user={self.username} --password={self.password} --query="INSERT INTO {schema_name}.{table_name} FORMAT CSV" --format_csv_delimiter='|'"""
            result = self.execute_command(import_cmd, timeout=3600.0, record=False)
            if not result.get("success", False):
                print(f"Failed to load data: {result.get('stderr', 'Unknown error')}")
                return False
            if clickhouse_connect is None:
                count_cmd = f'clickhouse-client --user={self.username} --password={self.password} --query="SELECT COUNT(*) FROM {schema_name}.{table_name} FORMAT TSV"'
                count_result = self.execute_command(
                    count_cmd, timeout=60.0, record=False
                )
                if count_result.get("success", False):
                    row_count = int(count_result.get("stdout", "0").strip())
                else:
                    print("Warning: Could not verify row count")
                    return True
            else:
                client = self._get_client()
                if client:
                    count_result = client.query(
                        f"SELECT COUNT(*) FROM {schema_name}.{table_name}"
                    )
                    row_count = count_result.result_rows[0][0]
                else:
                    print("Warning: Could not verify row count")
                    return True
            print(f"Successfully loaded {row_count:,} rows into {table_name}")
            return True
        except Exception as e:
            print(f"Failed to load data into {table_name}: {e}")
            return False

    def execute_query(
        self, query: str, query_name: str | None = None, return_data: bool = False
    ) -> dict[str, Any]:
        """Execute a SQL query in ClickHouse using clickhouse-connect."""
        from ..debug import debug_print

        if not query_name:
            query_name = "unnamed_query"
        query = query.rstrip().rstrip(";")
        try:
            debug_print(f"Executing query: {query_name}")
            if len(query) > 200:
                debug_print(f"SQL: {query[:200]}...")
            else:
                debug_print(f"SQL: {query}")
            with Timer(f"Query {query_name}") as timer:
                if clickhouse_connect is None:
                    print(
                        "Warning: clickhouse-connect not available, falling back to client"
                    )
                    return self._execute_query_fallback(
                        query, query_name, timer, return_data
                    )
                client = clickhouse_connect.get_client(
                    host=self.host,
                    port=self.port,
                    username=self.username,
                    password=self.password,
                    database=self.database,
                    interface="http",
                    secure=False,
                )
                try:
                    query_stripped = query.strip()
                    while query_stripped.startswith("--"):
                        newline_pos = query_stripped.find("\n")
                        if newline_pos == -1:
                            query_stripped = ""
                            break
                        query_stripped = query_stripped[newline_pos + 1 :].strip()
                    if query_stripped.upper().startswith(
                        ("SELECT", "WITH", "SHOW", "DESCRIBE")
                    ):
                        result = client.query(query)
                        rows_returned = (
                            result.row_count
                            if hasattr(result, "row_count")
                            else len(result.result_rows)
                        )
                        if return_data:
                            import pandas as pd

                            df = pd.DataFrame(
                                result.result_rows, columns=result.column_names
                            )
                        else:
                            df = None
                    else:
                        client.command(query)
                        rows_returned = 0
                        df = None
                    response: dict[str, Any] = {
                        "success": True,
                        "elapsed_s": timer.elapsed,
                        "rows_returned": rows_returned,
                        "query_name": query_name,
                        "error": None,
                    }
                    if return_data and df is not None:
                        response["data"] = df
                    return response
                finally:
                    client.close()
        except Exception as e:
            return {
                "success": False,
                "elapsed_s": timer.elapsed if "timer" in locals() else 0,
                "rows_returned": 0,
                "query_name": query_name,
                "error": str(e),
            }

    def _execute_query_fallback(
        self, query: str, query_name: str, timer: Any, return_data: bool = False
    ) -> dict[str, Any]:
        """Fallback query execution using clickhouse-client when clickhouse-connect is not available."""
        if return_data:
            print(
                "Warning: return_data not supported in fallback mode, data will not be returned"
            )
        try:
            if self.setup_method == "docker":
                cmd = f"docker exec {self.container_name} clickhouse-client --user={self.username} --password={self.password} --database={self.database} --query='{query}' --format=TabSeparated"
            else:
                cmd = f"clickhouse-client --user={self.username} --password={self.password} --database={self.database} --query='{query}' --format=TabSeparated"
            result = self.execute_command(cmd, timeout=3600.0)
            if result["success"]:
                rows_returned = self._count_result_rows(result["stdout"])
                return {
                    "success": True,
                    "elapsed_s": timer.elapsed,
                    "rows_returned": rows_returned,
                    "query_name": query_name,
                    "error": None,
                }
            else:
                return {
                    "success": False,
                    "elapsed_s": timer.elapsed,
                    "rows_returned": 0,
                    "query_name": query_name,
                    "error": result["stderr"],
                }
        except Exception as e:
            return {
                "success": False,
                "elapsed_s": timer.elapsed,
                "rows_returned": 0,
                "query_name": query_name,
                "error": str(e),
            }

    def _count_result_rows(self, output: str) -> int:
        """Count number of rows in query result."""
        if not output.strip():
            return 0
        return len([line for line in output.strip().split("\n") if line.strip()])

    def get_system_metrics(self) -> dict[str, Any]:
        """Get ClickHouse-specific performance metrics using clickhouse-connect."""
        metrics: dict[str, Any] = {}
        try:
            if clickhouse_connect is None:
                metrics["warning"] = "clickhouse-connect not available, limited metrics"
                return metrics
            system_queries = {
                "query_count": "SELECT count() FROM system.processes",
                "memory_usage": "SELECT formatReadableSize(sum(memory_usage)) FROM system.processes",
                "disk_usage": "SELECT formatReadableSize(sum(bytes_on_disk)) FROM system.parts",
                "cache_stats": "SELECT * FROM system.events WHERE event LIKE '%Cache%'",
            }
            for metric_name, query in system_queries.items():
                result = self.execute_query(query, query_name=f"metrics_{metric_name}")
                if result["success"]:
                    metrics[metric_name] = {
                        "query_time": result["elapsed_s"],
                        "rows": result["rows_returned"],
                    }
        except Exception as e:
            metrics["error"] = str(e)
        return metrics

    def teardown(self) -> bool:
        """Clean up ClickHouse installation."""
        success = True
        if self.setup_method == "docker":
            stop_result = self.execute_command(
                f"docker stop {self.container_name} || true"
            )
            remove_result = self.execute_command(
                f"docker rm {self.container_name} || true"
            )
            success = stop_result["success"] and remove_result["success"]
        elif self.setup_config.get("stop_service_on_teardown", False):
            self.execute_command("sudo systemctl stop clickhouse-server")
        if self.setup_config.get("cleanup_data", False):
            success = success and self.cleanup_data_directory()
        return success

    def get_version_info(self) -> dict[str, str]:
        """Get detailed version information using clickhouse-connect."""
        version_info = {"configured_version": self.version}
        try:
            result = self.execute_query("SELECT version()", query_name="get_version")
            if result["success"]:
                version_info["actual_version"] = (
                    "version_retrieved_via_clickhouse_connect"
                )
            if clickhouse_connect is not None:
                version_info["clickhouse_connect_available"] = "yes"
                version_info["clickhouse_connect_version"] = getattr(
                    clickhouse_connect, "__version__", "unknown"
                )
            else:
                version_info["clickhouse_connect_available"] = "no"
        except Exception as e:
            version_info["version_error"] = str(e)
        return version_info
