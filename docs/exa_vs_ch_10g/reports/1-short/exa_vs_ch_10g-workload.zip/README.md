# Workload Execution Package

This is a minimal, self-contained package for executing database benchmark workloads.

## Quick Start

```bash
# Install dependencies
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Execute workload (auto-detects running database)
./execute_workload.sh

# Or specify system explicitly
./execute_workload.sh exasol
./execute_workload.sh clickhouse

# Debug mode
./execute_workload.sh exasol --debug
```

## Package Contents

- `benchkit/` - Minimal framework for workload execution
- `workloads/` - Workload definitions and queries
- `config.yaml` - Workload configuration
- `execute_workload.sh` - Main execution script
- `requirements.txt` - Python dependencies

## Code Quality

This package is generated and validated with:
- **Black** for code formatting
- **Ruff** for linting and auto-fixes
- **isort** for import sorting
- **mypy** for type checking

All quality checks pass in the generated package.
