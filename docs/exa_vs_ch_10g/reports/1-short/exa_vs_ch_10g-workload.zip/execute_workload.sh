#!/bin/bash
# Workload execution script for exa_vs_ch_10g
# This script executes only the workload against pre-configured systems
set -e

# Parse command line arguments
SYSTEM_NAME=""
DEBUG_FLAG=""

while [[ $# -gt 0 ]]; do
    case $1 in
        --debug)
            DEBUG_FLAG="--debug"
            shift
            ;;
        *)
            if [ -z "$SYSTEM_NAME" ]; then
                SYSTEM_NAME="$1"
            fi
            shift
            ;;
    esac
done

# Auto-detect system if not provided
if [ -z "$SYSTEM_NAME" ]; then
    # Auto-detect system based on what's running locally
    if systemctl is-active --quiet c4_cloud_command 2>/dev/null || pgrep -f "c4" >/dev/null 2>&1; then
        SYSTEM_NAME="exasol"
    elif systemctl is-active --quiet clickhouse-server 2>/dev/null || pgrep -f "clickhouse" >/dev/null 2>&1; then
        SYSTEM_NAME="clickhouse"
    else
        echo "Error: Could not auto-detect system. Please specify system name as parameter."
        echo "Usage: $0 [system_name] [--debug]"
        echo "Available systems: exasol, clickhouse, clickhouse_tuned, clickhouse_stat"
        exit 1
    fi
fi

echo "=== Workload Execution: exa_vs_ch_10g ==="
echo "Running workload for system: $SYSTEM_NAME"
echo ""

# Install dependencies if needed
if [ ! -d "venv" ]; then
    echo "Setting up Python virtual environment..."
    python3 -m venv venv
fi

source venv/bin/activate
pip install -r requirements.txt

echo ""
echo "Executing workload for $SYSTEM_NAME..."

python -m benchkit --config config.yaml --system "$SYSTEM_NAME" $DEBUG_FLAG

echo ""
echo "=== Workload Completed ==="
echo "Results available in results/exa_vs_ch_10g/"
