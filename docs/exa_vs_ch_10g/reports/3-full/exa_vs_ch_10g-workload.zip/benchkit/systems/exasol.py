"""Exasol database system implementation."""

import os
from pathlib import Path
from typing import Any, cast

import pyexasol

from ..util import Timer
from .base import SystemUnderTest


class ExasolSystem(SystemUnderTest):
    """Exasol database system implementation."""

    @classmethod
    def get_python_dependencies(cls) -> list[str]:
        """Return Python packages required by Exasol system."""
        return ["pyexasol>=0.25.0"]

    @classmethod
    def extract_workload_connection_info(
        cls, setup_config: dict[str, Any], for_local_execution: bool = False
    ) -> dict[str, Any]:
        """
        Extract Exasol connection info with proper defaults and password handling.

        Args:
            setup_config: The setup section from system config
            for_local_execution: If True, use localhost (for packages running on DB machine).
                                If False, preserve configured host with env var resolution (for remote execution).
        """

        def resolve_env_var(value: str) -> str:
            """Resolve environment variable placeholders like $VAR_NAME."""
            if isinstance(value, str) and value.startswith("$"):
                var_name = value[1:]
                return os.environ.get(var_name, value)
            return value

        setup_method = setup_config.get("method", "docker")
        if setup_method == "installer":
            password = setup_config.get("db_password", "exasol")
        else:
            password = setup_config.get("password", "exasol")
        if for_local_execution:
            host = "localhost"
        else:
            host = resolve_env_var(setup_config.get("host", "localhost"))
        connection_info = {
            "host": host,
            "port": setup_config.get("port", 8563),
            "username": setup_config.get("username", "sys"),
            "password": password,
            "schema": setup_config.get("schema", "benchmark"),
        }
        if setup_config.get("use_additional_disk", False):
            connection_info["use_additional_disk"] = True
        return connection_info

    @classmethod
    def get_required_ports(cls) -> dict[str, int]:
        """Return ports required by Exasol system."""
        return {
            "Exasol Database": 8563,
            "Exasol BucketFS": 6583,
            "Exasol Admin UI": 2443,
            "Exasol SSH": 20002,
        }

    def get_connection_string(self, public_ip: str, private_ip: str) -> str:
        """Get Exasol connection string with full CLI command."""
        port = self.setup_config.get("port", 8563)
        username = self.setup_config.get("username", "sys")
        schema = self.setup_config.get("schema", "benchmark")
        return f"exaplus -c {public_ip}:{port} -u {username} -p <password> -s {schema}"

    def __init__(self, config: dict[str, Any]):
        super().__init__(config)
        self.setup_method = self.setup_config.get("method", "docker")
        self.container_name = f"exasol_{self.name}"
        self.license_file = self.setup_config.get("license_file")
        self.cluster_config = self.setup_config.get("cluster", {})
        if self.setup_config.get("use_additional_disk", False):
            self.data_dir = None
        if self.setup_method == "installer":
            host_external_addrs = self.setup_config.get("host_external_addrs")
            if host_external_addrs:
                if host_external_addrs.startswith("$"):
                    var_name = host_external_addrs[1:]
                    resolved_ip = self._resolve_ip_address(var_name)
                    host_external_addrs = (
                        resolved_ip if resolved_ip else host_external_addrs
                    )
                self.host = host_external_addrs.split(",")[0].strip()
            else:
                self.host = self.setup_config.get("host", "localhost")
            self.password = self.setup_config.get("db_password", "exasol")
        else:
            self.host = self.setup_config.get("host", "localhost")
            self.password = self.setup_config.get("password", "exasol")
        self.port = self.setup_config.get("port", 8563)
        self.username = self.setup_config.get("username", "sys")
        self.schema = self.setup_config.get("schema", "benchmark")
        self._connection = None
        self._schema_created = False
        self._cloud_instance_manager = None
        self._external_host = None
        self._certificate_fingerprint: str | None = None
        self._data_generation_mount_point: str | None = None
        self._exasol_raw_partition: str | None = None

    def _resolve_ip_address(self, var_name: str) -> str | None:
        """Resolve IP address from configuration or infrastructure state."""
        from benchkit.infra.manager import InfraManager

        return InfraManager.resolve_ip_from_infrastructure(var_name, self.name)

    def _connect_with_fingerprint_retry(
        self, dsn: str, user: str, password: str, **kwargs: Any
    ) -> pyexasol.ExaConnection:
        """
        Connect to Exasol with automatic TLS certificate fingerprint handling.

        For localhost connections, disables SSL verification.
        For remote connections, tries normal connection first, then extracts
        fingerprint from error and retries if certificate error occurs.
        """
        import re
        import ssl

        is_localhost = dsn.startswith("localhost") or dsn.startswith("127.0.0.1")
        try:
            connection_kwargs = kwargs.copy()
            connection_kwargs["autocommit"] = True
            if is_localhost:
                connection_kwargs["websocket_sslopt"] = {"cert_reqs": ssl.CERT_NONE}
            return pyexasol.connect(
                dsn=dsn, user=user, password=password, **connection_kwargs
            )
        except Exception as e:
            error_msg = str(e)
            if is_localhost and ("SSL" in error_msg or "certificate" in error_msg):
                print(
                    "SSL error on localhost, attempting connection without SSL verification"
                )
                connection_kwargs["websocket_sslopt"] = {"cert_reqs": ssl.CERT_NONE}
                return pyexasol.connect(
                    dsn=dsn, user=user, password=password, **connection_kwargs
                )
            if (
                "PKIX path building failed" in error_msg
                or "unable to find valid certification path" in error_msg
                or "TLS connection to host" in error_msg
            ):
                patterns = [
                    "connection string: [^/]+/([A-F0-9]+)",
                    "localhost/([A-F0-9]+)",
                    "[^/]+:?\\d*/([A-F0-9]+)",
                ]
                fingerprint_match = None
                for pattern in patterns:
                    fingerprint_match = re.search(pattern, error_msg)
                    if fingerprint_match:
                        break
                if fingerprint_match:
                    fingerprint = fingerprint_match.group(1)
                    if fingerprint is None:
                        self._certificate_fingerprint = ""
                    else:
                        self._certificate_fingerprint = fingerprint
                    if "/" in dsn:
                        dsn_with_fingerprint = dsn
                    else:
                        dsn_with_fingerprint = f"{dsn}/{fingerprint}"
                    print(
                        f"TLS certificate issue detected, retrying with fingerprint: {dsn_with_fingerprint}"
                    )
                    return pyexasol.connect(
                        dsn=dsn_with_fingerprint, user=user, password=password, **kwargs
                    )
                else:
                    print(
                        f"Certificate error but couldn't extract fingerprint: {error_msg}"
                    )
                    raise
            else:
                raise

    def _build_dsn(self, host: str, port: int) -> str:
        """Build DSN with cached fingerprint if available."""
        dsn = f"{host}:{port}"
        if self._certificate_fingerprint:
            dsn = f"{dsn}/{self._certificate_fingerprint}"
        return dsn

    def _schema_exists(self, conn: Any, schema_name: str | None = None) -> bool:
        """Return True if the given schema exists."""
        target_schema = schema_name or self.schema
        if not target_schema:
            return False
        normalized = target_schema.upper()
        safe_schema = normalized.replace("'", "''")
        query = f"SELECT 1 FROM sys.exa_schemas WHERE UPPER(schema_name) = '{safe_schema}' LIMIT 1"
        try:
            result = conn.execute(query)
            row = result.fetchone() if result else None
            return row is not None
        except Exception:
            return False

    def get_data_generation_directory(self, workload: Any) -> Path | None:
        """
        Get directory for TPC-H data generation.

        Priority order:
        1. If data_dir explicitly specified in config → use that
        2. If use_additional_disk=true → use /data/tpch_gen for data generation
        3. Otherwise → use default local path (None)

        Args:
            workload: The workload object (for scale factor)

        Returns:
            Path to data generation directory, or None for default
        """
        explicit_data_dir = self.setup_config.get("data_dir")
        if explicit_data_dir:
            data_gen_path = (
                Path(str(explicit_data_dir))
                / "tpch_gen"
                / workload.name
                / f"sf{workload.scale_factor}"
            )
            print(
                f"Exasol: Using configured data_dir for data generation: {data_gen_path}"
            )
            return cast(Path, data_gen_path)
        use_additional_disk = self.setup_config.get("use_additional_disk", False)
        if use_additional_disk:
            tpch_gen_dir = "/data/tpch_gen"
            self.execute_command(
                f"sudo mkdir -p {tpch_gen_dir} && sudo chown -R $(whoami):$(whoami) {tpch_gen_dir}",
                record=False,
            )
            if self._data_generation_mount_point is None:
                self._data_generation_mount_point = tpch_gen_dir
            data_gen_path = (
                Path(tpch_gen_dir) / workload.name / f"sf{workload.scale_factor}"
            )
            print(f"Exasol: Using additional disk for data generation: {data_gen_path}")
            return cast(Path, data_gen_path)
        return None

    def _get_connection(self) -> Any:
        """Get a connection to Exasol database using pyexasol."""
        connection_params = {
            "dsn": self._build_dsn(self.host, self.port),
            "user": self.username,
            "password": self.password,
            "compression": True,
        }
        if hasattr(self, "_schema_created") and self._schema_created and self.schema:
            connection_params["schema"] = self.schema
        return self._connect_with_fingerprint_retry(**connection_params)

    def _verify_preinstalled(self) -> bool:
        """Verify that Exasol is already installed and accessible."""
        return self.is_healthy()

    def start(self) -> bool:
        """Start the Exasol system."""
        print(f"Starting {self.name} system using {self.setup_method} method...")
        if self.setup_method == "docker":
            result = self.execute_command(f"docker start {self.container_name}")
            if result["success"]:
                print(
                    f"Docker container started, waiting for {self.name} to be healthy..."
                )
                return self.wait_for_health()
            print(f"Failed to start Docker container for {self.name}")
            return False
        else:
            print(f"Connection details: {self.host}:{self.port} as {self.username}")
            print("Performing initial health check...")
            if self.is_healthy(quiet=False):
                print(f"✓ {self.name} is already healthy and ready")
                return True
            print("Database not accessible, checking c4 service status...")
            service_check = self.execute_command(
                "systemctl is-active c4_cloud_command", record=False
            )
            if service_check.get("success", False):
                print("✓ c4_cloud_command service is running, waiting for database...")
                success = self.wait_for_health(max_attempts=60, delay=5.0)
                if success:
                    print(f"✓ {self.name} is healthy and ready")
                else:
                    print(f"✗ {self.name} failed to become healthy after 5 minutes")
                    print("Final health check with detailed error:")
                    self.is_healthy(quiet=False)
                return success
            else:
                print(
                    "⚠ c4_cloud_command service not running, attempting to restart cluster..."
                )
                return self._restart_existing_cluster()

    def _restart_existing_cluster(self) -> bool:
        """Restart an existing Exasol cluster that has been installed but not running."""
        print("Attempting to restart existing Exasol cluster...")
        config_check = self.execute_command(
            "find /tmp -name 'exasol_c4.conf' -type f | head -1", record=False
        )
        if (
            not config_check.get("success", False)
            or not config_check.get("stdout", "").strip()
        ):
            print("⚠ No existing c4 config file found, cannot restart cluster")
            print("   This likely means the cluster was never fully deployed")
            return False
        config_path = config_check.get("stdout", "").strip()
        print(f"Found existing config file: {config_path}")
        print("Restarting cluster with existing configuration...")
        result = self.execute_command(f"./c4 host play -i {config_path}", timeout=900)
        if not result["success"]:
            print(f"Failed to restart cluster: {result.get('stderr', 'Unknown error')}")
            return False
        print("Cluster restart initiated, waiting for database to become healthy...")
        success = self.wait_for_health(max_attempts=60, delay=5.0)
        if success:
            print(f"✓ {self.name} cluster restarted successfully")
        else:
            print(f"✗ {self.name} cluster restart failed - database not healthy")
        return success

    def is_healthy(self, quiet: bool = False) -> bool:
        """Check if Exasol is running and accepting connections."""
        try:
            health_check_host = getattr(self, "_external_host", None)
            if not health_check_host and self._cloud_instance_manager:
                health_check_host = getattr(
                    self._cloud_instance_manager, "public_ip", None
                )
            if not health_check_host:
                health_check_host = self.host
            dsn = self._build_dsn(health_check_host, self.port)
            if not quiet:
                print(f"Connecting to Exasol at {dsn} as {self.username}...")
            conn = self._connect_with_fingerprint_retry(
                dsn=dsn, user=self.username, password=self.password, compression=True
            )
            if not quiet:
                print("Connection established, testing with SELECT 1...")
            conn.execute("SELECT 1")
            conn.close()
            if not quiet:
                print("Health check successful")
            return True
        except Exception as e:
            if not quiet:
                print(f"Health check failed: {e}")
                print(
                    f"Connection details: host={self.host}, port={self.port}, user={self.username}"
                )
            return False

    def create_schema(self, schema_name: str) -> bool:
        """Create a schema in Exasol."""
        sql = f"CREATE SCHEMA IF NOT EXISTS {schema_name};"
        result = self.execute_query(sql, query_name=f"create_schema_{schema_name}")
        success = bool(result.get("success", False))
        if success and self.schema and (schema_name.upper() == self.schema.upper()):
            self._schema_created = True
        return success

    def load_data(self, table_name: str, data_path: Path, **kwargs: Any) -> bool:
        """Load data into Exasol table using pyexasol import_from_file."""
        schema_name = kwargs.get("schema", "benchmark")
        columns = kwargs.get("columns", None)
        conn = None
        try:
            conn = self._get_connection()
            if not conn:
                return False
            if not self._schema_created:
                if self._schema_exists(conn, schema_name):
                    self._schema_created = True
                    conn.execute(f"OPEN SCHEMA {schema_name}")
            import_params = {
                "column_separator": "|",
                "columns": columns,
                "csv_cols": [f"1..{len(columns)}"] if columns else None,
            }
            import_params = {k: v for k, v in import_params.items() if v is not None}
            print(f"Loading {data_path} into {table_name}...")
            conn.import_from_file(
                str(data_path), table=table_name, import_params=import_params
            )
            result = conn.execute(f"SELECT COUNT(*) FROM {table_name}")
            row_count = result.fetchone()[0]
            print(f"Successfully loaded {row_count:,} rows into {table_name}")
            return True
        except Exception as e:
            print(f"Failed to load data into {table_name}: {e}")
            return False
        finally:
            if conn:
                conn.close()

    def execute_query(
        self, query: str, query_name: str | None = None, return_data: bool = False
    ) -> dict[str, Any]:
        """Execute a SQL query in Exasol using pyexasol."""
        from ..debug import debug_print

        if not query_name:
            query_name = "unnamed_query"
        timer_obj: Timer | None = None
        try:
            conn = None
            schema_to_use = self.schema
            try:
                conn = self._get_connection()
                if schema_to_use:
                    if not self._schema_created:
                        if self._schema_exists(conn, schema_to_use):
                            self._schema_created = True
                            conn.execute(f"OPEN SCHEMA {schema_to_use}")
                debug_print(f"Executing query: {query_name}")
                if len(query) > 200:
                    debug_print(f"SQL: {query[:200]}...")
                else:
                    debug_print(f"SQL: {query}")
                with Timer(f"Query {query_name}") as timer:
                    timer_obj = timer
                    query_stripped = query.strip()
                    while query_stripped.startswith("--"):
                        newline_pos = query_stripped.find("\n")
                        if newline_pos == -1:
                            query_stripped = ""
                            break
                        query_stripped = query_stripped[newline_pos + 1 :].strip()
                    is_select_query = query_stripped.upper().startswith(
                        ("SELECT", "WITH")
                    )
                    debug_print(f"Is SELECT/WITH: {is_select_query}")
                    if is_select_query:
                        if return_data:
                            import pandas as pd

                            result = conn.execute(query)
                            data = result.fetchall() if result else []
                            columns = result.columns() if result else []
                            df = pd.DataFrame(data, columns=columns)
                            rows_returned = len(df)
                        else:
                            result = conn.execute(query)
                            rows_returned = len(result.fetchall()) if result else 0
                            df = None
                    else:
                        conn.execute(query)
                        rows_returned = (
                            conn.rowcount() if hasattr(conn, "rowcount") else 0
                        )
                        df = None
                response: dict[str, Any] = {
                    "success": True,
                    "elapsed_s": timer_obj.elapsed if timer_obj else 0,
                    "rows_returned": rows_returned,
                    "query_name": query_name,
                    "error": None,
                }
                if return_data and df is not None:
                    response["data"] = df
                    debug_print(f"Added data to response, df shape: {df.shape}")
                elif return_data:
                    debug_print(f"return_data={return_data}, but df is None")
                return response
            finally:
                if conn:
                    if schema_to_use:
                        try:
                            self._schema_created = self._schema_exists(
                                conn, schema_to_use
                            )
                        except Exception:
                            pass
                    conn.close()
        except Exception as e:
            return {
                "success": False,
                "elapsed_s": timer_obj.elapsed if timer_obj else 0,
                "rows_returned": 0,
                "query_name": query_name,
                "error": str(e),
            }

    def get_system_metrics(self) -> dict[str, Any]:
        """Get Exasol-specific performance metrics using pyexasol."""
        metrics: dict[str, Any] = {}
        try:
            system_queries = {
                "sessions": "SELECT COUNT(*) FROM EXA_ALL_SESSIONS WHERE STATUS = 'EXECUTE'",
                "memory_usage": "SELECT * FROM EXA_SYSTEM_EVENTS WHERE EVENT_TYPE = 'MEMORY' ORDER BY MEASURE_TIME DESC LIMIT 1",
                "cache_stats": "SELECT * FROM EXA_STATISTICS.EXA_DB_SIZE_DAILY ORDER BY SNAPSHOT_ID DESC LIMIT 1",
            }
            for metric_name, query in system_queries.items():
                result = self.execute_query(query, query_name=f"metrics_{metric_name}")
                if result["success"]:
                    metrics[metric_name] = {
                        "query_time": result["elapsed_s"],
                        "rows": result["rows_returned"],
                    }
        except Exception as e:
            metrics["error"] = str(e)
        return metrics

    def teardown(self) -> bool:
        """Clean up Exasol installation."""
        success = True
        if self.setup_method == "docker":
            stop_result = self.execute_command(
                f"docker stop {self.container_name} || true"
            )
            remove_result = self.execute_command(
                f"docker rm {self.container_name} || true"
            )
            success = stop_result["success"] and remove_result["success"]
        if self.setup_config.get("cleanup_data", False):
            success = success and self.cleanup_data_directory()
        return success

    def get_version_info(self) -> dict[str, str]:
        """Get detailed version information using pyexasol."""
        version_info = {"configured_version": self.version}
        try:
            result = self.execute_query(
                "SELECT PARAM_VALUE FROM EXA_METADATA WHERE PARAM_NAME = 'databaseProductVersion'",
                query_name="get_version",
            )
            if result["success"]:
                version_info["actual_version"] = "version_retrieved_via_pyexasol"
            version_info["pyexasol_version"] = getattr(
                pyexasol, "__version__", "unknown"
            )
        except Exception as e:
            version_info["version_error"] = str(e)
        return version_info

    def set_cloud_instance_manager(self, instance_manager: Any) -> None:
        """Set the cloud instance manager for remote command execution."""
        self._cloud_instance_manager = instance_manager
        if instance_manager and hasattr(instance_manager, "public_ip"):
            self._external_host = instance_manager.public_ip
            self.host = "localhost"
            db_password = self.setup_config.get("db_password")
            if db_password:
                self.password = db_password

    def execute_command(
        self,
        command: str,
        timeout: float | None = None,
        record: bool = True,
        category: str = "setup",
    ) -> dict[str, Any]:
        """Execute a command, either locally or remotely depending on setup."""
        if self._cloud_instance_manager:
            result = self._cloud_instance_manager.run_remote_command(
                command, timeout=int(timeout) if timeout else 300
            )
            if record:
                self.setup_commands.append(
                    {
                        "command": self._sanitize_command_for_report(command),
                        "success": result.get("success", False),
                        "description": f"Execute {command.split()[0]} command on remote system",
                        "category": category,
                    }
                )
            return dict(result)
        else:
            return super().execute_command(command, timeout, record, category)
