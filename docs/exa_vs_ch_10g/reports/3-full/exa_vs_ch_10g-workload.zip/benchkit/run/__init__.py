"""Minimal run module for workload execution."""
