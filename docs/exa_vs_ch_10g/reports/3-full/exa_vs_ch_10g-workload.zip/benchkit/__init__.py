"""
Database Benchmark Blog Framework

A modular framework for running and documenting database benchmarks.
"""

__version__ = "0.1.0"
