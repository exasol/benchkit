# ClickHouse TPC-H Optimizations

This document explains the ClickHouse-specific optimizations added to improve performance for complex TPC-H queries, particularly Q8, Q17, and Q21.

## Overview

The optimizations are automatically applied during the TPC-H workload preparation phase through two setup scripts:
- `create_indexes.sql` - Adds skip indexes for selective filtering
- `analyze_tables.sql` - Collects statistics and optimizes tables

## 1. Skip Indexes (Data Skipping Indexes)

Skip indexes allow ClickHouse to skip reading unnecessary data blocks during query execution. They are especially effective for:
- Highly selective filters
- Bloom filter lookups on high-cardinality columns
- Set membership checks on low-cardinality columns

### Skip Indexes Added

#### Lineitem Table (Most Critical)
```sql
-- Q21: Fast IN/NOT IN for self-join subqueries
idx_l_orderkey_bloom: bloom_filter on l_orderkey

-- Q21: Date comparison filters
idx_l_dates_minmax: minmax on (l_receiptdate, l_commitdate)

-- Q17: Correlated subquery lookups
idx_l_partkey_set: set(0) on l_partkey

-- Q17: Quantity range filters
idx_l_quantity_minmax: minmax on l_quantity (bloom_filter doesn't support Decimal)
```

#### Part Table
```sql
-- Q08: Highly selective type filter (p_type = 'ECONOMY ANODIZED STEEL')
idx_p_type_set: set(100) on p_type

-- Q17: Brand and container filters
idx_p_brand_set: set(50) on p_brand
idx_p_container_set: set(50) on p_container
```

#### Orders Table
```sql
-- Q21: Status filter (o_orderstatus = 'F')
idx_o_orderstatus_set: set(3) on o_orderstatus
```

#### Nation and Region Tables
```sql
-- Q08, Q21: Nation name filters
idx_n_name_bloom: bloom_filter on n_name

-- Q08: Region name filter (r_name = 'AMERICA')
idx_r_name_set: set(10) on r_name
```

### Skip Index Types

- **bloom_filter**: Best for equality checks on high-cardinality columns
  - Supported types: Integer, String, Date, DateTime, FixedString
  - **NOT supported**: Decimal, Float, Double
- **set(N)**: Best for low-cardinality columns (stores up to N unique values)
  - Supported types: Most data types including integers, strings, dates
- **minmax**: Best for range comparisons on ordered data
  - Supported types: All numeric types (including Decimal), dates, strings

## 2. Table Statistics (Optional)

**Note**: Statistics collection is **opt-in** and requires explicit configuration.

To enable statistics, add to your config YAML:
```yaml
systems:
  - name: "clickhouse"
    setup:
      extra:
        allow_statistics_optimize: 1
```

When enabled, statistics help ClickHouse's query optimizer make better decisions about:
- Join ordering
- Join algorithms (hash vs merge)
- Predicate pushdown

### Statistics Types

- **countmin**: Count-Min sketch for cardinality estimation (note: one word, no underscore)
- **tdigest**: T-digest for quantile estimation and range selectivity
- **uniq**: Unique value count estimation (HyperLogLog)
- **minmax**: Min/max values for range estimation

### Statistics Added

Statistics are collected on all join keys and filter columns:

#### Join Keys (High Priority)
- `l_orderkey`, `l_partkey`, `l_suppkey` (lineitem foreign keys)
- `o_orderkey`, `o_custkey` (orders keys)
- `p_partkey`, `s_suppkey`, `c_custkey` (primary keys)
- `ps_partkey`, `ps_suppkey` (partsupp composite key)
- `n_nationkey`, `r_regionkey` (dimension keys)

#### Filter Columns
- `l_quantity`, `l_receiptdate`, `l_commitdate` (Q17, Q21 filters)
- `o_orderdate`, `o_orderstatus` (Q8, Q21 filters)
- `p_type`, `p_brand`, `p_container` (Q8, Q17 filters)
- `n_name`, `r_name` (dimension filters)

## 3. Query-Specific Optimizations

### Q21: Suppliers Who Kept Orders Waiting

**Problem**: Multiple self-joins on lineitem with IN/NOT IN subqueries

**Optimizations Applied**:
```sql
-- Skip indexes
idx_l_orderkey_bloom     -- Fast subquery evaluation
idx_l_dates_minmax       -- l_receiptdate > l_commitdate filter
idx_o_orderstatus_set    -- o_orderstatus = 'F' filter
idx_n_name_bloom         -- n_name = 'SAUDI ARABIA' filter

-- Statistics for join reordering
l_orderkey, l_suppkey    -- Optimize lineitem self-joins
o_orderkey, s_suppkey    -- Optimize main joins
```

### Q08: National Market Share

**Problem**: 8-way join with multiple date and type filters

**Optimizations Applied**:
```sql
-- Skip indexes
idx_p_type_set           -- p_type = 'ECONOMY ANODIZED STEEL'
idx_r_name_set           -- r_name = 'AMERICA'
idx_n_name_bloom         -- Nation name lookups

-- Statistics for join reordering (8 tables)
All join keys get count_min, tdigest, uniq statistics
o_orderdate gets tdigest for range filter
```

### Q17: Small-Quantity-Order Revenue

**Problem**: Correlated subquery with aggregation (0.2 * AVG)

**Optimizations Applied**:
```sql
-- Skip indexes
idx_l_partkey_set        -- Correlated subquery on l_partkey
idx_l_quantity_minmax    -- l_quantity < threshold filter (minmax for Decimal type)
idx_p_brand_set          -- p_brand = 'Brand#23' filter
idx_p_container_set      -- p_container = 'MED BOX' filter

-- Statistics
l_partkey, l_quantity    -- Help optimizer with correlated subquery
p_partkey                -- Join optimization
```

## 4. Version Compatibility

### Statistics Feature (ClickHouse 24.6+ - Optional)

The statistics collection is **opt-in** and uses experimental features that require:
- ClickHouse version 24.6 or later
- Explicit configuration: `allow_statistics_optimize: 1` in config YAML `extra` section
- When enabled, settings are automatically added to user profile (`/etc/clickhouse-server/users.d/benchmark.xml`)

**Default Behavior**: If `allow_statistics_optimize` is not set to 1:
- Statistics collection is **skipped entirely**
- Only skip indexes and OPTIMIZE TABLE are executed
- Works with all ClickHouse versions (including older versions that don't support statistics)

**When Enabled**: Statistics are collected and settings are configured globally for all queries

### Skip Indexes (All Versions)

Skip indexes are supported in all modern ClickHouse versions (20.1+) and will work regardless of statistics support.

## 5. Performance Expectations

With these optimizations, you should see:

**Q21 Performance**:
- 3-10x improvement from bloom filter on l_orderkey (subquery acceleration)
- 1.5-2x from join reordering with statistics
- **Total expected improvement: 5-20x**

**Q08 Performance**:
- 2-5x improvement from selective skip indexes (p_type, r_name)
- 1.5-3x from optimal join ordering
- **Total expected improvement: 3-15x**

**Q17 Performance**:
- 2-4x improvement from l_partkey set index (correlated subquery)
- 1.3-1.8x from minmax on l_quantity (range pruning)
- **Total expected improvement: 2.5-7x**

## 6. Verification Commands

After running the benchmark, you can verify the optimizations were applied:

### Check Skip Indexes
```sql
SELECT
    database,
    table,
    name AS index_name,
    type AS index_type,
    expr AS index_expression
FROM system.data_skipping_indices
WHERE database = 'benchmark'
ORDER BY table, name;
```

### Check Statistics
```sql
SELECT
    database,
    table,
    column,
    type AS statistic_type,
    is_active
FROM system.statistics
WHERE database = 'benchmark'
ORDER BY table, column;
```

### Verify OPTIMIZE Completed
```sql
SELECT
    database,
    table,
    active_part_count,
    bytes_on_disk
FROM system.tables
WHERE database = 'benchmark'
ORDER BY table;
```

### Analyze Query Plans
```sql
-- Get execution plan for Q21
EXPLAIN indexes = 1, actions = 1
SELECT s_name, COUNT(*) AS numwait
FROM supplier, lineitem l1, orders, nation
WHERE s_suppkey = l1.l_suppkey
  AND o_orderkey = l1.l_orderkey
  AND o_orderstatus = 'F'
  AND l1.l_receiptdate > l1.l_commitdate
  ...
```

## 7. Troubleshooting

### Statistics Not Applied

If statistics aren't working:

1. **Check ClickHouse Version**:
   ```sql
   SELECT version();
   -- Should be 24.6 or later
   ```

2. **Verify Global Settings Are Configured**:
   ```sql
   -- Check your current session settings
   SELECT name, value
   FROM system.settings
   WHERE name IN ('allow_experimental_statistics', 'allow_statistics_optimize');
   ```

   Both should show value `'1'`. If not, verify the user profile was created:
   ```bash
   cat /etc/clickhouse-server/users.d/benchmark.xml
   ```

3. **Manually Add Statistics**:
   If automatic creation failed, you can manually add them using the commands in `analyze_tables.sql`

### Skip Indexes Not Used

Check if indexes were created but not used:

1. **Verify Indexes Exist**:
   ```sql
   SELECT * FROM system.data_skipping_indices
   WHERE database = 'benchmark';
   ```

2. **Check Query Uses Indexed Columns**:
   Use `EXPLAIN indexes = 1` to see which indexes are being used

3. **Force Index Usage** (if needed):
   ```sql
   SET force_data_skipping_indices = 'idx_l_orderkey_bloom';
   ```

### Performance Still Poor

If performance is still significantly worse:

1. **Check Join Order**: Use `EXPLAIN` to verify ClickHouse is using optimal join order
2. **Increase Memory**: Set `max_memory_usage` higher if queries spill to disk
3. **Check Parallel Execution**: Verify `max_threads` is set appropriately
4. **Consider Query Rewrite**: Some TPC-H queries may need manual optimization for ClickHouse

## 8. Further Optimizations

If you still need better performance, consider:

### Projection Optimization
Create projections for specific queries:
```sql
ALTER TABLE lineitem ADD PROJECTION proj_q21_orderkey (
    SELECT * ORDER BY l_orderkey, l_suppkey
);
```

### Materialized Views
Pre-aggregate data for complex queries:
```sql
CREATE MATERIALIZED VIEW mv_nation_stats AS
SELECT n_name, COUNT(*) as cnt
FROM nation
GROUP BY n_name;
```

### Query Hints
Use ClickHouse-specific hints:
```sql
SELECT /*+ JOIN(orders, lineitem) */ ...
```

### Compression Tuning
Adjust compression codecs for better I/O:
```sql
ALTER TABLE lineitem MODIFY COLUMN l_quantity CODEC(DoubleDelta, LZ4);
```

## References

- [ClickHouse Skip Indexes](https://clickhouse.com/docs/en/optimize/skipping-indexes)
- [ClickHouse Statistics](https://clickhouse.com/docs/en/operations/statistics)
- [Query Optimization Guide](https://clickhouse.com/docs/en/optimize/query-optimization)
- [TPC-H in ClickHouse](https://clickhouse.com/docs/en/getting-started/example-datasets/tpch)
