from __future__ import annotations

"""Exasol database system implementation."""
import ssl
from collections.abc import Callable, Iterable
from pathlib import Path
from typing import Any, cast

import pyexasol

from benchkit.common import DataFormat

from ..util import Timer
from .base import SystemUnderTest


class ExasolSystem(SystemUnderTest):
    """Exasol database system implementation."""

    SUPPORTS_MULTINODE = True
    SUPPORTS_STREAMLOAD = True

    @classmethod
    def get_python_dependencies(cls) -> list[str]:
        """Return Python packages required by Exasol system."""
        return ["pyexasol>=0.25.0"]

    @classmethod
    def _get_connection_defaults(cls) -> dict[str, Any]:
        return {
            "port": 8563,
            "username": "sys",
            "password": "exasol",
            "schema_key": "schema",
            "schema": "benchmark",
        }

    @classmethod
    def _get_password_key(cls, setup_config: dict[str, Any]) -> str:
        return (
            "db_password" if setup_config.get("method") == "installer" else "password"
        )

    @classmethod
    def get_required_ports(cls) -> dict[str, int]:
        """Return ports required by Exasol system."""
        return {
            "Exasol Database": 8563,
            "Exasol BucketFS": 6583,
            "Exasol Admin UI": 2443,
            "Exasol SSH": 20002,
        }

    def __init__(
        self,
        config: dict[str, Any],
        output_callback: Callable[[str], None] | None = None,
        workload_config: dict[str, Any] | None = None,
    ):
        super().__init__(config, output_callback, workload_config)
        self.setup_method = self.setup_config.get("method", "docker")
        project_id = config.get("project_id", "")
        if project_id:
            self.container_name = f"exasol_{project_id}_{self.name}"
        else:
            self.container_name = f"exasol_{self.name}"
        self.license_file = self.setup_config.get("license_file")
        self.cluster_config = self.setup_config.get("cluster", {})
        if self.setup_config.get("use_additional_disk", False):
            self.data_dir = None
        if self.setup_method == "installer":
            host_external_addrs = self.setup_config.get("host_external_addrs")
            if host_external_addrs:
                if host_external_addrs.startswith("$"):
                    var_name = host_external_addrs[1:]
                    resolved_ip = self._resolve_ip_address(var_name)
                    host_external_addrs = (
                        resolved_ip if resolved_ip else host_external_addrs
                    )
                self.host = host_external_addrs.replace(",", " ").split()[0]
            else:
                self.host = self.setup_config.get("host", "localhost")
            self.password = self.setup_config.get("db_password", "exasol")
        else:
            self.host = self.setup_config.get("host", "localhost")
            self.password = self.setup_config.get("password", "exasol")
        self.port = self.setup_config.get("port", 8563)
        self.username = self.setup_config.get("username", "sys")
        self.schema = self.setup_config.get("schema", "benchmark")
        self._connection = None
        self._schema_created = False
        self._certificate_fingerprint: str | None = None
        self._data_generation_mount_point: str | None = None
        self._exasol_raw_partition: str | None = None
        self.data_device: str | None = None

    def _resolve_ip_address(self, var_name: str) -> str | None:
        """Resolve IP address from configuration or infrastructure state."""
        try:
            from benchkit.infra.manager import InfraManager

            project_id = self.config.get("project_id", "")
            result = InfraManager.resolve_ip_from_infrastructure(
                var_name, self.name, project_id
            )
            return cast(str | None, result)
        except ImportError:
            return None

    def _connect_with_fingerprint_retry(
        self, dsn: str, user: str, password: str, **kwargs: Any
    ) -> pyexasol.ExaConnection:
        """
        Connect to Exasol with automatic TLS certificate fingerprint handling.

        For localhost connections, disables SSL verification.
        For remote connections, tries normal connection first, then extracts
        fingerprint from error and retries if certificate error occurs.
        """
        import re

        is_localhost = dsn.startswith("localhost") or dsn.startswith("127.0.0.1")
        kwargs = {
            **kwargs,
            "autocommit": True,
            "websocket_sslopt": {"cert_reqs": ssl.CERT_NONE},
        }
        try:
            return pyexasol.connect(dsn=dsn, user=user, password=password, **kwargs)
        except Exception as e:
            error_msg = str(e)
            if is_localhost and ("SSL" in error_msg or "certificate" in error_msg):
                self._log(
                    "SSL error on localhost, attempting connection without SSL verification"
                )
                kwargs["websocket_sslopt"] = {"cert_reqs": ssl.CERT_NONE}
                return pyexasol.connect(dsn=dsn, user=user, password=password, **kwargs)
            if any(

                    x in error_msg
                    for x in ["PKIX", "certification path", "TLS connection"]

            ):
                for pattern in [
                    "connection string: [^/]+/([A-F0-9]+)",
                    "localhost/([A-F0-9]+)",
                    "[^/]+:?\\d*/([A-F0-9]+)",
                ]:
                    if m := re.search(pattern, error_msg):
                        self._certificate_fingerprint = m.group(1) or ""
                        return pyexasol.connect(
                            dsn=(
                                f"{dsn}/{self._certificate_fingerprint}"
                                if "/" not in dsn
                                else dsn
                            ),
                            user=user,
                            password=password,
                            **kwargs,
                        )
            raise

    def _build_dsn(self, host: str, port: int) -> str:
        """Build DSN with cached fingerprint if available."""
        dsn = f"{host}:{port}"
        if self._certificate_fingerprint:
            dsn = f"{dsn}/{self._certificate_fingerprint}"
        return dsn

    def _schema_exists(self, conn: Any, schema_name: str | None = None) -> bool:
        """Return True if the given schema exists."""
        target_schema = schema_name or self.schema
        if not target_schema:
            return False
        normalized = target_schema.upper()
        safe_schema = normalized.replace("'", "''")
        query = f"SELECT 1 FROM sys.exa_schemas WHERE UPPER(schema_name) = '{safe_schema}' LIMIT 1"
        try:
            result = conn.execute(query)
            row = result.fetchone() if result else None
            return row is not None
        except Exception:
            return False

    def get_data_generation_directory(self, workload: Any) -> Path | None:
        """Get directory for TPC-H data generation (uses base class, adds caching)."""
        result = super().get_data_generation_directory(workload)
        if result and self._data_generation_mount_point is None:
            self._data_generation_mount_point = str(result.parent.parent.parent)
        return result

    def _get_connection(
        self, compression: bool = True, skip_schema: bool = False
    ) -> Any:
        """Get a connection to Exasol database using pyexasol.

        Args:
            compression: Whether to enable compression (default True)
            skip_schema: If True, don't include schema in connection params.
                        Use this when creating schemas to avoid chicken-and-egg
                        problem where we try to connect TO the schema we're creating.
        """
        extra_kwargs: dict[str, Any] = {"compression": compression}
        if not skip_schema:
            schema_to_use = getattr(self, "_active_schema", None) or self.schema
            if schema_to_use:
                extra_kwargs["schema"] = schema_to_use
        return self._connect_with_fingerprint_retry(
            dsn=self._build_dsn(self.host, self.port),
            user=self.username,
            password=self.password,
            **extra_kwargs,
        )

    def _restart_existing_cluster(self) -> bool:
        """Restart an existing Exasol cluster that has been installed but not running."""
        self._log("Attempting to restart existing Exasol cluster...")
        config_check = self.execute_command(
            "find /tmp -name 'exasol_c4.conf' -type f | head -1", record=False
        )
        if (
            not config_check.get("success", False)
            or not config_check.get("stdout", "").strip()
        ):
            self._log("⚠ No existing c4 config file found, cannot restart cluster")
            self._log("   This likely means the cluster was never fully deployed")
            return False
        config_path = config_check.get("stdout", "").strip()
        self._log(f"Found existing config file: {config_path}")
        self._log("Restarting cluster with existing configuration...")
        result = self.execute_command(f"./c4 host play -i {config_path}", timeout=900)
        if not result["success"]:
            self._log(
                f"Failed to restart cluster: {result.get('stderr', 'Unknown error')}"
            )
            return False
        self._log(
            "Cluster restart initiated, waiting for database to become healthy..."
        )
        success = self.wait_for_health(max_attempts=60, delay=5.0)
        if success:
            self._log(f"✓ {self.name} cluster restarted successfully")
        else:
            self._log(f"✗ {self.name} cluster restart failed - database not healthy")
        return success

    def is_healthy(self, quiet: bool = False) -> bool:
        """Check if Exasol is running and accepting connections."""
        try:
            health_check_host = self._get_health_check_host()
            dsn = self._build_dsn(health_check_host, self.port)
            if not quiet:
                self._log(f"Connecting to Exasol at {dsn} as {self.username}...")
            conn = self._connect_with_fingerprint_retry(
                dsn=dsn, user=self.username, password=self.password, compression=True
            )
            if not quiet:
                self._log("Connection established, testing with SELECT 1...")
            conn.execute("SELECT 1")
            conn.close()
            if not quiet:
                self._log("Health check successful")
            return True
        except Exception as e:
            if not quiet:
                self._log(f"Health check failed: {e}")
                self._log(
                    f"Connection details: host={self.host}, port={self.port}, user={self.username}"
                )
            return False

    def create_schema(self, schema_name: str) -> bool:
        """Create a schema in Exasol.

        Uses skip_schema=True to avoid chicken-and-egg problem where we try
        to connect TO the schema we're creating.
        """
        sql = f"CREATE SCHEMA IF NOT EXISTS {schema_name};"
        conn = None
        try:
            conn = self._get_connection(skip_schema=True)
            if not conn:
                self._log(f"Failed to connect for schema creation: {schema_name}")
                return False
            conn.execute(sql)
            if self.schema and schema_name.upper() == self.schema.upper():
                self._schema_created = True
            self._log(f"✓ Schema '{schema_name}' created successfully")
            return True
        except Exception as e:
            self._log(f"Failed to create schema '{schema_name}': {e}")
            return False
        finally:
            if conn:
                try:
                    conn.close()
                except Exception:
                    pass

    def load_data(self, table_name: str, data_path: Path, **kwargs: Any) -> bool:
        """Load data into Exasol table using pyexasol import_from_file."""
        schema_name = kwargs.get("schema", "benchmark")
        columns = kwargs.get("columns", [])
        conn = None
        try:
            conn = self._get_connection(compression=False)
            if not conn:
                return False
            if not self._schema_created:
                if self._schema_exists(conn, schema_name):
                    self._schema_created = True
                    conn.execute(f"OPEN SCHEMA {schema_name}")
            import_params = {
                "column_separator": "|",
                "columns": columns,
                "csv_cols": [f"1..{len(columns)}"] if columns else None,
            }
            import_params = {k: v for k, v in import_params.items() if v is not None}
            self._log(f"Loading {data_path} into {table_name}...")
            conn.import_from_file(
                str(data_path), table=table_name, import_params=import_params
            )
            result = conn.execute(f"SELECT COUNT(*) FROM {table_name}")
            row_count = result.fetchone()[0]
            self._log(f"Successfully loaded {row_count:,} rows into {table_name}")
            return True
        except Exception as e:
            self._log(f"Failed to load data into {table_name}: {e}")
            return False
        finally:
            if conn:
                conn.close()

    def load_data_from_iterable(
        self,
        table_name: str,
        data_source: Iterable[Any],
        data_format: DataFormat,
        **kwargs: Any,
    ) -> bool:
        schema_name: str = kwargs.get("schema", "benchmark")
        conn: pyexasol.ExaConnection | None = None
        try:
            conn = self._get_connection(compression=False)
            if not conn:
                return False
            if not self._schema_created:
                if self._schema_exists(conn, schema_name):
                    self._schema_created = True
                    conn.execute(f"OPEN SCHEMA {schema_name}")
            self._log(f"Loading ({data_format}) into {schema_name}.{table_name}...")
            if data_format == DataFormat.DATA_LIST:
                conn.import_from_iterable(data_source, table=table_name)
            else:
                conn.import_from_file(data_source, table_name, import_params={})
            result = conn.execute(f"SELECT COUNT(*) FROM {table_name}")
            row_count = result.fetchone()[0]
            self._log(f"Successfully loaded {row_count:,} rows into {table_name}")
            return True
        except Exception as e:
            self._log(f"Failed to load data into {table_name}: {e}")
            return False
        finally:
            if conn:
                conn.close()

    def execute_query(
        self,
        query: str,
        query_name: str | None = None,
        return_data: bool = False,
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Execute a SQL query in Exasol using pyexasol.

        Note: timeout parameter is accepted for interface compatibility but not
        currently used by Exasol (pyexasol manages its own timeouts).
        """
        from ..debug import debug_print

        if not query_name:
            query_name = "unnamed_query"
        timer_obj: Timer | None = None
        try:
            conn = None
            try:
                conn = self._get_connection()
                debug_print(f"Executing query: {query_name}")
                if len(query) > 200:
                    debug_print(f"SQL: {query[:200]}...")
                else:
                    debug_print(f"SQL: {query}")
                with Timer(f"Query {query_name}") as timer:
                    timer_obj = timer
                    query_stripped = query.strip()
                    while query_stripped.startswith("--"):
                        newline_pos = query_stripped.find("\n")
                        if newline_pos == -1:
                            query_stripped = ""
                            break
                        query_stripped = query_stripped[newline_pos + 1 :].strip()
                    is_select_query = query_stripped.upper().startswith(
                        ("SELECT", "WITH")
                    )
                    debug_print(f"Is SELECT/WITH: {is_select_query}")
                    if is_select_query:
                        if return_data:
                            import pandas as pd

                            result = conn.execute(query)
                            data = result.fetchall() if result else []
                            columns = result.columns() if result else []
                            df = pd.DataFrame(data, columns=columns)
                            rows_returned = len(df)
                        else:
                            result = conn.execute(query)
                            rows_returned = len(result.fetchall()) if result else 0
                            df = None
                    else:
                        conn.execute(query)
                        rows_returned = (
                            conn.rowcount() if hasattr(conn, "rowcount") else 0
                        )
                        df = None
                response: dict[str, Any] = {
                    "success": True,
                    "elapsed_s": timer_obj.elapsed if timer_obj else 0,
                    "rows_returned": rows_returned,
                    "query_name": query_name,
                    "error": None,
                }
                if return_data and df is not None:
                    response["data"] = df
                    debug_print(f"Added data to response, df shape: {df.shape}")
                elif return_data:
                    debug_print(f"return_data={return_data}, but df is None")
                return response
            finally:
                if conn:
                    conn.close()
        except Exception as e:
            return {
                "success": False,
                "elapsed_s": timer_obj.elapsed if timer_obj else 0,
                "rows_returned": 0,
                "query_name": query_name,
                "error": str(e),
            }

    def get_system_metrics(self) -> dict[str, Any]:
        """Get Exasol-specific performance metrics using pyexasol."""
        metrics: dict[str, Any] = {}
        try:
            system_queries = {
                "sessions": "SELECT COUNT(*) FROM EXA_ALL_SESSIONS WHERE STATUS = 'EXECUTE'",
                "memory_usage": "SELECT * FROM EXA_SYSTEM_EVENTS WHERE EVENT_TYPE = 'MEMORY' ORDER BY MEASURE_TIME DESC LIMIT 1",
                "cache_stats": "SELECT * FROM EXA_STATISTICS.EXA_DB_SIZE_DAILY ORDER BY SNAPSHOT_ID DESC LIMIT 1",
            }
            for metric_name, query in system_queries.items():
                result = self.execute_query(query, query_name=f"metrics_{metric_name}")
                if result["success"]:
                    metrics[metric_name] = {
                        "query_time": result["elapsed_s"],
                        "rows": result["rows_returned"],
                    }
        except Exception as e:
            metrics["error"] = str(e)
        return metrics

    def teardown(self) -> bool:
        """Clean up Exasol installation."""
        success = True
        if self.setup_method == "docker":
            stop_result = self.execute_command(
                f"docker stop {self.container_name} || true"
            )
            remove_result = self.execute_command(
                f"docker rm {self.container_name} || true"
            )
            success = stop_result["success"] and remove_result["success"]
        if self.setup_config.get("cleanup_data", False):
            success = success and self.cleanup_data_directory()
        return success
