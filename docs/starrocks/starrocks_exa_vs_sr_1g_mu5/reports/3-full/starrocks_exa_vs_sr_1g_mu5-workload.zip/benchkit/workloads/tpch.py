from __future__ import annotations

"""TPC-H benchmark workload implementation."""
from datetime import timedelta
from pathlib import Path
from typing import Any

from benchkit.systems import SystemUnderTest
from benchkit.util import safe_command

from .base import Workload


class TPCH(Workload):
    """TPC-H benchmark workload implementation."""

    SUPPORTS_EXTERNAL_TABLES: bool = True

    @classmethod
    def get_python_dependencies(cls) -> list[str]:
        """Return Python packages required for TPC-H workload."""
        return ["tpchgen-cli>=0.2.0"]

    def __init__(self, config: dict[str, Any]):
        super().__init__(config)
        assert self.generator in ["dbgen", "dbgen-pipe"]

    def generate_data(
        self, output_dir: Path, force: bool = False, data_format: str = "tbl"
    ) -> bool:
        """Generate TPC-H data using tpchgen-cli (modern Python approach).

        Args:
            output_dir: Directory to store generated data
            force: Force regeneration even if data exists
            data_format: Output format - "tbl" (default) or "parquet"
        """
        if self.generator == "dbgen":
            return self._generate_with_tpchgen_cli(output_dir, force, data_format)
        return True

    def _generate_with_tpchgen_cli(
        self, output_dir: Path, force: bool = False, data_format: str = "tbl"
    ) -> bool:
        """Generate TPC-H data using tpchgen-cli (modern Python package).

        Args:
            output_dir: Directory to store generated data
            force: Force regeneration even if data exists
            data_format: Output format - "tbl" (pipe-delimited) or "parquet"
        """
        if not force:
            if data_format == "parquet":
                missing = False
                for table in self.get_table_names():
                    table_dir = output_dir / table
                    if not table_dir.exists() or not any(table_dir.glob("*.parquet")):
                        missing = True
                        break
                if not missing:
                    print("Parquet data already exists, skipping generation")
                    return True
            else:
                missing = False
                for table in self.get_table_names():
                    tbl_file = output_dir / f"{table}.tbl"
                    if not tbl_file.exists():
                        missing = True
                        break
                if not missing:
                    return True
        try:
            result = safe_command("python -m pip show tpchgen-cli")
            if not result["success"]:
                print("tpchgen-cli not found. Install with: pip install tpchgen-cli")
                return False
            output_dir.mkdir(parents=True, exist_ok=True)
            cmd = [
                "tpchgen-cli",
                f"--output-dir={output_dir}",
                f"--format={data_format}",
                f"-s {self.scale_factor}",
            ]
            if data_format == "parquet":
                num_parts = max(1, min(self.scale_factor // 10, 16))
                if num_parts < 1:
                    num_parts = 1
                cmd.append(f"--parts={num_parts}")
                print(
                    f"Generating TPC-H Parquet data (SF {self.scale_factor}, {num_parts} parts, SNAPPY compression)..."
                )
            else:
                print(
                    f"Generating TPC-H data (scale factor {self.scale_factor}) using tpchgen-cli..."
                )
            result = safe_command(" ".join(cmd), timeout=3600)
            if not result["success"]:
                print(f"tpchgen-cli failed: {result.get('stderr', 'Unknown error')}")
                return False
            if data_format == "parquet":
                missing_tables = []
                for table in self.get_table_names():
                    table_dir = output_dir / table
                    if not table_dir.exists():
                        missing_tables.append(table)
                    else:
                        parquet_files = list(table_dir.glob("*.parquet"))
                        if not parquet_files:
                            missing_tables.append(table)
                        else:
                            print(f"  ✓ {table}: {len(parquet_files)} parquet file(s)")
                if missing_tables:
                    print(f"Missing Parquet data for tables: {missing_tables}")
                    return False
            else:
                missing_files = []
                for table in self.get_table_names():
                    tbl_file = output_dir / f"{table}.tbl"
                    if not tbl_file.exists():
                        missing_files.append(str(tbl_file))
                if missing_files:
                    print(f"Missing data files: {missing_files}")
                    return False
            if data_format == "tbl":
                self._strip_trailing_delimiters(output_dir)
            print(f"Successfully generated TPC-H data in {output_dir}")
            return True
        except Exception as e:
            print(f"Data generation failed: {e}")
            return False

    def _strip_trailing_delimiters(self, data_dir: Path) -> None:
        """Strip trailing pipe delimiters from TPC-H .tbl files.

        TPC-H dbgen produces files with trailing delimiters (e.g., "0|ALGERIA|0|comment|")
        which causes issues with some databases that count this as an extra empty column.
        """
        for tbl_file in data_dir.glob("*.tbl"):
            result = safe_command(f"sed -i 's/|$//' {tbl_file}")
            if not result["success"]:
                print(
                    f"  Warning: Failed to strip trailing delimiter from {tbl_file.name}"
                )

    def create_indexes(self, system: SystemUnderTest) -> bool:
        """Create TPC-H indexes using templated setup scripts."""
        return self.execute_setup_script(system, "create_indexes.sql")

    def analyze_tables(self, system: SystemUnderTest) -> bool:
        """Analyze TPC-H tables using templated setup scripts."""
        return self.execute_setup_script(system, "analyze_tables.sql")

    def calculate_statement_timeout(
        self, statement: str, system: SystemUnderTest
    ) -> timedelta:
        statement_upper = statement.upper().strip()
        if "OPTIMIZE TABLE" in statement_upper:
            table_multipliers = {
                "LINEITEM": 1.0,
                "ORDERS": 0.25,
                "PARTSUPP": 0.13,
                "PART": 0.03,
                "CUSTOMER": 0.025,
                "SUPPLIER": 0.002,
                "NATION": 0.0001,
                "REGION": 0.0001,
            }
            multiplier = 0.1
            for table_name, table_mult in table_multipliers.items():
                if table_name in statement_upper:
                    multiplier = table_mult
                    break
            return system.estimate_execution_time(
                "OPTIMIZE TABLE", self.scale_factor * multiplier
            )
        if "MATERIALIZE STATISTICS" in statement_upper:
            return system.estimate_execution_time(
                "MATERIALIZE STATISTICS", self.scale_factor
            )
        return system.estimate_execution_time("DEFAULT", self.scale_factor)

    def prepare(self, system: SystemUnderTest) -> bool:
        """Complete TPC-H setup process: generate data, create tables, load data, create indexes, analyze tables."""
        print("Setting up TPC-H workload...")
        self._current_system = system
        schema = self.get_schema_name()
        if system.SUPPORTS_EXTERNAL_TABLES:
            return self._prepare_for_external_tables(system, schema)
        else:
            return self._prepare_traditional(system)

    def _prepare_for_external_tables(
        self, system: SystemUnderTest, schema: str
    ) -> bool:
        """Prepare TPC-H for systems that use external tables (Trino).

        For external table systems:
        1. Generate Parquet data and upload to storage
        2. Create external tables pointing to storage
        3. No INSERT-based loading needed
        """
        storage = system.get_storage_backend()
        if storage is None:
            print("ERROR: System supports external tables but has no storage backend")
            return False
        print(f"0. Generating and uploading Parquet data to {storage}...")
        if not self.generate_data_for_external_tables(storage, schema):
            print("Failed to generate/upload Parquet data")
            return False
        if not system.ensure_storage_permissions():
            print("Failed to ensure storage permissions")
            return False
        print("1. Creating external tables...")
        if not self.create_schema(system):
            print("Failed to create schema and tables")
            return False
        print("2. Skipping data load (external tables read from storage)")
        print("3. Creating indexes...")
        if not self.create_indexes(system):
            print("Failed to create indexes")
            return False
        print("4. Analyzing tables...")
        if not self.analyze_tables(system):
            print("Failed to analyze tables")
            return False
        print("TPC-H workload setup completed successfully (external tables)")
        return True

    def _prepare_traditional(self, system: SystemUnderTest) -> bool:
        """Prepare TPC-H for traditional systems (Exasol, ClickHouse).

        For traditional systems:
        1. Generate data files (.tbl format)
        2. Create tables
        3. Load data via INSERT statements
        """
        custom_data_dir = system.get_data_generation_directory(self)
        if custom_data_dir:
            self.data_dir = Path(custom_data_dir)
            print(f"Using system-provided data directory: {self.data_dir}")
        print("0. Generating TPC-H data (format: tbl)...")
        if not self.generate_data(self.data_dir, data_format="tbl"):
            print("Failed to generate TPC-H data")
            return False
        print("1. Creating tables and schema...")
        if not self.create_schema(system):
            print("Failed to create schema and tables")
            return False
        print("2. Loading data...")
        if not self.load_data(system):
            print("Failed to load data")
            return False
        print("3. Creating indexes...")
        if not self.create_indexes(system):
            print("Failed to create indexes")
            return False
        print("4. Analyzing tables...")
        if not self.analyze_tables(system):
            print("Failed to analyze tables")
            return False
        print("TPC-H workload setup completed successfully")
        return True

    def load_data(self, system: SystemUnderTest) -> bool:
        """Load TPC-H data into the database system."""
        if system.SUPPORTS_EXTERNAL_TABLES:
            print("Using external tables - no data loading needed")
            print("  Data files are read directly from storage")
            return True
        if self.generator == "dbgen-pipe" and system.SUPPORTS_STREAMLOAD:
            return self._load_data_from_pipe(system)
        else:
            return self.generate_data(self.data_dir) and self._load_data_from_files(
                system
            )

    def _load_data_from_files(self, system: SystemUnderTest) -> bool:
        schema_name = self.get_schema_name()
        for table_name in self.get_table_names():
            data_file = self.data_dir / f"{table_name}.tbl"
            if not data_file.exists():
                print(f"Data file not found: {data_file}")
                return False
            print(f"Loading {table_name}...")
            columns = self.get_table_columns(table_name)
            column_types = self.get_table_column_types(table_name)
            success = system.load_data(
                table_name,
                data_file,
                schema=schema_name,
                format=self.data_format,
                columns=columns,
                column_types=column_types,
            )
            if not success:
                print(f"Failed to load {table_name}")
                return False
            try:
                data_file.unlink()
                print(f"  ✓ Cleaned up {data_file.name}")
            except Exception as e:
                print(f"  Warning: Could not delete {data_file.name}: {e}")
        try:
            if self.data_dir.exists() and (not any(self.data_dir.iterdir())):
                self.data_dir.rmdir()
                print(f"Cleaned up empty data directory: {self.data_dir}")
        except Exception as e:
            print(f"Warning: Could not remove data directory: {e}")
        return True

    def _load_data_from_pipe(self, system: SystemUnderTest) -> bool:
        from benchkit.common import DataFormat, DbGenPipe

        schema_name = self.get_schema_name()
        for table_name in self.get_table_names():
            print(f"Loading {table_name}...")
            with DbGenPipe(table_name, self.scale_factor) as dbgen:
                if not system.load_data_from_iterable(
                    table_name, dbgen.file_stream(), DataFormat.CSV, schema=schema_name
                ):
                    print(f"Failed to load {table_name}")
                    return False
        return True

    def run_workload(
        self,
        system: SystemUnderTest,
        query_names: list[str],
        runs_per_query: int = 3,
        warmup_runs: int = 1,
        num_streams: int = 1,
        randomize: bool = False,
        random_seed: int | None = None,
    ) -> dict[str, list[dict[str, Any]]]:
        """Execute the TPC-H workload with system context for template resolution."""
        self._current_system = system
        variant_for_system = self._get_query_variant_for_system(system)
        result_dict = super().run_workload(
            system,
            query_names,
            runs_per_query,
            warmup_runs,
            num_streams,
            randomize,
            random_seed,
        )
        for result in result_dict["measured"]:
            result["variant"] = variant_for_system
        for result in result_dict["warmup"]:
            result["variant"] = variant_for_system
        return result_dict

    def get_workload_description(self) -> dict[str, Any]:
        """Return TPC-H workload description."""
        return {
            "short": "TPC-H is an industry-standard decision support benchmark simulating complex business analytics queries",
            "full": "TPC-H is a decision support benchmark that consists of a suite of business-oriented ad-hoc queries\n            and concurrent data modifications. The queries and data are chosen to have broad industry-wide relevance.\n            This benchmark illustrates decision support systems that examine large volumes of data, execute queries with\n            a high degree of complexity, and give answers to critical business questions. The benchmark models a wholesale\n            supplier with a distribution network across multiple regions.",
            "characteristics": [
                "22 complex analytical queries",
                "8 tables with varying cardinality",
                "Queries involve multi-table joins, aggregations, and subqueries",
                "Simulates real-world business intelligence workloads",
            ],
        }

    def get_table_names(self) -> list[str]:
        """Get list of TPC-H table names."""
        return [
            "nation",
            "region",
            "part",
            "supplier",
            "partsupp",
            "customer",
            "orders",
            "lineitem",
        ]

    def get_table_columns(self, table_name: str) -> list[str]:
        """Get column names for a TPC-H table."""
        table_columns = {
            "nation": ["n_nationkey", "n_name", "n_regionkey", "n_comment"],
            "region": ["r_regionkey", "r_name", "r_comment"],
            "part": [
                "p_partkey",
                "p_name",
                "p_mfgr",
                "p_brand",
                "p_type",
                "p_size",
                "p_container",
                "p_retailprice",
                "p_comment",
            ],
            "supplier": [
                "s_suppkey",
                "s_name",
                "s_address",
                "s_nationkey",
                "s_phone",
                "s_acctbal",
                "s_comment",
            ],
            "partsupp": [
                "ps_partkey",
                "ps_suppkey",
                "ps_availqty",
                "ps_supplycost",
                "ps_comment",
            ],
            "customer": [
                "c_custkey",
                "c_name",
                "c_address",
                "c_nationkey",
                "c_phone",
                "c_acctbal",
                "c_mktsegment",
                "c_comment",
            ],
            "orders": [
                "o_orderkey",
                "o_custkey",
                "o_orderstatus",
                "o_totalprice",
                "o_orderdate",
                "o_orderpriority",
                "o_clerk",
                "o_shippriority",
                "o_comment",
            ],
            "lineitem": [
                "l_orderkey",
                "l_partkey",
                "l_suppkey",
                "l_linenumber",
                "l_quantity",
                "l_extendedprice",
                "l_discount",
                "l_tax",
                "l_returnflag",
                "l_linestatus",
                "l_shipdate",
                "l_commitdate",
                "l_receiptdate",
                "l_shipinstruct",
                "l_shipmode",
                "l_comment",
            ],
        }
        return table_columns.get(table_name, [])

    def get_table_column_types(self, table_name: str) -> list[str]:
        """Get column types for a TPC-H table.

        Returns simplified type identifiers that can be used for type conversion:
        - INTEGER: 32-bit integer
        - BIGINT: 64-bit integer
        - DECIMAL: Fixed-point decimal number
        - VARCHAR: Variable-length string
        - DATE: Date without time
        """
        table_column_types = {
            "nation": ["INTEGER", "VARCHAR", "INTEGER", "VARCHAR"],
            "region": ["INTEGER", "VARCHAR", "VARCHAR"],
            "part": [
                "INTEGER",
                "VARCHAR",
                "VARCHAR",
                "VARCHAR",
                "VARCHAR",
                "INTEGER",
                "VARCHAR",
                "DECIMAL",
                "VARCHAR",
            ],
            "supplier": [
                "INTEGER",
                "VARCHAR",
                "VARCHAR",
                "INTEGER",
                "VARCHAR",
                "DECIMAL",
                "VARCHAR",
            ],
            "partsupp": ["INTEGER", "INTEGER", "INTEGER", "DECIMAL", "VARCHAR"],
            "customer": [
                "INTEGER",
                "VARCHAR",
                "VARCHAR",
                "INTEGER",
                "VARCHAR",
                "DECIMAL",
                "VARCHAR",
                "VARCHAR",
            ],
            "orders": [
                "BIGINT",
                "INTEGER",
                "VARCHAR",
                "DECIMAL",
                "DATE",
                "VARCHAR",
                "VARCHAR",
                "INTEGER",
                "VARCHAR",
            ],
            "lineitem": [
                "BIGINT",
                "INTEGER",
                "INTEGER",
                "INTEGER",
                "DECIMAL",
                "DECIMAL",
                "DECIMAL",
                "DECIMAL",
                "VARCHAR",
                "VARCHAR",
                "DATE",
                "DATE",
                "DATE",
                "VARCHAR",
                "VARCHAR",
                "VARCHAR",
            ],
        }
        return table_column_types.get(table_name, [])

    def get_external_table_columns(self, table_name: str) -> list[tuple[str, str]]:
        """Return column definitions for TPC-H external tables.

        Combines column names with their type identifiers.

        Args:
            table_name: Name of the TPC-H table

        Returns:
            List of (column_name, column_type) tuples
        """
        columns = self.get_table_columns(table_name)
        types = self.get_table_column_types(table_name)
        return list(zip(columns, types, strict=True))

    def get_table_info(self) -> dict[str, dict[str, Any]]:
        """Return TPC-H table metadata."""
        return {
            "nation": {
                "description": "Nations/countries (25 rows)",
                "columns": self.get_table_columns("nation"),
                "cardinality_sf1": 25,
                "relationships": ["Foreign key to region"],
            },
            "region": {
                "description": "Geographic regions (5 rows)",
                "columns": self.get_table_columns("region"),
                "cardinality_sf1": 5,
                "relationships": [],
            },
            "part": {
                "description": "Parts/products catalog",
                "columns": self.get_table_columns("part"),
                "cardinality_sf1": 200000,
                "relationships": [],
            },
            "supplier": {
                "description": "Suppliers/vendors",
                "columns": self.get_table_columns("supplier"),
                "cardinality_sf1": 10000,
                "relationships": ["Foreign key to nation"],
            },
            "partsupp": {
                "description": "Parts supplied by suppliers (association table)",
                "columns": self.get_table_columns("partsupp"),
                "cardinality_sf1": 800000,
                "relationships": ["Foreign keys to part and supplier"],
            },
            "customer": {
                "description": "Customers/buyers",
                "columns": self.get_table_columns("customer"),
                "cardinality_sf1": 150000,
                "relationships": ["Foreign key to nation"],
            },
            "orders": {
                "description": "Customer orders",
                "columns": self.get_table_columns("orders"),
                "cardinality_sf1": 1500000,
                "relationships": ["Foreign key to customer"],
            },
            "lineitem": {
                "description": "Order line items (largest table)",
                "columns": self.get_table_columns("lineitem"),
                "cardinality_sf1": 6001215,
                "relationships": ["Foreign keys to orders, part, supplier, partsupp"],
            },
        }

    def get_setup_script_info(self) -> dict[str, str]:
        """Return TPC-H setup step descriptions."""
        return {
            "schema_creation": "Create 8 TPC-H tables with system-optimized data types",
            "index_creation": "Create indexes on foreign keys and join columns",
            "table_analysis": "Update database statistics for query optimizer",
        }

    def get_all_query_names(self) -> list[str]:
        """Get list of all TPC-H query names."""
        return [f"Q{i:02d}" for i in range(1, 23)]

    def get_schema_name(self) -> str:
        """Get the schema name for TPC-H workload."""
        if self._current_system is None:
            return "benchmark"
        if hasattr(self._current_system, "schema") and self._current_system.schema:
            return str(self._current_system.schema)
        elif (
            hasattr(self._current_system, "database") and self._current_system.database
        ):
            return str(self._current_system.database)
        else:
            return "benchmark"

    def estimate_filesystem_usage_gb(self, system: SystemUnderTest) -> int:
        """
        Estimate required storage size for TPC-H data at specific scale factor

        # SF1 ≈ 1GB, add 20% safety margin
        # estimated_gb = max(int(scale_factor * 1.3), 3)
        """
        if system.SUPPORTS_STREAMLOAD and self.generator == "dbgen-pipe":
            return 0

        def scale_multiplier(sf: float) -> float:
            if sf <= 10:
                return 2.0
            val = 1.3 + 0.7 / (1.0 + (sf / 26.853725639548) ** 2.5965770266157073)
            return float(max(1.3, min(val, 2.0)))

        def estimate_gb(sf: float) -> int:
            return int(max(sf * scale_multiplier(sf), 3.0))

        return estimate_gb(float(self.scale_factor))

    def generate_data_for_external_tables(self, storage: Any, schema: str) -> bool:
        """Generate Parquet data and upload to storage for external table access.

        This is used by systems that support external tables (like Trino).
        Generates Parquet files locally, then uploads them to the storage backend.

        Args:
            storage: StorageBackend instance (LocalStorage or S3Storage)
            schema: Schema name for the data

        Returns:
            True if generation and upload successful, False otherwise
        """
        import tempfile

        try:
            if not storage.prepare():
                print("Failed to prepare storage backend")
                return False
            with tempfile.TemporaryDirectory(prefix="tpch_parquet_") as temp_dir:
                temp_path = Path(temp_dir)
                print(f"Generating TPC-H Parquet data (SF {self.scale_factor})...")
                if not self._generate_with_tpchgen_cli(
                    temp_path, force=False, data_format="parquet"
                ):
                    print("Failed to generate Parquet data")
                    return False
                for table_name in self.get_table_names():
                    table_dir = temp_path / table_name
                    if not table_dir.exists():
                        print(f"Table data not found: {table_dir}")
                        return False
                    print(f"Uploading {table_name} to storage...")
                    if not storage.upload_data(table_dir, schema, table_name):
                        print(f"Failed to upload {table_name}")
                        return False
            print(f"Successfully uploaded TPC-H data to {storage}")
            return True
        except Exception as e:
            print(f"Failed to generate/upload external table data: {e}")
            import traceback

            traceback.print_exc()
            return False
