"""Debug utilities for the benchmark framework."""

import os
from typing import Any

_debug_enabled = False


def set_debug(enabled: bool) -> None:
    """Set global debug state."""
    global _debug_enabled
    _debug_enabled = enabled
    if enabled:
        os.environ["BENCHKIT_DEBUG"] = "1"
    else:
        os.environ.pop("BENCHKIT_DEBUG", None)


def is_debug_enabled() -> bool:
    """Check if debug mode is enabled."""
    global _debug_enabled
    if not _debug_enabled and os.getenv("BENCHKIT_DEBUG", "").lower() in (
        "1",
        "true",
        "yes",
    ):
        _debug_enabled = True
    return _debug_enabled


def _get_task_prefix() -> str:
    """
    Get the task name prefix for output tagging during parallel execution.

    This function provides defense-in-depth for debug output. When running
    in parallel mode, debug output needs to be tagged with the correct
    system name to avoid race conditions with redirect_stdout.

    Returns:
        "[task_name] " prefix if running in a parallel task, empty string otherwise.
    """
    try:
        from .run.parallel_executor import get_current_task_name

        task_name = get_current_task_name()
        if task_name:
            return f"[{task_name}] "
    except ImportError:
        pass
    return ""


def debug_print(message: str, **kwargs: Any) -> None:
    """Print debug message if debug mode is enabled."""
    if is_debug_enabled():
        prefix = _get_task_prefix()
        print(f"{prefix}[DEBUG] {message}", **kwargs)
