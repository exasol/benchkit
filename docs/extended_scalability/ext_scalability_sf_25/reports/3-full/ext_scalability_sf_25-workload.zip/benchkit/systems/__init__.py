"""Database system implementations."""

from .base import SystemUnderTest
from .duckdb import DuckdbSystem

SYSTEM_IMPLEMENTATIONS = {
    "duckdb": DuckdbSystem,
}


def create_system(config: dict) -> SystemUnderTest:
    """Create a system instance from configuration."""
    kind = config.get("kind")
    if kind not in SYSTEM_IMPLEMENTATIONS:
        available = ", ".join(SYSTEM_IMPLEMENTATIONS.keys())
        raise ValueError(f"Unsupported system: {kind}. Available: {available}")
    return SYSTEM_IMPLEMENTATIONS[kind](config)


__all__ = ["SystemUnderTest", "create_system", "SYSTEM_IMPLEMENTATIONS"]
