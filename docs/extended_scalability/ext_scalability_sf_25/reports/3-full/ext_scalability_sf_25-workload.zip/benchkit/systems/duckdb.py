from __future__ import annotations

"""DuckDB embedded analytical database system implementation."""
import tempfile
from collections.abc import Callable, Iterable
from pathlib import Path
from typing import TYPE_CHECKING, Any

try:
    import duckdb
except ModuleNotFoundError:
    duckdb = None
from benchkit.common import DataFormat

from ..util import Timer
from .base import SystemUnderTest

if TYPE_CHECKING:
    pass


class DuckdbSystem(SystemUnderTest):
    """DuckDB embedded analytical database system implementation.

    DuckDB is an embedded database that runs in-process (no separate server).
    This makes it simpler than other systems but requires different connection
    lifecycle management.

    Key differences from server-based databases:
    - No Docker support (runs directly in Python process)
    - Single persistent connection stored in _connection
    - Database file created lazily on first connection
    - No network ports required
    """

    SUPPORTS_MULTINODE = False
    SUPPORTS_STREAMLOAD = True
    SUPPORTS_EXTERNAL_TABLES = False
    LOAD_TIMEOUT_MULTIPLIER = 0.6

    @classmethod
    def get_python_dependencies(cls) -> list[str]:
        """Return Python packages required by DuckDB system."""
        return ["duckdb>=1.0.0"]

    @classmethod
    def _get_connection_defaults(cls) -> dict[str, Any]:
        """Return DuckDB-specific connection defaults."""
        return {
            "port": None,
            "username": None,
            "password": "",
            "schema_key": "database",
            "schema": "main",
        }

    @classmethod
    def get_valid_setup_methods(cls) -> list[str]:
        """Return valid setup methods for DuckDB.

        DuckDB is embedded - no Docker support, only native/preinstalled.
        """
        return ["native", "preinstalled"]

    @classmethod
    def get_required_ports(cls) -> dict[str, int]:
        """Return ports required by DuckDB (none - embedded database)."""
        return {}

    def get_storage_config(self) -> tuple[str | None, str]:
        """Return DuckDB-specific storage configuration."""
        return ("/data/duckdb", "ubuntu:ubuntu")

    def __init__(
        self,
        config: dict[str, Any],
        output_callback: Callable[[str], None] | None = None,
        workload_config: dict[str, Any] | None = None,
    ):
        super().__init__(config, output_callback, workload_config)
        self.setup_method = self.setup_config.get("method", "native")
        explicit_db_path = self.setup_config.get("database_path")
        if explicit_db_path:
            if explicit_db_path == ":memory:":
                self.database_path: Path | str = ":memory:"
            else:
                self.database_path = Path(explicit_db_path)
        else:
            self.database_path = Path(str(self.data_dir)) / f"{self.name}.duckdb"
        extra_config = self.setup_config.get("extra") or {}
        self.memory_limit = extra_config.get("memory_limit")
        self.threads = extra_config.get("threads")
        self._connection: Any = None
        self.schema = self.setup_config.get("schema", "main")

    def _get_connection(self) -> Any:
        """Get or create a DuckDB connection.

        DuckDB connections are lazily created on first use.
        The connection is reused for all subsequent operations.
        """
        if self._connection is not None:
            return self._connection
        if duckdb is None:
            raise RuntimeError(
                "duckdb package not installed. Install with: pip install duckdb>=0.8.0"
            )
        db_path = str(self.database_path)
        self._log(f"Opening DuckDB database: {db_path}")
        self._connection = duckdb.connect(db_path)
        if self.memory_limit:
            self._connection.execute(f"SET memory_limit = '{self.memory_limit}'")
            self._log(f"  Set memory_limit = {self.memory_limit}")
        if self.threads:
            self._connection.execute(f"SET threads = {self.threads}")
            self._log(f"  Set threads = {self.threads}")
        return self._connection

    def _close_connection(self) -> None:
        """Close the DuckDB connection if open."""
        if self._connection is not None:
            try:
                self._connection.close()
            except Exception as e:
                self._log(f"Warning: Error closing DuckDB connection: {e}")
            finally:
                self._connection = None

    def is_healthy(self, quiet: bool = False) -> bool:
        """Check if DuckDB is accessible and responding."""
        if self._should_execute_remotely():
            return self._is_healthy_remote(quiet)
        try:
            if duckdb is None:
                if not quiet:
                    self._log("duckdb package not available")
                return False
            conn = self._get_connection()
            result = conn.execute("SELECT 1").fetchone()
            return result is not None and result[0] == 1
        except Exception as e:
            if not quiet:
                self._log(f"DuckDB health check failed: {e}")
            return False

    def _is_healthy_remote(self, quiet: bool = False) -> bool:
        """Check DuckDB health on remote instance."""
        if not self._cloud_instance_manager:
            return False
        try:
            db_path = str(self.database_path)
            check_cmd = f'''python3 -c "import duckdb; conn = duckdb.connect('{db_path}'); print(conn.execute('SELECT 1').fetchone()[0])"'''
            result = self._cloud_instance_manager.run_remote_command(
                check_cmd, timeout=30, debug=False
            )
            if result.get("success"):
                stdout: str = result.get("stdout", "").strip()
                return bool(stdout == "1")
            return False
        except Exception as e:
            if not quiet:
                self._log(f"Remote DuckDB health check failed: {e}")
            return False

    def create_schema(self, schema_name: str) -> bool:
        """Create a schema in DuckDB."""
        try:
            conn = self._get_connection()
            conn.execute(f"CREATE SCHEMA IF NOT EXISTS {schema_name}")
            self.schema = schema_name
            self._log(f"Created schema: {schema_name}")
            return True
        except Exception as e:
            self._log(f"Failed to create schema '{schema_name}': {e}")
            return False

    def load_data(self, table_name: str, data_path: Path, **kwargs: Any) -> bool:
        """Load data into DuckDB table using native file readers.

        DuckDB has highly optimized native readers for various formats:
        - Parquet: read_parquet()
        - CSV: read_csv_auto()
        - TSV: read_csv_auto() with delimiter
        - TBL (pipe-delimited): read_csv_auto() with delimiter
        """
        schema_name = kwargs.get("schema", self.schema or "main")
        data_format = kwargs.get("format", "csv")
        try:
            conn = self._get_connection()
            full_table_name = f"{schema_name}.{table_name}"
            self._log(
                f"Loading {data_path} into {full_table_name} (format: {data_format})..."
            )
            if data_format == "parquet":
                query = f"\n                    INSERT INTO {full_table_name}\n                    SELECT * FROM read_parquet('{data_path}')\n                "
            elif data_format == "tsv":
                query = f"\n                    INSERT INTO {full_table_name}\n                    SELECT * FROM read_csv_auto(\n                        '{data_path}',\n                        delim = '\t',\n                        header = false\n                    )\n                "
            elif data_format == "tbl":
                table_cols_result = conn.execute(
                    f"\n                    SELECT column_name FROM information_schema.columns\n                    WHERE table_schema = '{schema_name}' AND table_name = '{table_name}'\n                    ORDER BY ordinal_position\n                "
                ).fetchall()
                num_cols = len(table_cols_result)
                sample = conn.execute(
                    f"\n                    SELECT * FROM read_csv_auto(\n                        '{data_path}',\n                        delim = '|',\n                        header = false\n                    ) LIMIT 1\n                "
                ).fetchdf()
                file_col_names = sample.columns.tolist()
                col_list = ", ".join(file_col_names[:num_cols])
                query = f"\n                    INSERT INTO {full_table_name}\n                    SELECT {col_list} FROM read_csv_auto(\n                        '{data_path}',\n                        delim = '|',\n                        header = false\n                    )\n                "
            else:
                query = f"\n                    INSERT INTO {full_table_name}\n                    SELECT * FROM read_csv_auto(\n                        '{data_path}',\n                        header = false\n                    )\n                "
            conn.execute(query)
            count_result = conn.execute(
                f"SELECT COUNT(*) FROM {full_table_name}"
            ).fetchone()
            row_count = count_result[0] if count_result else 0
            self._log(f"Successfully loaded {row_count:,} rows into {table_name}")
            return True
        except Exception as e:
            self._log(f"Failed to load data into {table_name}: {e}")
            return False

    def load_data_from_iterable(
        self,
        table_name: str,
        data_source: Iterable[Any],
        data_format: DataFormat,
        **kwargs: Any,
    ) -> bool:
        """Load data into DuckDB from an iterable.

        Supports:
        - DATA_LIST: Direct insertion using executemany
        - Text formats (CSV, TSV, TBL): Write to temp file then load
        """
        schema_name = kwargs.get("schema", self.schema or "main")
        full_table_name = f"{schema_name}.{table_name}"
        try:
            conn = self._get_connection()
            if data_format == DataFormat.DATA_LIST:
                data_list = list(data_source)
                if not data_list:
                    self._log(f"No data to load into {table_name}")
                    return True
                first_row = data_list[0]
                placeholders = ", ".join(["?"] * len(first_row))
                insert_sql = f"INSERT INTO {full_table_name} VALUES ({placeholders})"
                conn.executemany(insert_sql, data_list)
                self._log(f"Loaded {len(data_list):,} rows into {table_name}")
                return True
            else:
                if data_format == DataFormat.TSV:
                    delimiter = "\t"
                    suffix = ".tsv"
                elif data_format == DataFormat.TBL:
                    delimiter = "|"
                    suffix = ".tbl"
                else:
                    delimiter = ","
                    suffix = ".csv"
                with tempfile.NamedTemporaryFile(
                    mode="w", suffix=suffix, delete=False
                ) as f:
                    for row in data_source:
                        if isinstance(row, str):
                            f.write(row)
                            if not row.endswith("\n"):
                                f.write("\n")
                        else:
                            f.write(delimiter.join(str(v) for v in row) + "\n")
                    temp_path = f.name
                try:
                    query = f"\n                        INSERT INTO {full_table_name}\n                        SELECT * FROM read_csv_auto(\n                            '{temp_path}',\n                            delim = '{delimiter}',\n                            header = false\n                        )\n                    "
                    conn.execute(query)
                    count_result = conn.execute(
                        f"SELECT COUNT(*) FROM {full_table_name}"
                    ).fetchone()
                    row_count = count_result[0] if count_result else 0
                    self._log(f"Loaded {row_count:,} rows into {table_name}")
                    return True
                finally:
                    Path(temp_path).unlink(missing_ok=True)
        except Exception as e:
            self._log(f"Failed to load data from iterable into {table_name}: {e}")
            return False

    def execute_query(
        self,
        query: str,
        query_name: str | None = None,
        return_data: bool = False,
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Execute a SQL query and return timing and result information.

        Args:
            query: SQL query to execute
            query_name: Optional name for the query (for logging)
            return_data: If True, include result data in response as DataFrame
            timeout: Ignored for DuckDB (no query timeout support in Python API)

        Returns:
            Dictionary with success, elapsed_s, rows_returned, error, query_name, data
        """
        from ..debug import debug_print

        if not query_name:
            query_name = "unnamed_query"
        try:
            debug_print(f"Executing query: {query_name}")
            if len(query) > 200:
                debug_print(f"SQL: {query[:200]}...")
            else:
                debug_print(f"SQL: {query}")
            with Timer(f"Query {query_name}") as timer:
                conn = self._get_connection()
                schema_to_use = getattr(self, "_active_schema", None) or self.schema
                if schema_to_use and schema_to_use != "main":
                    conn.execute(f"SET search_path = '{schema_to_use}'")
                query_stripped = query.strip()
                while query_stripped.startswith("--"):
                    newline_pos = query_stripped.find("\n")
                    if newline_pos == -1:
                        query_stripped = ""
                        break
                    query_stripped = query_stripped[newline_pos + 1 :].strip()
                result = conn.execute(query)
                is_select = query_stripped.upper().startswith(
                    ("SELECT", "WITH", "SHOW", "DESCRIBE", "EXPLAIN")
                )
                if is_select:
                    if return_data:
                        df = result.fetchdf()
                        rows_returned = len(df)
                    else:
                        rows = result.fetchall()
                        rows_returned = len(rows)
                        df = None
                else:
                    rows_returned = 0
                    df = None
            response: dict[str, Any] = {
                "success": True,
                "elapsed_s": timer.elapsed,
                "rows_returned": rows_returned,
                "query_name": query_name,
                "error": None,
            }
            if return_data and df is not None:
                response["data"] = df
            return response
        except Exception as e:
            elapsed = timer.elapsed if "timer" in locals() else 0
            return {
                "success": False,
                "elapsed_s": elapsed,
                "rows_returned": 0,
                "query_name": query_name,
                "error": str(e),
            }

    def get_system_metrics(self) -> dict[str, Any]:
        """Get DuckDB-specific system metrics."""
        metrics: dict[str, Any] = {}
        try:
            conn = self._get_connection()
            if self.database_path != ":memory:":
                db_path = Path(self.database_path)
                if db_path.exists():
                    size_bytes = db_path.stat().st_size
                    metrics["database_size_bytes"] = size_bytes
                    metrics["database_size_mb"] = size_bytes / (1024 * 1024)
            if self.memory_limit:
                metrics["memory_limit"] = self.memory_limit
            if self.threads:
                metrics["threads"] = self.threads
            if duckdb:
                metrics["duckdb_version"] = duckdb.__version__
            try:
                result = conn.execute("SELECT current_setting('threads')").fetchone()
                if result:
                    metrics["current_threads"] = result[0]
            except Exception:
                pass
            try:
                result = conn.execute(
                    "SELECT current_setting('memory_limit')"
                ).fetchone()
                if result:
                    metrics["current_memory_limit"] = result[0]
            except Exception:
                pass
        except Exception as e:
            metrics["error"] = str(e)
        return metrics

    def teardown(self) -> bool:
        """Clean up DuckDB resources."""
        success = True
        self._close_connection()
        self._is_running = False
        if self.setup_config.get("cleanup_data", False):
            if self.database_path != ":memory:":
                db_path = Path(self.database_path)
                if db_path.exists():
                    try:
                        db_path.unlink()
                        self._log(f"Removed database file: {db_path}")
                    except Exception as e:
                        self._log(f"Failed to remove database file: {e}")
                        success = False
            success = success and self.cleanup_data_directory()
        return success

    def _should_execute_remotely(self) -> bool:
        """Check if commands should execute on remote cloud instance.

        DuckDB is embedded and runs in-process, but when deployed to AWS,
        the benchmark package is transferred to the remote instance and
        executed there. In this case, setup commands (like creating data
        directories) should run on the remote instance.
        """
        return self._cloud_instance_manager is not None
