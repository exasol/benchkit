"""Base classes for benchmark workloads."""

import random
import threading
from abc import ABC, abstractmethod
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import timedelta
from pathlib import Path
from typing import Any

from jinja2 import Environment, FileSystemLoader

from ..systems.base import SystemUnderTest


class Workload(ABC):
    """Abstract base class for benchmark workloads."""

    SUPPORTS_EXTERNAL_TABLES: bool = False

    def __init__(self, config: dict[str, Any]):
        self.name = config["name"]
        self.scale_factor = config.get("scale_factor", 1)
        self.config = config
        self.data_dir = Path(f"data/{self.name}/sf{self.scale_factor}")
        self.workload_dir = (
            Path(__file__).parent.parent.parent / "workloads" / self.name
        )
        self.template_env: Environment | None = None
        self._current_system: SystemUnderTest | None = None
        self.data_format = config.get("data_format", "tbl")
        self.variant = config.get("variant", "official")
        self.generator: str = config.get("generator", "dbgen")
        self.system_variants = config.get("system_variants") or {}
        queries_config = config.get("queries", {})
        self.queries_include = queries_config.get("include", [])
        self.queries_exclude = queries_config.get("exclude", [])

    def get_template_env(self) -> Environment:
        """Get the workload's jinja2 template environment"""
        if not self.template_env:
            self.template_env = Environment(
                loader=FileSystemLoader(
                    [self.workload_dir / "queries", self.workload_dir / "setup"]
                ),
                trim_blocks=True,
                lstrip_blocks=True,
            )
        return self.template_env

    def display_name(self) -> str:
        """Return user-friendly display name for workload"""
        return f"{self.name} SF{self.scale_factor}"

    def safe_display_name(self) -> str:
        """Return filesystem-friendly full name for workload"""
        from re import sub

        return sub("[^0-9a-zA-Z_]", "_", self.display_name())

    @abstractmethod
    def estimate_filesystem_usage_gb(self, system: SystemUnderTest) -> int:
        """
        Estimate file system usage for generating workload data before load.

        Args:
            system: the system to receive the workload. System features may
                    affect required file size (0 for streaming load)
        Returns:
            Estimated file system usage for generated data in GB
        """
        pass

    def create_schema(self, system: SystemUnderTest) -> bool:
        """
        Create database schema and tables for the workload.

        Args:
            system: System under test to create schema on

        Returns:
            True if schema creation successful, False otherwise
        """
        schema: str = self.get_schema_name()
        if hasattr(system, "create_schema"):
            if not system.create_schema(schema):
                print(f"        Failed to create schema '{schema}'")
                return False
            print(f"        ✓ Schema '{schema}' ready")
        if not self.execute_setup_script(system, "create_tables.sql"):
            return False
        print("        ✓ Tables created")
        return True

    @abstractmethod
    def load_data(self, system: SystemUnderTest) -> bool:
        """
        Load generated data into the database system.

        Args:
            system: System under test to load data into

        Returns:
            True if data loading successful, False otherwise
        """
        pass

    def get_external_table_format(self) -> str:
        """Return data format for external tables.

        Override in subclasses that support external tables.

        Returns:
            Data format string (e.g., 'PARQUET', 'CSV', 'ORC')
        """
        return "PARQUET"

    def get_external_table_columns(self, table_name: str) -> list[tuple[str, str]]:
        """Return column definitions for external table.

        Override in subclasses that support external tables.

        Args:
            table_name: Name of the table

        Returns:
            List of (column_name, column_type) tuples
        """
        raise NotImplementedError(
            f"Workload {self.name} must implement get_external_table_columns to support external tables"
        )

    def get_table_names(self) -> list[str]:
        """Get list of table names in this workload.

        Override in subclasses.

        Returns:
            List of table names
        """
        raise NotImplementedError(
            f"Workload {self.name} must implement get_table_names"
        )

    def generate_data_for_external_tables(self, storage: Any, schema: str) -> bool:
        """Generate data and upload to storage backend for external table access.

        This is the entry point for systems that use external tables.
        Generates data locally (e.g., Parquet files), then uploads to storage.

        Override in subclasses that support external tables.

        Args:
            storage: StorageBackend instance (LocalStorage or S3Storage)
            schema: Schema name for the data

        Returns:
            True if generation and upload successful, False otherwise
        """
        raise NotImplementedError(
            f"Workload {self.name} must implement generate_data_for_external_tables to support external tables"
        )

    def get_data_locations(self, storage: Any, schema: str) -> dict[str, str]:
        """Get data location URLs for all tables.

        Used to pass to SQL templates for external table creation.

        Args:
            storage: StorageBackend instance
            schema: Schema name

        Returns:
            Dictionary mapping table names to their data location URLs
        """
        return {
            table: storage.get_data_location(schema, table)
            for table in self.get_table_names()
        }

    def get_data_format_spec(self) -> dict[str, Any]:
        """Return data format specification for loading.

        Systems use this to understand how to parse and load workload data.
        Override in subclasses that have specific format requirements.

        Returns:
            Dictionary with format specification:
            - format: Data format (csv, tsv, parquet, tbl)
            - delimiter: Field delimiter character (for delimited formats)
            - has_header: Whether data files have headers
            - compression: Compression type (gzip, none)
        """
        return {
            "format": self.data_format,
            "delimiter": "|" if self.data_format == "tbl" else ",",
            "has_header": False,
            "compression": "none",
        }

    def get_timestamp_columns(self) -> set[str]:
        """Return column names that contain Unix timestamp values.

        Systems use this for automatic timestamp conversion during data loading.
        Override in subclasses with timestamp columns.

        Returns:
            Set of column names that are Unix timestamps (seconds since epoch)
        """
        return set()

    def get_date_columns(self) -> set[str]:
        """Return column names that contain date values as days since epoch.

        Systems use this for automatic date conversion during data loading.
        Override in subclasses with date columns stored as integers.

        Returns:
            Set of column names that are dates (days since 1970-01-01)
        """
        return set()

    def get_expected_row_counts(self) -> dict[str, int]:
        """Return expected row counts per table for validation.

        Systems use this to verify data loading succeeded.
        Override in subclasses with known row counts.

        Returns:
            Dictionary mapping table names to expected row counts
        """
        return {}

    def get_table_columns(self, table_name: str) -> list[str]:
        """Get column names for a specific table.

        Override in subclasses with table schemas.

        Args:
            table_name: Name of the table

        Returns:
            List of column names in order
        """
        return []

    def get_required_package_files(self) -> list[str]:
        """Return additional files needed for packaging.

        Override in subclasses that need extra files beyond the workload module.

        Returns:
            List of relative file paths to include in packages
        """
        return []

    def supports_parallel_loading(self) -> bool:
        """Return whether this workload supports parallel data loading.

        Some workloads (like ClickBench) have pre-partitioned data that
        can be loaded in parallel for better performance.

        Returns:
            True if parallel loading is supported
        """
        return False

    def get_parallel_load_config(self) -> dict[str, Any]:
        """Return configuration for parallel data loading.

        Only called if supports_parallel_loading() returns True.
        Override in subclasses that support parallel loading.

        Returns:
            Dictionary with parallel loading configuration:
            - num_partitions: Number of data partitions
            - partition_url_pattern: URL pattern with {} for partition number
            - default_workers: Default number of parallel workers
        """
        return {}

    def get_queries(
        self, system: SystemUnderTest | None = None, use_verify_variants: bool = False
    ) -> dict[str, str]:
        """
        Get the benchmark queries.

        Args:
            system: Optional system under test for query template resolution
            use_verify_variants: If True, prefer verification variants that add
                                 deterministic ORDER BY clauses for result comparison

        Returns:
            Dictionary mapping query names to SQL text
        """
        target_system = system or self._current_system
        if target_system is None:
            raise ValueError(
                "System must be provided either as parameter or stored from previous call"
            )
        self._current_system = target_system
        variant = self._get_query_variant_for_system(target_system)
        if variant != "official":
            print(f"Loading '{variant}' variant queries for {target_system.kind}")
        queries = {}
        for query_name in self.get_included_queries():
            queries[query_name] = self._get_query_sql(
                query_name, target_system, use_verify_variants
            )
        return queries

    @abstractmethod
    def get_all_query_names(self) -> list[str]:
        """
        Get list of all query names available in this workload.

        Returns:
            List of query names (e.g., ["Q01", "Q02", ...])
        """
        pass

    def get_included_queries(self) -> list[str]:
        all_queries = self.get_all_query_names()
        if self.queries_include:
            return [q for q in all_queries if q in self.queries_include]
        elif self.queries_exclude:
            return [q for q in all_queries if q not in self.queries_exclude]
        else:
            return all_queries

    def run_query(
        self, system: SystemUnderTest, query_name: str, query_sql: str
    ) -> dict[str, Any]:
        """
        Execute a single benchmark query.

        Args:
            system: System under test
            query_name: Name of the query
            query_sql: SQL text to execute

        Returns:
            Query execution result dictionary
        """
        schema_name = self.get_schema_name()
        formatted_sql = query_sql.format(schema=schema_name)
        return system.execute_query(formatted_sql, query_name=query_name)

    def run_workload(
        self,
        system: SystemUnderTest,
        query_names: list[str],
        runs_per_query: int = 3,
        warmup_runs: int = 1,
        num_streams: int = 1,
        randomize: bool = False,
        random_seed: int | None = None,
    ) -> dict[str, list[dict[str, Any]]]:
        """
        Execute the full workload against a system.

        Args:
            system: System under test
            query_names: List of query names to execute
            runs_per_query: Number of measured runs per query
            warmup_runs: Number of warmup runs per query
            num_streams: Number of concurrent execution streams (1 = sequential)
            randomize: Whether to randomize query execution order across streams
            random_seed: Optional random seed for reproducibility

        Returns:
            Dictionary with 'measured' and 'warmup' keys containing lists of query execution results
        """
        system.set_active_schema(self.get_schema_name())
        if num_streams <= 1:
            return self._run_workload_sequential(
                system, query_names, runs_per_query, warmup_runs
            )
        else:
            return self._run_workload_multiuser(
                system,
                query_names,
                runs_per_query,
                warmup_runs,
                num_streams,
                randomize,
                random_seed,
            )

    def _run_workload_sequential(
        self,
        system: SystemUnderTest,
        query_names: list[str],
        runs_per_query: int,
        warmup_runs: int,
    ) -> dict[str, list[dict[str, Any]]]:
        """
        Execute workload sequentially on a single connection.

        Args:
            system: System under test
            query_names: List of query names to execute
            runs_per_query: Number of measured runs per query
            warmup_runs: Number of warmup runs per query

        Returns:
            Dictionary with 'measured' and 'warmup' keys containing results
        """
        all_queries = self.get_queries(system)
        measured_results = []
        warmup_results = []
        for query_name in query_names:
            if query_name not in all_queries:
                print(f"Warning: Query {query_name} not found in workload")
                continue
            query_sql = all_queries[query_name]
            print(f"Running {query_name}...")
            for warmup in range(warmup_runs):
                print(f"  Warmup {warmup + 1}/{warmup_runs}")
                result = self.run_query(
                    system, f"{query_name}_warmup_{warmup + 1}", query_sql
                )
                result.update(
                    {
                        "run_number": warmup + 1,
                        "system": system.name,
                        "workload": self.name,
                        "scale_factor": self.scale_factor,
                        "variant": self.config.get("variant", "official"),
                        "stream_id": None,
                    }
                )
                warmup_results.append(result)
            for run in range(runs_per_query):
                print(f"  Run {run + 1}/{runs_per_query}")
                result = self.run_query(system, query_name, query_sql)
                result.update(
                    {
                        "run_number": run + 1,
                        "system": system.name,
                        "workload": self.name,
                        "scale_factor": self.scale_factor,
                        "variant": self.config.get("variant", "official"),
                        "stream_id": None,
                    }
                )
                measured_results.append(result)
        return {"measured": measured_results, "warmup": warmup_results}

    def _run_workload_multiuser(
        self,
        system: SystemUnderTest,
        query_names: list[str],
        runs_per_query: int,
        warmup_runs: int,
        num_streams: int,
        randomize: bool,
        random_seed: int | None,
    ) -> dict[str, list[dict[str, Any]]]:
        """
        Execute workload with multiple concurrent streams.

        Args:
            system: System under test
            query_names: List of query names to execute
            runs_per_query: Number of measured runs per query
            warmup_runs: Number of warmup runs per query
            num_streams: Number of concurrent execution streams
            randomize: Whether to randomize query execution order
            random_seed: Optional random seed for reproducibility

        Returns:
            Dictionary with 'measured' and 'warmup' keys containing results
        """
        all_queries = self.get_queries(system)
        warmup_results = []
        print(f"Running multiuser workload with {num_streams} concurrent streams")
        print(f"Randomize: {randomize}, Seed: {random_seed}")
        print("\nPhase 1: Warmup runs (sequential)")
        for query_name in query_names:
            if query_name not in all_queries:
                print(f"Warning: Query {query_name} not found in workload")
                continue
            query_sql = all_queries[query_name]
            print(f"Running {query_name} warmup...")
            for warmup in range(warmup_runs):
                print(f"  Warmup {warmup + 1}/{warmup_runs}")
                result = self.run_query(
                    system, f"{query_name}_warmup_{warmup + 1}", query_sql
                )
                result.update(
                    {
                        "run_number": warmup + 1,
                        "system": system.name,
                        "workload": self.name,
                        "scale_factor": self.scale_factor,
                        "variant": self.config.get("variant", "official"),
                        "stream_id": None,
                    }
                )
                warmup_results.append(result)
        print(f"\nPhase 2: Measured runs ({num_streams} concurrent streams)")
        query_executions = []
        for query_name in query_names:
            if query_name not in all_queries:
                continue
            for run in range(1, runs_per_query + 1):
                query_executions.append((query_name, run))
        total_executions = len(query_executions)
        print(
            f"Total query executions: {total_executions} ({len(query_names)} queries × {runs_per_query} runs)"
        )
        if randomize:
            rng = random.Random(random_seed)
            rng.shuffle(query_executions)
            print(f"Query execution order randomized (seed: {random_seed})")
        else:
            print("Query execution order: round-robin")
        stream_assignments: list[list[tuple[str, int]]] = [
            [] for _ in range(num_streams)
        ]
        for idx, query_exec in enumerate(query_executions):
            stream_id = idx % num_streams
            stream_assignments[stream_id].append(query_exec)
        for stream_id, assignments in enumerate(stream_assignments):
            print(f"  Stream {stream_id}: {len(assignments)} queries")
        measured_results = []
        results_lock = threading.Lock()

        def collect_result(result: dict[str, Any]) -> None:
            """Thread-safe result collection."""
            with results_lock:
                measured_results.append(result)

        with ThreadPoolExecutor(max_workers=num_streams) as executor:
            futures = []
            for stream_id, assignments in enumerate(stream_assignments):
                future = executor.submit(
                    self._execute_stream,
                    stream_id,
                    assignments,
                    all_queries,
                    system,
                    collect_result,
                )
                futures.append(future)
            for future in as_completed(futures):
                try:
                    stream_id, queries_executed = future.result()
                    print(f"  Stream {stream_id} completed: {queries_executed} queries")
                except Exception as e:
                    print(f"  Stream execution failed: {e}")
        print(f"\nCompleted: {len(measured_results)} total query executions")
        return {"measured": measured_results, "warmup": warmup_results}

    def _execute_stream(
        self,
        stream_id: int,
        query_assignments: list[tuple[str, int]],
        all_queries: dict[str, str],
        system: SystemUnderTest,
        result_callback: Callable[[dict[str, Any]], None],
    ) -> tuple[int, int]:
        """
        Execute queries for a single stream.

        Args:
            stream_id: ID of this stream (0-based)
            query_assignments: List of (query_name, run_number) tuples to execute
            all_queries: Dictionary of all available queries
            system: System under test
            result_callback: Callback function to collect results (thread-safe)

        Returns:
            Tuple of (stream_id, number_of_queries_executed)
        """
        queries_executed = 0
        for query_name, run_number in query_assignments:
            query_sql = all_queries[query_name]
            try:
                result = self.run_query(system, query_name, query_sql)
                result.update(
                    {
                        "run_number": run_number,
                        "system": system.name,
                        "workload": self.name,
                        "scale_factor": self.scale_factor,
                        "variant": self.config.get("variant", "official"),
                        "stream_id": stream_id,
                    }
                )
                result_callback(result)
                queries_executed += 1
            except Exception as e:
                print(f"  Stream {stream_id}: Error executing {query_name}: {e}")
                error_result = {
                    "query": query_name,
                    "elapsed_ms": 0,
                    "success": False,
                    "error": str(e),
                    "run_number": run_number,
                    "system": system.name,
                    "workload": self.name,
                    "scale_factor": self.scale_factor,
                    "variant": self.config.get("variant", "official"),
                    "stream_id": stream_id,
                }
                result_callback(error_result)
        return (stream_id, queries_executed)

    def get_schema_name(self) -> str:
        """Get the schema name for this workload."""
        return f"{self.name}_sf{self.scale_factor}"

    @classmethod
    def get_python_dependencies(cls) -> list[str]:
        """Return list of Python packages required by this workload."""
        return []

    def get_data_size_info(self) -> dict[str, Any]:
        """Get information about generated data size."""
        info = {
            "scale_factor": self.scale_factor,
            "data_directory": str(self.data_dir),
            "data_exists": self._is_data_generated(),
        }
        if self._is_data_generated():
            total_size = sum(
                f.stat().st_size for f in self.data_dir.rglob("*") if f.is_file()
            )
            info["total_size_bytes"] = total_size
            info["total_size_mb"] = int(round(total_size / (1024 * 1024), 2))
        return info

    def _is_data_generated(self) -> bool:
        """Check if data has already been generated."""
        return self.data_dir.exists() and any(self.data_dir.iterdir())

    def get_workload_description(self) -> dict[str, Any]:
        """
        Get workload description for report.

        Returns:
            Dictionary with 'short' and 'full' description, and optional 'characteristics' list
        """
        return {
            "short": f"{self.name.upper()} benchmark workload",
            "full": f"This benchmark uses the {self.name.upper()} workload at scale factor {self.scale_factor}.",
        }

    def get_query_categories(self) -> dict[str, list[str]]:
        """Return query categories for performance grouping in reports.

        Override in subclasses to provide meaningful query groupings.
        Keys are category names, values are lists of query names.

        Returns:
            Dictionary mapping category names to lists of query names.
            Empty dict means no categorization (all queries shown individually).
        """
        return {}

    def get_table_info(self) -> dict[str, dict[str, Any]]:
        """
        Return table metadata (names, columns, descriptions).

        Returns:
            Dictionary mapping table names to table metadata including:
            - description: Human-readable description
            - columns: List of column names
            - cardinality_sf1: Approximate row count at SF=1 (optional)
            - relationships: List of relationship descriptions (optional)
        """
        return {}

    def get_setup_script_info(self) -> dict[str, str]:
        """
        Return descriptions of setup steps.

        Returns:
            Dictionary mapping script names to human-readable descriptions
        """
        return {
            "schema_creation": "Create database schema and tables",
            "index_creation": "Create indexes for query optimization",
            "table_analysis": "Analyze tables and update statistics",
        }

    def _get_template_context(self, system: SystemUnderTest) -> dict[str, Any]:
        """Build template context for rendering setup scripts.

        Consolidates all template variables needed for SQL template rendering,
        including generic variables and system-specific overrides.

        Args:
            system: System under test

        Returns:
            Dictionary of template variables
        """
        system_extra = {}
        if hasattr(system, "setup_config"):
            system_extra = system.setup_config.get("extra", {})
        node_count = getattr(system, "node_count", 1)
        cluster = getattr(system, "cluster_name", "benchmark_cluster")
        context: dict[str, Any] = {
            "system_kind": system.kind,
            "scale_factor": self.scale_factor,
            "schema": self.get_schema_name(),
            "system_extra": system_extra,
            "node_count": node_count,
            "cluster": cluster,
        }
        if system.SUPPORTS_EXTERNAL_TABLES:
            storage = system.get_storage_backend()
            if storage is not None:
                context["data_locations"] = self.get_data_locations(
                    storage, self.get_schema_name()
                )
            else:
                context["data_locations"] = {}
        else:
            context["data_locations"] = {}
        context.update(system.get_template_variables())
        return context

    def execute_setup_script(self, system: SystemUnderTest, script_name: str) -> bool:
        """Execute a templated setup script with per-system file support.

        Priority order for template loading:
        1. setup/{system.kind}/{script_name}  (system-specific)
        2. setup/{script_name}                (fallback/legacy)

        This mirrors the query variant pattern, making each system's SQL
        self-contained and easier to maintain.
        """
        try:
            template_paths = [f"{system.kind}/{script_name}", script_name]
            template = None
            for path in template_paths:
                try:
                    template = self.get_template_env().get_template(path)
                    break
                except Exception:
                    continue
            if template is None:
                raise FileNotFoundError(
                    f"Setup script {script_name} not found for system {system.kind}. Tried: {', '.join(template_paths)}"
                )
            context = self._get_template_context(system)
            rendered_sql = template.render(**context)
            statements = system.split_sql_statements(rendered_sql)
            for idx, statement in enumerate(statements):
                if not statement.strip():
                    continue
                timeout = self.calculate_statement_timeout(statement, system)
                result = system.execute_query(
                    statement,
                    query_name=f"setup_{script_name.replace('.sql', '')}_{idx + 1}",
                    timeout=int(timeout.total_seconds()),
                )
                if not result["success"]:
                    print(
                        f"Failed to execute statement {idx + 1} in {script_name}: {result.get('error', 'Unknown error')}"
                    )
                    print(f"Statement was: {statement[:200]}...")
                    return False
            return True
        except Exception as e:
            print(f"Error executing setup script {script_name}: {e}")
            return False

    def _get_query_variant_for_system(self, system: SystemUnderTest) -> str:
        """
        Determine which query variant to use for a given system.

        Args:
            system: System under test

        Returns:
            Variant name to use for this system
        """
        if self.system_variants and system.name in self.system_variants:
            return str(self.system_variants[system.name])
        return str(self.variant)

    def _get_query_sql(
        self,
        query_name: str,
        system: SystemUnderTest,
        use_verify_variants: bool = False,
    ) -> str:
        """
        Get SQL text for a specific query with variant and templates resolved.

        Priority order for loading queries (when use_verify_variants=True):
        1. variants/verify/{system_kind}/{query_name}.sql (system-specific verify)
        2. variants/verify/{query_name}.sql (generic verify)
        3. variants/{variant}/{system_kind}/{query_name}.sql (system-specific)
        4. variants/{variant}/{query_name}.sql (generic variant)
        5. {query_name}.sql (default/official with inline conditionals)

        When use_verify_variants=False, steps 1-2 are skipped.
        """
        try:
            variant = self._get_query_variant_for_system(system)
            query_paths: list[str] = []
            if use_verify_variants:
                query_paths.extend(
                    [
                        f"variants/verify/{system.kind}/{query_name}.sql",
                        f"variants/verify/{query_name}.sql",
                    ]
                )
            query_paths.extend(
                [
                    f"variants/{variant}/{system.kind}/{query_name}.sql",
                    f"variants/{variant}/{query_name}.sql",
                    f"{query_name}.sql",
                ]
            )
            template = None
            for path in query_paths:
                try:
                    template = self.get_template_env().get_template(path)
                    break
                except Exception:
                    continue
            if template is None:
                raise FileNotFoundError(
                    f"Query {query_name} not found in any variant path"
                )
            system_extra = {}
            if hasattr(system, "setup_config"):
                system_extra = system.setup_config.get("extra", {})
            rendered_sql = template.render(
                system_kind=system.kind,
                scale_factor=self.scale_factor,
                schema=self.get_schema_name(),
                variant=variant,
                system_extra=system_extra,
            )
            return rendered_sql
        except Exception as e:
            print(f"Error loading query {query_name}: {e}")
            return f"-- Error loading query {query_name}: {e}"

    def calculate_statement_timeout(
        self, statement: str, system: SystemUnderTest
    ) -> timedelta:
        """Default implementation: 5 minutes for any statement"""
        return timedelta(minutes=5)


def get_workload_class(workload_name: str) -> type | None:
    """
    Dynamically import and return the workload class for the given workload name.

    Args:
        workload_name: The workload identifier (e.g., 'tpch', 'tpcds')

    Returns:
        The workload class if found, None otherwise
    """
    import importlib
    import inspect

    class_name = f"{workload_name.upper()}Workload"
    module_name = f"benchkit.workloads.{workload_name}"
    try:
        module = importlib.import_module(module_name)
        if hasattr(module, class_name):
            cls = getattr(module, class_name)
            return cls if isinstance(cls, type) else None
        else:
            for attr_name in dir(module):
                attr = getattr(module, attr_name)
                if (
                    inspect.isclass(attr)
                    and issubclass(attr, Workload)
                    and (attr != Workload)
                ):
                    return attr
            return None
    except ImportError:
        return None
