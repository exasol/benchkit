from __future__ import annotations

from enum import Enum


class DataFormat(Enum):
    CSV = 1
    TBL = 2
    TSV = 3
    DATA_LIST = 4

    @staticmethod
    def fromString(name: str) -> DataFormat:
        upper_name = name.upper()
        fmt: DataFormat
        for fmt in list(DataFormat):
            if upper_name == str(fmt).split(".")[-1]:
                return fmt
        raise KeyError(f"DataFormat '{name}'")
