"""Result parsing and normalization utilities."""
