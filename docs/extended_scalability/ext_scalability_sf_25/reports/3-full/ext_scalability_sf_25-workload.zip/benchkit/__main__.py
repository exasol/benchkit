"""Entry point for benchmark execution."""

from .cli import app

if __name__ == "__main__":
    app()
