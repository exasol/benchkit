# Benchmark Execution Package

This is a minimal, self-contained package for executing database benchmarks.

## Quick Start

```bash
# Install dependencies
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Phase 2: Load data (auto-detects running database)
./load_data.sh

# Phase 3: Run queries (auto-detects running database)
./run_queries.sh

# Or specify system explicitly
./load_data.sh exasol
./run_queries.sh exasol

# Debug mode
./load_data.sh exasol --debug
./run_queries.sh exasol --debug
```

## Package Contents

- `benchkit/` - Minimal framework for benchmark execution
- `workloads/` - Workload definitions and queries
- `config.yaml` - Workload configuration
- `load_data.sh` - Data loading script (Phase 2)
- `run_queries.sh` - Query execution script (Phase 3)
- `requirements.txt` - Python dependencies

## Code Quality

This package is generated and validated with:
- **Black** for code formatting
- **Ruff** for linting and auto-fixes
- **isort** for import sorting
- **mypy** for type checking

All quality checks pass in the generated package.
