from __future__ import annotations

"""StarRocks database system implementation."""
import time
from collections.abc import Callable, Iterable
from datetime import timedelta
from pathlib import Path
from typing import Any

try:
    import pymysql
except ModuleNotFoundError:
    pymysql = None
try:
    import requests
except ModuleNotFoundError:
    requests = None
from benchkit.common import DataFormat

from ..util import Timer
from .base import SystemUnderTest, TableOperation


class StarrocksSystem(SystemUnderTest):
    """StarRocks database system implementation.

    StarRocks is a next-generation sub-second MPP database for full analytics scenarios.
    It uses a MySQL-compatible protocol for queries and HTTP Stream Load for data ingestion.

    Architecture:
    - FE (Frontend): Query parsing, planning, and coordination
    - BE (Backend): Data storage and query execution

    Multinode Support:
    - All nodes run both FE and BE
    - Node 0: FE Leader + BE
    - Nodes 1+: FE Followers + BEs
    - FE cluster uses BDBJE for metadata replication
    - BEs are registered via ALTER SYSTEM ADD BACKEND
    """

    SUPPORTS_MULTINODE = True
    SUPPORTS_STREAMLOAD = True
    LOAD_TIMEOUT_MULTIPLIER = 1.2
    FE_MYSQL_PORT = 9030
    FE_HTTP_PORT = 8030
    FE_RPC_PORT = 9020
    FE_EDIT_LOG_PORT = 9010
    BE_THRIFT_PORT = 9060
    BE_HTTP_PORT = 8040
    BE_HEARTBEAT_PORT = 9050
    BE_BRPC_PORT = 8060

    @classmethod
    def get_python_dependencies(cls) -> list[str]:
        """Return Python packages required by StarRocks system."""
        return ["pymysql>=1.0.0", "requests>=2.28.0"]

    def get_storage_config(self) -> tuple[str | None, str]:
        """Return StarRocks-specific storage configuration.

        StarRocks uses /data/starrocks subdirectory with ubuntu user ownership.
        """
        return ("/data/starrocks", "ubuntu:ubuntu")

    @classmethod
    def _get_connection_defaults(cls) -> dict[str, Any]:
        return {
            "port": 9030,
            "username": "root",
            "password": "",
            "schema_key": "database",
            "schema": "benchmark",
        }

    @classmethod
    def _extend_connection_info(
        cls, conn_info: dict[str, Any], setup_config: dict[str, Any]
    ) -> None:
        if "extra" in setup_config:
            conn_info["extra"] = setup_config["extra"]

    @classmethod
    def get_required_ports(cls) -> dict[str, int]:
        """Return ports required by StarRocks system."""
        return {
            "StarRocks FE MySQL": cls.FE_MYSQL_PORT,
            "StarRocks FE HTTP": cls.FE_HTTP_PORT,
            "StarRocks FE RPC": cls.FE_RPC_PORT,
            "StarRocks FE Edit Log": cls.FE_EDIT_LOG_PORT,
            "StarRocks BE Thrift": cls.BE_THRIFT_PORT,
            "StarRocks BE HTTP": cls.BE_HTTP_PORT,
            "StarRocks BE Heartbeat": cls.BE_HEARTBEAT_PORT,
            "StarRocks BE BRPC": cls.BE_BRPC_PORT,
        }

    def __init__(
        self,
        config: dict[str, Any],
        output_callback: Callable[[str], None] | None = None,
        workload_config: dict[str, Any] | None = None,
    ):
        super().__init__(config, output_callback, workload_config)
        self.setup_method = self.setup_config.get("method", "native")
        raw_host = self.setup_config.get("host", "localhost")
        resolved_host = self._resolve_ip_addresses(raw_host)
        if "," in resolved_host:
            self.host = resolved_host.split(",")[0].strip()
        else:
            self.host = resolved_host
        self.port = self.setup_config.get("port", self.FE_MYSQL_PORT)
        self.http_port = self.setup_config.get("http_port", self.FE_HTTP_PORT)
        self.username = self.setup_config.get("username", "root")
        self.password = self.setup_config.get("password", "")
        self.database = self.setup_config.get("database", "benchmark")
        self.install_dir = "/opt/starrocks"
        self.fe_dir = f"{self.install_dir}/fe"
        self.be_dir = f"{self.install_dir}/be"
        self.cluster_name = "benchmark_cluster"
        major_version = int(self.version.split(".")[0])
        if major_version >= 4:
            self._java_home = "/usr/lib/jvm/java-17-openjdk-amd64"
        else:
            self._java_home = "/usr/lib/jvm/java-11-openjdk-amd64"

    def _get_connection(self) -> Any:
        """Get a MySQL connection to StarRocks."""
        if pymysql is None:
            raise ImportError("pymysql is required for StarRocks connections")
        query_timeout = int(self._get_query_execution_timeout())
        return pymysql.connect(
            host=self.host,
            port=self.port,
            user=self.username,
            password=self.password,
            database=self.database if self.database else None,
            connect_timeout=30,
            read_timeout=query_timeout,
            write_timeout=query_timeout,
        )

    def _is_follower_node(self) -> bool:
        """Check if current node is a follower (not the leader) in multinode setup."""
        if not self._cloud_instance_managers or len(self._cloud_instance_managers) <= 1:
            return False
        if self._cloud_instance_manager is not None:
            is_follower: bool = (
                self._cloud_instance_manager != self._cloud_instance_managers[0]
            )
            return is_follower
        return False

    def _generate_fe_config(self) -> str:
        """Generate FE configuration."""
        if self._cloud_instance_manager:
            priority_networks = self._cloud_instance_manager.private_ip
        else:
            priority_networks = "127.0.0.1"
        if "." in priority_networks:
            parts = priority_networks.split(".")
            priority_networks = f"{parts[0]}.{parts[1]}.{parts[2]}.0/24"
        config = f"# StarRocks FE Configuration\nLOG_DIR = {self.fe_dir}/log\nmeta_dir = {self.fe_dir}/meta\nhttp_port = {self.FE_HTTP_PORT}\nrpc_port = {self.FE_RPC_PORT}\nquery_port = {self.FE_MYSQL_PORT}\nedit_log_port = {self.FE_EDIT_LOG_PORT}\npriority_networks = {priority_networks}\n# Performance tuning\nqe_max_connection = 1024\n# Memory settings\nmetadata_memory_limit = 8G\n"
        return config

    def _generate_be_config(self) -> str:
        """Generate BE configuration."""
        if self._cloud_instance_manager:
            priority_networks = self._cloud_instance_manager.private_ip
        else:
            priority_networks = "127.0.0.1"
        if "." in priority_networks:
            parts = priority_networks.split(".")
            priority_networks = f"{parts[0]}.{parts[1]}.{parts[2]}.0/24"
        storage_root = str(self.data_dir) if self.data_dir else f"{self.be_dir}/storage"
        config = f"# StarRocks BE Configuration\nLOG_DIR = {self.be_dir}/log\nbe_port = {self.BE_THRIFT_PORT}\nbe_http_port = {self.BE_HTTP_PORT}\nheartbeat_service_port = {self.BE_HEARTBEAT_PORT}\nbrpc_port = {self.BE_BRPC_PORT}\npriority_networks = {priority_networks}\nstorage_root_path = {storage_root}\n# Performance tuning\nmem_limit = 80%\n# Parallel execution\nparallel_fragment_exec_instance_num = 16\n"
        return config

    def _wait_for_fe_ready(self, timeout: int = 60) -> bool:
        """Wait for FE to be ready to accept connections."""
        start_time = time.time()
        while time.time() - start_time < timeout:
            try:
                result = self.execute_command(
                    f"mysql -h 127.0.0.1 -P {self.FE_MYSQL_PORT} -u root -e 'SELECT 1' 2>/dev/null",
                    timeout=10.0,
                    record=False,
                )
                if result.get("success", False):
                    return True
            except Exception:
                pass
            time.sleep(2)
        return False

    def _register_local_backend(self) -> bool:
        """Register the local BE with FE."""
        if self._cloud_instance_manager:
            be_host = self._cloud_instance_manager.private_ip
        else:
            be_host = "127.0.0.1"
        sql = f"ALTER SYSTEM ADD BACKEND '{be_host}:{self.BE_HEARTBEAT_PORT}'"
        result = self.execute_command(
            f'mysql -h 127.0.0.1 -P {self.FE_MYSQL_PORT} -u root -e "{sql}" 2>/dev/null || true',
            timeout=30.0,
            record=False,
        )
        return bool(result.get("success", False))

    def is_healthy(self, quiet: bool = False) -> bool:
        """Check if StarRocks is running and accepting connections."""
        try:
            health_check_host = self._get_health_check_host()
            if pymysql is None:
                if not quiet:
                    self._log("Warning: pymysql not available")
                return False
            conn = pymysql.connect(
                host=health_check_host,
                port=self.port,
                user=self.username,
                password=self.password,
                connect_timeout=10,
            )
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            cursor.close()
            conn.close()
            return True
        except Exception as e:
            if not quiet:
                self._log(f"Health check failed: {e}")
            return False

    def create_schema(self, schema_name: str) -> bool:
        """Create a database in StarRocks."""
        try:
            if pymysql is None:
                self._log("✗ Failed to create database: pymysql not available")
                return False
            conn = pymysql.connect(
                host=self.host,
                port=self.port,
                user=self.username,
                password=self.password,
                database=None,
                connect_timeout=30,
            )
            try:
                cursor = conn.cursor()
                sql = f"CREATE DATABASE IF NOT EXISTS {schema_name}"
                cursor.execute(sql)
                conn.commit()
                cursor.close()
            finally:
                conn.close()
            self.database = schema_name
            self._log(f"✓ Created database: {schema_name}")
            return True
        except Exception as e:
            self._log(f"✗ Failed to create database: {e}")
            return False

    def load_data(self, table_name: str, data_path: Path, **kwargs: Any) -> bool:
        """Load data into StarRocks table using Stream Load."""
        schema_name = kwargs.get("schema", self.database)
        try:
            self._log(f"Loading {data_path} into {table_name}...")
            load_host = self._get_health_check_host()
            column_separator = kwargs.get("column_separator", "|")
            curl_cmd = f'curl --location-trusted -u {self.username}:{self.password} -H "column_separator:{column_separator}" -H "Expect:100-continue" -T {data_path} http://{load_host}:{self.http_port}/api/{schema_name}/{table_name}/_stream_load'
            result = self.execute_command(
                curl_cmd, timeout=self._get_data_loading_timeout(), record=False
            )
            if not result.get("success", False):
                self._log(f"Stream Load failed: {result.get('stderr', '')}")
                return False
            stdout = result.get("stdout", "")
            if '"Status": "Success"' in stdout or '"Status":"Success"' in stdout:
                self._log(f"✓ Successfully loaded data into {table_name}")
                return True
            elif '"Status": "Fail"' in stdout or '"Status":"Fail"' in stdout:
                self._log(f"Stream Load reported failure: {stdout}")
                return False
            else:
                count_result = self.execute_query(
                    f"SELECT COUNT(*) FROM {schema_name}.{table_name}",
                    query_name=f"count_{table_name}",
                )
                if count_result.get("success", False):
                    self._log(f"✓ Data loaded into {table_name}")
                    return True
                self._log(f"Could not verify data load: {stdout}")
                return False
        except Exception as e:
            self._log(f"Failed to load data into {table_name}: {e}")
            return False

    def load_data_from_iterable(
        self,
        table_name: str,
        data_source: Iterable[Any],
        data_format: DataFormat,
        **kwargs: Any,
    ) -> bool:
        """Load data from iterable - not implemented for StarRocks."""
        raise NotImplementedError("StarRocks.load_data_from_iterable not implemented")

    def execute_query(
        self,
        query: str,
        query_name: str | None = None,
        return_data: bool = False,
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Execute a SQL query in StarRocks using pymysql."""
        from ..debug import debug_print

        if not query_name:
            query_name = "unnamed_query"
        if timeout is None:
            timeout = 300
        try:
            debug_print(f"Executing query: {query_name}")
            if len(query) > 200:
                debug_print(f"SQL: {query[:200]}...")
            else:
                debug_print(f"SQL: {query}")
            with Timer(f"Query {query_name}") as timer:
                if pymysql is None:
                    return {
                        "success": False,
                        "elapsed_s": 0,
                        "rows_returned": 0,
                        "query_name": query_name,
                        "error": "pymysql not available",
                    }
                database_to_use = getattr(self, "_active_schema", None) or self.database
                conn = pymysql.connect(
                    host=self.host,
                    port=self.port,
                    user=self.username,
                    password=self.password,
                    database=database_to_use,
                    connect_timeout=30,
                    read_timeout=timeout,
                    write_timeout=timeout,
                )
                try:
                    cursor = conn.cursor()
                    query_stripped = query.strip()
                    while query_stripped.startswith("--"):
                        newline_pos = query_stripped.find("\n")
                        if newline_pos == -1:
                            query_stripped = ""
                            break
                        query_stripped = query_stripped[newline_pos + 1 :].strip()
                    cursor.execute(query)
                    if query_stripped.upper().startswith(
                        ("SELECT", "WITH", "SHOW", "DESCRIBE", "EXPLAIN")
                    ):
                        rows = cursor.fetchall()
                        rows_returned = len(rows)
                        if return_data:
                            import pandas as pd

                            columns = [desc[0] for desc in cursor.description]
                            df = pd.DataFrame(rows, columns=columns)
                        else:
                            df = None
                    else:
                        conn.commit()
                        rows_returned = cursor.rowcount if cursor.rowcount >= 0 else 0
                        df = None
                    response: dict[str, Any] = {
                        "success": True,
                        "elapsed_s": timer.elapsed,
                        "rows_returned": rows_returned,
                        "query_name": query_name,
                        "error": None,
                    }
                    if return_data and df is not None:
                        response["data"] = df
                    return response
                finally:
                    cursor.close()
                    conn.close()
        except Exception as e:
            return {
                "success": False,
                "elapsed_s": timer.elapsed if "timer" in locals() else 0,
                "rows_returned": 0,
                "query_name": query_name,
                "error": str(e),
            }

    def get_system_metrics(self) -> dict[str, Any]:
        """Get StarRocks-specific performance metrics."""
        metrics: dict[str, Any] = {}
        try:
            system_queries = {
                "be_count": "SELECT COUNT(*) FROM information_schema.be_bvars",
                "fe_count": "SHOW PROC '/frontends'",
            }
            for metric_name, query in system_queries.items():
                result = self.execute_query(query, query_name=f"metrics_{metric_name}")
                if result["success"]:
                    metrics[metric_name] = {
                        "query_time": result["elapsed_s"],
                        "rows": result["rows_returned"],
                    }
        except Exception as e:
            metrics["error"] = str(e)
        return metrics

    def get_template_variables(self) -> dict[str, Any]:
        """Return StarRocks-specific template variables for SQL rendering.

        Unpacks extra config values (bucket_count, replication_num) so templates
        can use them directly as {{ bucket_count }} instead of {{ system_extra.bucket_count }}.

        Returns:
            Dictionary with bucket_count and replication_num
        """
        variables = super().get_template_variables()
        extra = self.setup_config.get("extra", {})
        if "bucket_count" in extra:
            variables["bucket_count"] = extra["bucket_count"]
        if "replication_num" in extra:
            variables["replication_num"] = extra["replication_num"]
        return variables

    def teardown(self) -> bool:
        """Clean up StarRocks installation."""
        success = True
        stop_be = self.execute_command(f"cd {self.be_dir} && ./bin/stop_be.sh || true")
        stop_fe = self.execute_command(f"cd {self.fe_dir} && ./bin/stop_fe.sh || true")
        success = stop_be.get("success", False) and stop_fe.get("success", False)
        if self.setup_config.get("cleanup_data", False):
            success = success and self.cleanup_data_directory()
        return success

    def _should_execute_remotely(self) -> bool:
        """StarRocks only executes remotely for native installations."""
        return (
            self._cloud_instance_manager is not None and self.setup_method == "native"
        )

    def estimate_execution_time(
        self, operation: TableOperation, data_size_gb: float
    ) -> timedelta:
        """Estimate execution time for operations."""
        if operation == "OPTIMIZE TABLE":
            estimate = timedelta(minutes=0.5 * data_size_gb / self.node_count)
            return max(timedelta(minutes=5), min(timedelta(hours=1), estimate))
        return super().estimate_execution_time(operation, data_size_gb)
