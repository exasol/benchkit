"""Entry point for minimal workload execution."""

from .cli import app

if __name__ == "__main__":
    app()
