"""Minimal CLI for workload execution only."""

from pathlib import Path
from typing import Any

import typer
import yaml
from rich.console import Console

app = typer.Typer(
    name="benchkit", help="Minimal workload execution framework", no_args_is_help=True
)
console = Console()


def load_workload_config(config_path: str) -> dict[str, Any]:
    """Load workload config without full validation (minimal fields only)."""
    with open(config_path) as f:
        config = yaml.safe_load(f)
    return config


@app.command()
def execute(
    config: str = typer.Option(..., "--config", "-c", help="Path to config YAML file"),
    system: str = typer.Option(
        ..., "--system", "-s", help="System name to run workload against"
    ),
    force: bool = typer.Option(
        False, "--force", "-f", help="Force run even if results exist"
    ),
    debug: bool = typer.Option(
        False, "--debug", help="Enable debug output for query execution"
    ),
) -> None:
    """Execute workload against the specified system."""
    from .debug import set_debug
    from .workload_runner import execute_workload

    if debug:
        set_debug(True)
    cfg = load_workload_config(config)
    outdir = Path("results") / cfg["project_id"]
    outdir.mkdir(parents=True, exist_ok=True)
    cfg["systems"] = [s for s in cfg["systems"] if s["name"] == system]
    if not cfg["systems"]:
        console.print(f"[red]Error: System '{system}' not found in configuration[/]")
        return
    console.print(f"[blue]Executing workload for system:[/] {system}")
    console.print(
        f"[dim]Workload: {cfg['workload']['name']} (SF={cfg['workload']['scale_factor']})[/]"
    )
    execute_workload(cfg, outdir, force)
    console.print("[green]✓ Workload execution completed[/]")


if __name__ == "__main__":
    app()
