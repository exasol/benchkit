"""Base classes for database systems under test."""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from ..util import safe_command


class SystemUnderTest(ABC):
    """Abstract base class for database systems under test."""

    def __init__(self, config: dict[str, Any]):
        self.name = config["name"]
        self.kind = config["kind"]
        self.version = config["version"]
        self.setup_config = config["setup"]
        self.data_dir: Path | None = Path(
            self.setup_config.get("data_dir", f"/data/{self.name}")
        )
        self.config = config
        self._connection = None
        self._is_running = False
        self.setup_commands: list[dict[str, Any]] = []
        self.installation_notes: list[str] = []

    @abstractmethod
    def is_healthy(self, quiet: bool = False) -> bool:
        """
        Check if the database system is running and healthy.

        Returns:
            True if system is healthy, False otherwise
        """
        pass

    @abstractmethod
    def create_schema(self, schema_name: str) -> bool:
        """
        Create a database schema/database.

        Args:
            schema_name: Name of the schema to create

        Returns:
            True if creation successful, False otherwise
        """
        pass

    def get_connection_string(self, public_ip: str, private_ip: str) -> str:
        """
        Get connection string for this database system.

        Args:
            public_ip: Public IP address of the system
            private_ip: Private IP address of the system

        Returns:
            Connection string with CLI command to connect to the database
        """
        host = self.setup_config.get("host", public_ip)
        port = self.setup_config.get("port", "N/A")
        return f"{self.kind}://{host}:{port}"

    def get_data_generation_directory(self, workload: Any) -> Path | None:
        """
        Get the directory where benchmark data should be generated.

        Override this method in subclasses to provide custom paths on additional disks.

        Args:
            workload: The workload object that needs data generation

        Returns:
            Path where data should be generated, or None to use default local path
        """
        return None

    @abstractmethod
    def load_data(self, table_name: str, data_path: Path, **kwargs: Any) -> bool:
        """
        Load data into a table.

        Args:
            table_name: Name of the target table
            data_path: Path to the data file
            **kwargs: Additional parameters for data loading

        Returns:
            True if loading successful, False otherwise
        """
        pass

    @abstractmethod
    def execute_query(
        self, query: str, query_name: str | None = None, return_data: bool = False
    ) -> dict[str, Any]:
        """
        Execute a SQL query and return timing and result information.

        Args:
            query: SQL query to execute
            query_name: Optional name for the query (for logging)
            return_data: If True, include result data in response (default: False)

        Returns:
            Dictionary containing:
            - success: bool
            - elapsed_s: float (execution time in seconds)
            - rows_returned: int (number of rows returned)
            - error: str (error message if failed)
            - query_name: str (name of the query)
            - data: pd.DataFrame (only if return_data=True, query results as DataFrame)
        """
        pass

    @abstractmethod
    def get_system_metrics(self) -> dict[str, Any]:
        """
        Get system-specific performance metrics.

        Returns:
            Dictionary containing system metrics like:
            - memory_usage
            - cache_hit_ratio
            - active_connections
            - etc.
        """
        pass

    @abstractmethod
    def teardown(self) -> bool:
        """
        Clean up and remove the database system.

        Returns:
            True if teardown successful, False otherwise
        """
        pass

    def prepare_data_directory(self) -> bool:
        """Prepare data directory for the database."""
        if self.data_dir is None:
            return True
        try:
            self.data_dir.mkdir(parents=True, exist_ok=True)
            return True
        except Exception as e:
            print(f"Failed to create data directory {self.data_dir}: {e}")
            return False

    def cleanup_data_directory(self) -> bool:
        """Clean up data directory."""
        if self.data_dir is None:
            return True
        try:
            if self.data_dir.exists():
                import shutil

                shutil.rmtree(self.data_dir)
            return True
        except Exception as e:
            print(f"Failed to cleanup data directory {self.data_dir}: {e}")
            return False

    def execute_command(
        self,
        command: str,
        timeout: float | None = None,
        record: bool = True,
        category: str = "setup",
    ) -> dict[str, Any]:
        """Execute a system command safely and optionally record it."""
        result = safe_command(command, timeout=timeout)
        if record:
            self.setup_commands.append(
                {
                    "command": command,
                    "success": result["success"],
                    "description": f"Execute {command.split()[0]} command",
                    "category": category,
                }
            )
        return result

    def wait_for_health(self, max_attempts: int = 30, delay: float = 2.0) -> bool:
        """
        Wait for the system to become healthy.

        Args:
            max_attempts: Maximum number of health check attempts
            delay: Delay between attempts in seconds

        Returns:
            True if system became healthy, False if timeout
        """
        import time

        for attempt in range(max_attempts):
            quiet = attempt < max_attempts - 1
            if self.is_healthy(quiet=quiet):
                return True
            if attempt < max_attempts - 1:
                time.sleep(delay)
        return False

    def _sanitize_command_for_report(self, command: str) -> str:
        """Replace sensitive information in commands with placeholders for reports."""
        import os

        sensitive_replacements = {}
        if hasattr(self, "setup_config") and self.setup_config:
            if "image_password" in self.setup_config:
                sensitive_replacements[self.setup_config["image_password"]] = (
                    "<EXASOL_IMAGE_PASSWORD>"
                )
            if "db_password" in self.setup_config:
                sensitive_replacements[self.setup_config["db_password"]] = (
                    "<EXASOL_DB_PASSWORD>"
                )
            if "admin_password" in self.setup_config:
                sensitive_replacements[self.setup_config["admin_password"]] = (
                    "<EXASOL_ADMIN_PASSWORD>"
                )
            if "password" in self.setup_config:
                sensitive_replacements[self.setup_config["password"]] = (
                    "<DATABASE_PASSWORD>"
                )
        sensitive_replacements[os.path.expanduser("~/.ssh/id_rsa")] = "~/.ssh/id_rsa"
        sanitized = command
        for actual_value, placeholder in sensitive_replacements.items():
            sanitized = sanitized.replace(str(actual_value), placeholder)
        import re

        sanitized = re.sub(
            "\\b10\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\b", "<PRIVATE_IP>", sanitized
        )
        sanitized = re.sub(
            "\\b172\\.(1[6-9]|2\\d|3[01])\\.\\d{1,3}\\.\\d{1,3}\\b",
            "<PRIVATE_IP>",
            sanitized,
        )
        sanitized = re.sub(
            "\\b192\\.168\\.\\d{1,3}\\.\\d{1,3}\\b", "<PRIVATE_IP>", sanitized
        )
        sanitized = re.sub(
            "(?<![=:@])(?<![a-zA-Z0-9-])(?!127\\.0\\.0\\.1\\b)(?!localhost\\b)\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\b",
            "<PUBLIC_IP>",
            sanitized,
        )
        return sanitized

    def __str__(self) -> str:
        return f"{self.kind} {self.version} ({self.name})"

    def __repr__(self) -> str:
        return f"SystemUnderTest(name='{self.name}', kind='{self.kind}', version='{self.version}')"

    @classmethod
    def get_python_dependencies(cls) -> list[str]:
        """Return list of Python packages required by this system."""
        return []

    @classmethod
    def extract_workload_connection_info(
        cls, setup_config: dict[str, Any], for_local_execution: bool = False
    ) -> dict[str, Any]:
        """
        Extract connection information from setup config for workload execution.

        This method extracts only the minimal connection parameters needed for
        workload execution, with proper defaults and environment variable resolution.

        Args:
            setup_config: The setup section from system config
            for_local_execution: If True, use localhost (for packages running on DB machine).
                                If False, preserve configured host with env var resolution (for remote execution).

        Returns:
            Dictionary with connection parameters (host, port, username, password, etc.)
        """
        import os

        def resolve_env_var(value: str) -> str:
            """Resolve environment variable placeholders like $VAR_NAME."""
            if isinstance(value, str) and value.startswith("$"):
                var_name = value[1:]
                return os.environ.get(var_name, value)
            return value

        if for_local_execution:
            host = "localhost"
        else:
            host = resolve_env_var(setup_config.get("host", "localhost"))
        return {
            "host": host,
            "port": setup_config.get("port"),
            "username": setup_config.get("username"),
            "password": setup_config.get("password"),
            "schema": setup_config.get("schema"),
        }

    @classmethod
    def get_required_ports(cls) -> dict[str, int]:
        """
        Return ports required by this system for AWS security group configuration.

        Returns:
            Dictionary with port descriptions as keys and port numbers as values
        """
        return {}


def get_system_class(system_kind: str) -> type | None:
    """
    Dynamically import and return the system class for the given system kind.

    Args:
        system_kind: The system identifier (e.g., 'exasol', 'clickhouse', 'postgres')

    Returns:
        The system class if found, None otherwise
    """
    import importlib
    import inspect

    class_name = f"{system_kind.capitalize()}System"
    module_name = f"benchkit.systems.{system_kind}"
    try:
        module = importlib.import_module(module_name)
        if hasattr(module, class_name):
            cls = getattr(module, class_name)
            return cls if isinstance(cls, type) else None
        else:
            for attr_name in dir(module):
                attr = getattr(module, attr_name)
                if (
                    inspect.isclass(attr)
                    and issubclass(attr, SystemUnderTest)
                    and (attr != SystemUnderTest)
                    and hasattr(attr, "get_python_dependencies")
                ):
                    return attr
            return None
    except ImportError:
        return None
