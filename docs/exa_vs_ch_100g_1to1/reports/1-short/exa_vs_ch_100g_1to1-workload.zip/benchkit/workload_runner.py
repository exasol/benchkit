"""Workload execution runner for minimal packages."""

from pathlib import Path
from typing import Any

from rich.console import Console

console = Console()


def execute_workload(
    config: dict[str, Any], output_dir: Path, force: bool = False
) -> None:
    """Execute workload against configured systems."""
    import pandas as pd

    from .debug import is_debug_enabled
    from .systems.base import get_system_class
    from .workloads.base import get_workload_class

    runs_file = output_dir / "runs.csv"
    if runs_file.exists() and (not force):
        console.print("[yellow]Results already exist, skipping execution[/]")
        return
    workload_name = config["workload"]["name"]
    workload_class = get_workload_class(workload_name)
    if not workload_class:
        console.print(f"[red]Error: Unknown workload '{workload_name}'[/]")
        return
    all_results = []
    all_warmup_results = []
    for system_config in config["systems"]:
        system_name = system_config["name"]
        system_kind = system_config["kind"]
        console.print(f"[blue]Running workload on {system_name}...[/]")
        system_class = get_system_class(system_kind)
        if not system_class:
            console.print(f"[red]Error: Unknown system kind '{system_kind}'[/]")
            continue
        system = system_class(system_config)
        workload = workload_class(config["workload"])
        console.print("[dim]Preparing workload (data generation & loading)...[/dim]")
        try:
            if not workload.prepare(system):
                console.print(
                    f"[red]✗ Failed to prepare workload for {system_name}[/red]"
                )
                continue
            console.print("[green]✓ Workload preparation completed[/green]")
        except Exception as e:
            console.print(f"[red]✗ Workload preparation failed: {e}[/red]")
            if is_debug_enabled():
                import traceback

                console.print(f"[dim]{traceback.format_exc()}[/dim]")
            continue
        if hasattr(workload, "preparation_timings"):
            prep_timings = workload.preparation_timings.copy()
            prep_timings["system"] = system_name
            prep_timings["workload"] = workload.name
            prep_timings["scale_factor"] = workload.scale_factor
            import json

            prep_file = output_dir / f"preparation_{system_name}.json"
            with open(prep_file, "w") as f:
                json.dump(prep_timings, f, indent=2)
            console.print(f"[dim]Preparation timings saved to {prep_file}[/dim]")
        workload_config = config["workload"]
        runs_per_query = workload_config.get("runs_per_query", 3)
        warmup_runs = workload_config.get("warmup_runs", 1)
        multiuser_config = workload_config.get("multiuser") or {}
        num_streams = 1
        randomize = False
        random_seed = None
        if multiuser_config.get("enabled", False):
            num_streams = multiuser_config.get("num_streams", 1)
            randomize = multiuser_config.get("randomize", False)
            random_seed = multiuser_config.get("random_seed", None)
            console.print(
                f"[dim]Multiuser mode: {num_streams} streams, randomize={randomize}, seed={random_seed}[/dim]"
            )
        query_names = (
            workload.queries_to_include
            if hasattr(workload, "queries_to_include")
            else []
        )
        console.print("[dim]Running queries...[/dim]")
        try:
            result_dict = workload.run_workload(
                system,
                query_names,
                runs_per_query,
                warmup_runs,
                num_streams,
                randomize,
                random_seed,
            )
            measured_results = result_dict.get(
                "measured", result_dict if isinstance(result_dict, list) else []
            )
            warmup_results = result_dict.get("warmup", [])
            all_results.extend(measured_results)
            all_warmup_results.extend(warmup_results)
            console.print(f"[green]✓ Completed workload on {system_name}[/]")
        except Exception as e:
            console.print(f"[red]✗ Failed to run workload on {system_name}: {e}[/]")
            if is_debug_enabled():
                import traceback

                console.print(f"[dim]{traceback.format_exc()}[/dim]")
            continue
    if all_results:
        df = pd.DataFrame(all_results)
        df.to_csv(runs_file, index=False)
        console.print(f"[green]✓ Results saved to {runs_file}[/]")
    else:
        console.print("[yellow]No results to save[/]")
    if all_warmup_results:
        warmup_file = output_dir / "runs_warmup.csv"
        warmup_df = pd.DataFrame(all_warmup_results)
        warmup_df.to_csv(warmup_file, index=False)
        console.print(f"[green]✓ Warmup results saved to {warmup_file}[/]")
