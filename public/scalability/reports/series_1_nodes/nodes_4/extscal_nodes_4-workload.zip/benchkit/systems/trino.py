"""Trino database system implementation."""

from collections.abc import Callable, Iterable
from pathlib import Path
from typing import Any

from benchkit.common import DataFormat

from ..util import Timer
from .base import SystemUnderTest


class TrinoSystem(SystemUnderTest):
    """Trino database system implementation."""

    SUPPORTS_MULTINODE = True
    SUPPORTS_EXTERNAL_TABLES = True

    @classmethod
    def get_python_dependencies(cls) -> list[str]:
        """Return Python packages required by Trino system."""
        return ["trino>=0.336.0"]

    def get_storage_config(self) -> tuple[str | None, str]:
        """Return Trino-specific storage configuration.

        Trino uses /data/trino subdirectory with trino user ownership.
        """
        return ("/data/trino", "trino:trino")

    @classmethod
    def _get_connection_defaults(cls) -> dict[str, Any]:
        """Return default connection parameters for Trino."""
        return {
            "port": 8080,
            "username": "admin",
            "password": "",
            "schema_key": "schema",
            "schema": "benchmark",
        }

    @classmethod
    def extract_workload_connection_info(
        cls, setup_config: dict[str, Any], for_local_execution: bool = False
    ) -> dict[str, Any]:
        """
        Extract Trino connection info with proper defaults.

        Args:
            setup_config: The setup section from system config
            for_local_execution: If True, use localhost (for packages running on DB machine).
                                If False, preserve configured host with env var resolution (for remote execution).
        """
        import os

        def resolve_env_var(value: str) -> str:
            """Resolve environment variable placeholders like $VAR_NAME."""
            if isinstance(value, str) and value.startswith("$"):
                var_name = value[1:]
                return os.environ.get(var_name, value)
            return value

        if for_local_execution:
            host = "localhost"
        else:
            host = resolve_env_var(setup_config.get("host", "localhost"))
        defaults = cls._get_connection_defaults()
        connection_info = {
            "host": host,
            "port": setup_config.get("port", defaults["port"]),
            "username": setup_config.get("username", defaults["username"]),
            "catalog": setup_config.get("catalog", "hive"),
            "schema": setup_config.get("schema", defaults["schema"]),
        }
        if setup_config.get("use_additional_disk", False):
            connection_info["use_additional_disk"] = True
        if "storage" in setup_config:
            connection_info["storage"] = setup_config["storage"]
        return connection_info

    @classmethod
    def get_required_ports(cls) -> dict[str, int]:
        """Return ports required by Trino system."""
        return {"Trino HTTP": 8080, "Trino HTTPS": 8443, "Hive Metastore": 9083}

    def get_connection_string(self, public_ip: str, private_ip: str) -> str:
        """Get Trino connection string with full CLI command."""
        defaults = self._get_connection_defaults()
        port = self.setup_config.get("port", defaults["port"])
        catalog = self.setup_config.get("catalog", "hive")
        schema = self.setup_config.get("schema", defaults["schema"])
        return f"trino --server http://{public_ip}:{port} --catalog {catalog} --schema {schema}"

    def __init__(
        self,
        config: dict[str, Any],
        output_callback: Callable[[str], None] | None = None,
        workload_config: dict[str, Any] | None = None,
    ):
        super().__init__(config, output_callback, workload_config)
        self.setup_method = self.setup_config.get("method", "native")
        defaults = self._get_connection_defaults()
        self.host = self.setup_config.get("host", "localhost")
        self.port = self.setup_config.get("port", defaults["port"])
        self.username = self.setup_config.get("username", defaults["username"])
        self.catalog = self.setup_config.get("catalog", "hive")
        self.schema = self.setup_config.get("schema", defaults["schema"])
        self.trino_home = "/opt/trino-server"
        self.hive_metastore_home = "/opt/hive-metastore"
        self.data_dir: Path | None = Path("/data/trino")
        self.hive_data_dir = Path("/data/trino/hive-data")
        self._client = None
        self._cloud_instance_manager: Any = None
        self._cloud_instance_managers: list[Any] = []
        self._external_host: str | None = None
        self._storage_backend = self._create_storage_backend()
        self._validate_multinode_storage()

    def _create_storage_backend(self) -> Any:
        """Create storage backend from configuration.

        Returns:
            StorageBackend instance (LocalStorage or S3Storage)
        """
        from benchkit.storage import LocalStorage, S3Storage

        storage_config = self.setup_config.get("storage", {})
        storage_type = storage_config.get("type", "local")
        if storage_type == "s3":
            return S3Storage(
                bucket=storage_config["bucket"],
                prefix=storage_config.get("prefix", ""),
                region=storage_config.get("region", "us-east-1"),
            )
        else:
            hive_warehouse = self.setup_config.get(
                "hive_warehouse", "/data/trino/hive-warehouse"
            )
            return LocalStorage(base_path=hive_warehouse)

    def _validate_multinode_storage(self) -> None:
        """Validate that multinode clusters use S3 storage.

        Raises:
            ValueError: If multinode configured without S3 storage
        """
        from benchkit.storage import S3Storage

        if self.node_count > 1:
            if not isinstance(self._storage_backend, S3Storage):
                raise ValueError(
                    f"Trino multinode cluster (node_count={self.node_count}) requires S3 storage. Local storage cannot be shared across nodes efficiently. Please add storage configuration:\n  storage:\n    type: s3\n    bucket: your-bucket-name\n    region: your-region"
                )

    def get_storage_backend(self) -> Any:
        """Return the storage backend for this Trino system.

        Returns:
            StorageBackend instance (LocalStorage or S3Storage)
        """
        return self._storage_backend

    def ensure_storage_permissions(self) -> bool:
        """Ensure Hive warehouse directory has correct permissions.

        After data upload, the uploaded directories may have restrictive permissions
        (owned by ubuntu:ubuntu with 755). The Hive metastore (running as trino user)
        needs to write metadata files to these directories during table creation.

        This sets world-writable permissions on the entire warehouse directory
        to allow both users to write.

        Returns:
            True if permissions set successfully, False otherwise.
        """
        if self._storage_backend is None:
            return True
        if hasattr(self._storage_backend, "base_path"):
            hive_warehouse = self._storage_backend.base_path
            print(f"Setting permissions on {hive_warehouse}...")
            result = self.execute_command(
                f"sudo chmod -R 777 {hive_warehouse}", record=False
            )
            if not result.get("success", False):
                print(f"Failed to set permissions on {hive_warehouse}")
                return False
            print(f"✓ Permissions set on {hive_warehouse}")
        return True

    def get_template_variables(self) -> dict[str, Any]:
        """Return Trino-specific template variables.

        Provides hive_warehouse path for external table DDL templates.

        Returns:
            Dictionary with 'hive_warehouse' path
        """
        variables = super().get_template_variables()
        hive_warehouse = self.setup_config.get(
            "hive_warehouse", "/data/trino/hive-warehouse"
        )
        variables["hive_warehouse"] = hive_warehouse
        return variables

    def _get_connection(self) -> Any:
        """Get a connection to Trino database using Python client."""
        try:
            import trino
        except ImportError:
            print("Warning: trino package not available")
            return None
        return trino.dbapi.connect(
            host=self.host,
            port=self.port,
            user=self.username,
            catalog=self.catalog,
            schema=self.schema,
        )

    def _verify_preinstalled(self) -> bool:
        """Verify that Trino is already installed and accessible."""
        return self.is_healthy()

    def start(self) -> bool:
        """Start the Trino system."""
        print(f"Starting {self.name} system...")
        if self.is_healthy(quiet=False):
            print(f"✓ {self.name} is already healthy and ready")
            return True
        result = self.execute_command("sudo systemctl start trino", record=False)
        if not result.get("success", False):
            print("Failed to start Trino service")
            return False
        success = self.wait_for_health(max_attempts=60, delay=5.0)
        if success:
            print(f"✓ {self.name} is healthy and ready")
        else:
            print(f"✗ {self.name} failed to become healthy")
        return success

    def is_healthy(self, quiet: bool = False) -> bool:
        """Check if Trino is running and accepting connections."""
        try:
            health_check_host = getattr(self, "_external_host", None)
            if not health_check_host and self._cloud_instance_manager:
                health_check_host = getattr(
                    self._cloud_instance_manager, "public_ip", None
                )
            if not health_check_host:
                health_check_host = self.host
            if not quiet:
                print(f"Connecting to Trino at {health_check_host}:{self.port}...")
            try:
                import trino
            except ImportError:
                if not quiet:
                    print("Warning: trino package not available")
                return False
            conn = trino.dbapi.connect(
                host=health_check_host, port=self.port, user=self.username
            )
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            result = cursor.fetchone()
            conn.close()
            if not quiet:
                print("Health check successful")
            return result is not None
        except Exception as e:
            if not quiet:
                print(f"Health check failed: {e}")
            return False

    def create_schema(self, schema_name: str) -> bool:
        """Create a schema in Trino."""
        sql = f"CREATE SCHEMA IF NOT EXISTS {self.catalog}.{schema_name}"
        result = self.execute_query(sql, query_name=f"create_schema_{schema_name}")
        success = bool(result.get("success", False))
        if success:
            self.schema = schema_name
            print(f"✓ Using schema: {self.catalog}.{schema_name}")
        else:
            error = result.get("error", "Unknown error")
            print(f"✗ Failed to create schema '{schema_name}': {error}")
        return success

    def load_data(self, table_name: str, data_path: Path, **kwargs: Any) -> bool:
        """Load data into Trino table using INSERT.

        Args:
            table_name: Target table name
            data_path: Path to data file (pipe-delimited .tbl format)
            **kwargs: Additional options:
                - schema: Schema name (default: self.schema)
                - columns: List of column names
                - column_types: List of type identifiers (INTEGER, BIGINT, DECIMAL, VARCHAR, DATE)
        """
        schema_name = kwargs.get("schema", self.schema)
        columns = kwargs.get("columns", None)
        column_types = kwargs.get("column_types", None)
        try:
            print(f"Loading {data_path} into {table_name}...")
            conn = self._get_connection()
            if not conn:
                print("Failed to get Trino connection")
                return False
            cursor = conn.cursor()
            import csv
            from datetime import date
            from decimal import Decimal

            def convert_value(value: str, col_type: str) -> Any:
                """Convert string value to appropriate Python type for Trino."""
                if value == "" or value is None:
                    return None
                if col_type == "INTEGER":
                    return int(value)
                elif col_type == "BIGINT":
                    return int(value)
                elif col_type == "DECIMAL":
                    return Decimal(value)
                elif col_type == "DATE":
                    return date.fromisoformat(value)
                else:
                    return value

            with open(data_path) as f:
                reader = csv.reader(f, delimiter="|")
                placeholders = ",".join(["?" for _ in columns]) if columns else ""
                insert_sql = (
                    f"INSERT INTO {schema_name}.{table_name} VALUES ({placeholders})"
                )
                batch_size = 10000
                batch = []
                total_rows = 0
                for row in reader:
                    if row and row[-1] == "":
                        row = row[:-1]
                    if not row or all(x == "" for x in row):
                        continue
                    if column_types and len(column_types) == len(row):
                        processed_row: list[Any] = [
                            convert_value(val, col_type)
                            for val, col_type in zip(row, column_types, strict=False)
                        ]
                    else:
                        processed_row = [None if x == "" else x for x in row]
                    batch.append(processed_row)
                    total_rows += 1
                    if len(batch) >= batch_size:
                        cursor.executemany(insert_sql, batch)
                        batch = []
                        if total_rows % 50000 == 0:
                            print(f"  Loaded {total_rows:,} rows...")
                if batch:
                    cursor.executemany(insert_sql, batch)
            conn.close()
            print(f"Successfully loaded {total_rows:,} rows into {table_name}")
            return True
        except Exception as e:
            print(f"Failed to load data into {table_name}: {e}")
            import traceback

            traceback.print_exc()
            return False

    def load_data_from_iterable(
        self,
        table_name: str,
        data_source: Iterable[Any],
        data_format: DataFormat,
        **kwargs: Any,
    ) -> bool:
        """
        Streaming load not supported for Trino.

        Trino/Hive connector does not have efficient streaming insert capabilities.
        Use load_data() with file-based loading instead.

        Raises:
            NotImplementedError: Always raised as streaming load is not supported
        """
        raise NotImplementedError(
            "Trino does not support streaming data load. Use load_data() with file-based loading instead."
        )

    def execute_query(
        self,
        query: str,
        query_name: str | None = None,
        return_data: bool = False,
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Execute a SQL query in Trino using Python client."""
        from ..debug import debug_print

        _ = timeout
        query = query.strip().rstrip(";")
        if not query_name:
            query_name = "unnamed_query"
        timer_obj: Timer | None = None
        try:
            import trino
        except ImportError:
            return {
                "success": False,
                "elapsed_s": 0,
                "rows_returned": 0,
                "query_name": query_name,
                "error": "trino package not available",
            }
        try:
            debug_print(f"Executing query: {query_name}")
            if len(query) > 200:
                debug_print(f"SQL: {query[:200]}...")
            else:
                debug_print(f"SQL: {query}")
            with Timer(f"Query {query_name}") as timer:
                timer_obj = timer
                schema_to_use = getattr(self, "_active_schema", None) or self.schema
                conn = trino.dbapi.connect(
                    host=self.host,
                    port=self.port,
                    user=self.username,
                    catalog=self.catalog,
                    schema=schema_to_use,
                )
                cursor = conn.cursor()
                cursor.execute(query)
                query_stripped = query.strip().upper()
                while query_stripped.startswith("--"):
                    newline_pos = query_stripped.find("\n")
                    if newline_pos == -1:
                        query_stripped = ""
                        break
                    query_stripped = query_stripped[newline_pos + 1 :].strip()
                is_select_query = query_stripped.startswith(
                    ("SELECT", "WITH", "SHOW", "DESCRIBE")
                )
                if is_select_query:
                    if return_data:
                        import pandas as pd

                        rows = cursor.fetchall()
                        columns = [desc[0] for desc in cursor.description]
                        df = pd.DataFrame(rows, columns=columns)
                        rows_returned = len(df)
                    else:
                        rows = cursor.fetchall()
                        rows_returned = len(rows)
                        df = None
                else:
                    rows_returned = 0
                    df = None
                conn.close()
                response: dict[str, Any] = {
                    "success": True,
                    "elapsed_s": timer_obj.elapsed if timer_obj else 0,
                    "rows_returned": rows_returned,
                    "query_name": query_name,
                    "error": None,
                }
                if return_data and df is not None:
                    response["data"] = df
                    debug_print(f"Added data to response, df shape: {df.shape}")
                return response
        except Exception as e:
            return {
                "success": False,
                "elapsed_s": timer_obj.elapsed if timer_obj else 0,
                "rows_returned": 0,
                "query_name": query_name,
                "error": str(e),
            }

    def get_system_metrics(self) -> dict[str, Any]:
        """Get Trino-specific performance metrics."""
        metrics: dict[str, Any] = {}
        try:
            system_queries = {
                "active_queries": "SELECT COUNT(*) FROM system.runtime.queries WHERE state = 'RUNNING'",
                "completed_queries": "SELECT COUNT(*) FROM system.runtime.queries WHERE state = 'FINISHED'",
                "failed_queries": "SELECT COUNT(*) FROM system.runtime.queries WHERE state = 'FAILED'",
                "worker_nodes": "SELECT COUNT(*) FROM system.runtime.nodes WHERE coordinator = false",
                "total_nodes": "SELECT COUNT(*) FROM system.runtime.nodes",
            }
            for metric_name, query in system_queries.items():
                result = self.execute_query(query, query_name=f"metrics_{metric_name}")
                if result["success"]:
                    metrics[metric_name] = {
                        "query_time": result["elapsed_s"],
                        "rows": result["rows_returned"],
                    }
        except Exception as e:
            metrics["error"] = str(e)
        return metrics

    def get_table_sizes(
        self, schema: str, table_names: list[str]
    ) -> dict[str, dict[str, Any]]:
        """Query Trino for table storage sizes.

        Trino uses external tables via Hive metastore, so storage sizes
        come from the underlying storage (local filesystem or S3).

        Args:
            schema: Schema name containing the tables
            table_names: List of table names to query

        Returns:
            Dict mapping table names to size info with raw_bytes, stored_bytes,
            row_count, and compression_ratio.
        """
        sizes: dict[str, dict[str, Any]] = {}
        try:
            for table_name in table_names:
                try:
                    count_query = f'SELECT COUNT(*) as cnt FROM "{self.catalog}"."{schema}"."{table_name}"'
                    count_result = self.execute_query(
                        count_query, query_name=f"count_{table_name}", return_data=True
                    )
                    row_count = 0
                    if count_result.get("success") and "data" in count_result:
                        df = count_result["data"]
                        if not df.empty:
                            row_count = int(df.iloc[0, 0])
                    stored_bytes = 0
                    raw_bytes = 0
                    if self._storage_backend:
                        try:
                            storage_size = self._storage_backend.get_table_size(
                                schema, table_name
                            )
                            if storage_size:
                                stored_bytes = storage_size
                                raw_bytes = storage_size
                        except (AttributeError, Exception):
                            pass
                    sizes[table_name.lower()] = {
                        "raw_bytes": raw_bytes,
                        "stored_bytes": stored_bytes,
                        "row_count": row_count,
                        "compression_ratio": (
                            raw_bytes / stored_bytes if stored_bytes > 0 else 0.0
                        ),
                    }
                except Exception as e:
                    self._log(
                        f"Warning: Failed to get size for table {table_name}: {e}"
                    )
        except Exception as e:
            self._log(f"Warning: Failed to get table sizes: {e}")
        return sizes

    def teardown(self) -> bool:
        """Clean up Trino installation."""
        success = True
        self.execute_command("sudo systemctl stop trino || true", record=False)
        self.execute_command("sudo systemctl stop hive-metastore || true", record=False)
        if self.setup_config.get("cleanup_data", False):
            success = success and self.cleanup_data_directory()
        return success

    def get_version_info(self) -> dict[str, str]:
        """Get detailed version information."""
        version_info = {"configured_version": self.version}
        try:
            result = self.execute_query("SELECT version()", query_name="get_version")
            if result["success"]:
                version_info["actual_version"] = "version_retrieved_via_trino_client"
            try:
                import trino

                version_info["trino_client_version"] = getattr(
                    trino, "__version__", "unknown"
                )
            except ImportError:
                version_info["trino_client_version"] = "not_available"
        except Exception as e:
            version_info["version_error"] = str(e)
        return version_info

    def get_data_generation_directory(self, workload: Any) -> Path | None:
        """
        Get directory for TPC-H data generation.

        For Trino, Parquet files are generated directly into the Hive warehouse
        directory so external tables can read them without copying.

        Structure: /data/trino/hive-warehouse/<schema>/

        Returns:
            Path to Hive warehouse schema directory for Parquet generation
        """
        hive_warehouse = self.setup_config.get(
            "hive_warehouse", "/data/trino/hive-warehouse"
        )
        schema_name = self.schema if self.schema else "benchmark"
        parquet_dir = Path(hive_warehouse) / schema_name
        self.execute_command(
            f"sudo mkdir -p {parquet_dir} && sudo chmod -R 777 {hive_warehouse}",
            record=False,
        )
        print(f"Trino: Using Hive warehouse for Parquet data: {parquet_dir}")
        return parquet_dir

    def get_hive_warehouse_path(self) -> str:
        """Get the configured Hive warehouse path."""
        return str(
            self.setup_config.get("hive_warehouse", "/data/trino/hive-warehouse")
        )

    def set_cloud_instance_manager(self, instance_manager: Any | list[Any]) -> None:
        """
        Set the cloud instance manager(s) for remote command execution.

        Args:
            instance_manager: Single CloudInstanceManager for single-node systems,
                            or list of CloudInstanceManagers for multinode systems
        """
        if isinstance(instance_manager, list):
            self._cloud_instance_managers = instance_manager
            self._cloud_instance_manager = (
                instance_manager[0] if instance_manager else None
            )
        else:
            self._cloud_instance_manager = instance_manager
            self._cloud_instance_managers = (
                [instance_manager] if instance_manager else []
            )
        if self._cloud_instance_manager and hasattr(
            self._cloud_instance_manager, "public_ip"
        ):
            self._external_host = self._cloud_instance_manager.public_ip
            self.host = "localhost"

    def execute_command(
        self,
        command: str,
        timeout: float | None = None,
        record: bool = True,
        category: str = "setup",
        node_info: str | None = None,
        description: str | None = None,
    ) -> dict[str, Any]:
        """Execute command with remote execution support if cloud instance manager is available."""
        if self._cloud_instance_manager and self.setup_method == "native":
            result = self._cloud_instance_manager.run_remote_command(
                command, timeout=int(timeout) if timeout else 300
            )
            if record:
                command_record = {
                    "command": self._sanitize_command_for_report(command),
                    "success": result.get("success", False),
                    "description": description
                    or f"Execute {command.split()[0]} command on remote system",
                    "category": category,
                }
                if node_info:
                    command_record["node_info"] = node_info
                self.setup_commands.append(command_record)
            return dict(result)
        else:
            return super().execute_command(
                command, timeout, record, category, node_info, description
            )
