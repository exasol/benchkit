-- TPC-H Query 1: Pricing Summary Report
SELECT
    l_returnflag,
    l_linestatus,
    SUM(l_quantity) AS sum_qty,
    SUM(l_extendedprice) AS sum_base_price,
    SUM(l_extendedprice * (1 - l_discount)) AS sum_disc_price,
    SUM(l_extendedprice * (1 - l_discount) * (1 + l_tax)) AS sum_charge,
    AVG(l_quantity) AS avg_qty,
    AVG(l_extendedprice) AS avg_price,
    AVG(l_discount) AS avg_disc,
    COUNT(*) AS count_order
FROM lineitem
WHERE
    {% if system_kind == 'exasol' %}
    l_shipdate <= '1998-09-02'
    {% elif system_kind in ['clickhouse', 'trino', 'starrocks', 'duckdb', 'doris'] %}
    l_shipdate <= DATE '1998-09-02'
    {% else %}
    {{ UNSUPPORTED_SYSTEM_KIND_ERROR_FOR[system_kind] }}
    {% endif %}
GROUP BY
    l_returnflag,
    l_linestatus
ORDER BY
    l_returnflag,
    l_linestatus;