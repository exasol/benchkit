"""Data loading runner for minimal packages (Phase 2)."""

import json
import sys
from pathlib import Path
from typing import Any

from rich.console import Console

console = Console()


def execute_load(config: dict[str, Any], output_dir: Path, force: bool = False) -> None:
    """Execute data loading for configured systems."""
    from .debug import is_debug_enabled
    from .systems.base import get_system_class
    from .workloads.base import get_workload_class

    workload_name = config["workload"]["name"]
    workload_class = get_workload_class(workload_name)
    if not workload_class:
        console.print(f"[red]Error: Unknown workload '{workload_name}'[/]")
        sys.exit(1)
    failed_systems: list[str] = []
    for system_config in config["systems"]:
        system_name = system_config["name"]
        system_kind = system_config["kind"]
        load_complete_file = output_dir / f"load_complete_{system_name}.json"
        if load_complete_file.exists() and (not force):
            console.print(f"[green]✅ {system_name} data already loaded, skipping[/]")
            continue
        console.print(f"[blue]Loading data on {system_name}...[/]")
        system_class = get_system_class(system_kind)
        if not system_class:
            console.print(f"[red]Error: Unknown system kind '{system_kind}'[/]")
            failed_systems.append(system_name)
            continue
        system = system_class(system_config)
        workload = workload_class(config["workload"])
        console.print("[dim]Preparing workload (data generation & loading)...[/]")
        try:
            if not workload.prepare(system):
                console.print(f"[red]✗ Failed to prepare workload for {system_name}[/]")
                failed_systems.append(system_name)
                continue
            console.print("[green]✓ Workload preparation completed[/]")
        except Exception as e:
            console.print(f"[red]✗ Workload preparation failed: {e}[/]")
            if is_debug_enabled():
                import traceback

                console.print(f"[dim]{traceback.format_exc()}[/]")
            failed_systems.append(system_name)
            continue
        prep_timings = getattr(workload, "preparation_timings", {})
        load_complete_data = {
            "system_name": system_name,
            "data_generation_s": prep_timings.get("data_generation_s", 0.0),
            "schema_creation_s": prep_timings.get("schema_creation_s", 0.0),
            "data_loading_s": prep_timings.get("data_loading_s", 0.0),
            "total_raw_bytes": prep_timings.get("total_raw_bytes", 0),
            "total_stored_bytes": prep_timings.get("total_stored_bytes", 0),
            "table_sizes": prep_timings.get("table_sizes", {}),
            "total_preparation_s": prep_timings.get("total_preparation_s", 0.0),
        }
        from datetime import datetime

        load_complete_data["timestamp"] = datetime.now().isoformat()
        with open(load_complete_file, "w") as f:
            json.dump(load_complete_data, f, indent=2)
        console.print(f"[green]✓ Load completion marker saved for {system_name}[/]")
    if failed_systems:
        console.print(f"[red]Load failed for systems: {', '.join(failed_systems)}[/]")
        sys.exit(1)
