from __future__ import annotations

"""High-performance parquet loader using exarrow-rs for Exasol.

This module provides parallel parquet import using exarrow-rs, which leverages
Exasol's HTTP tunneling protocol for high-throughput bulk data loading.

Architecture (Unified Distributed - works for 1 or N nodes):
┌─────────────────────────────────────────────────────────────────┐
│                    Benchmark Runner (Coordinator)                │
│                                                                  │
│  1. Distribute parquet files to nodes via SSH/SCP               │
│  2. Start exarrow-rs on each node (via SSH)                     │
│  3. Collect internal addresses from all instances               │
│  4. Build single IMPORT SQL with all addresses                  │
│  5. Execute IMPORT via pyexasol                                 │
└─────────────────────────────────────────────────────────────────┘

Key advantages over CSV proxy approach:
- Firewall-friendly: exarrow-rs initiates outbound connections to Exasol
- True parallelism: N files = N parallel HTTP tunnels (no semaphore)
- Rust performance: Faster parquet→CSV conversion via native code
- Direct EXA protocol: Uses Exasol's native bulk import protocol
"""
import shutil
import subprocess
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from benchkit.infra.manager import CloudInstanceManager

    from .system import ExasolSystem
CLICKBENCH_PARQUET_URL_PATTERN = (
    "https://datasets.clickhouse.com/hits_compatible/athena_partitioned/hits_{}.parquet"
)


class ExarrowLoader:
    """High-performance parquet loader using exarrow-rs.

    Uses a unified distributed architecture that works identically
    for single-node (1 node) and multi-node (N nodes) deployments.
    The only difference is the number of nodes processing files.
    """

    def __init__(self, system: ExasolSystem, cache_dir: str | None = None):
        """Initialize the loader.

        Args:
            system: Parent ExasolSystem instance
            cache_dir: Directory to store downloaded parquet files
                       (should be workload-specific, e.g., /data/generated/clickbench/partitioned)
                       If None, defaults to /tmp/benchkit_parquet (for backward compatibility)
        """
        self._system = system
        self._parquet_cache_dir = cache_dir or "/tmp/benchkit_parquet"

    def _log(self, message: str) -> None:
        """Log a message using the parent system's logger."""
        self._system._log(message)

    def load_parquet_files_distributed(
        self,
        table_name: str,
        schema: str,
        parquet_url_pattern: str,
        num_partitions: int,
        columns: list[str],
        timestamp_cols: set[str] | None = None,
        date_cols: set[str] | None = None,
        parallel_connections: int = 100,
    ) -> bool:
        """Load parquet files via distributed exarrow-rs instances.

        Unified workflow (same for 1 or N nodes):
        1. Distribute parquet files across node(s) via SSH
        2. Create staging table with raw types
        3. Use pyexasol parallel import with worker callbacks
        4. Transform timestamps/dates via SQL INSERT SELECT
        5. Drop staging table

        Args:
            table_name: Target table name (must already exist)
            schema: Schema name containing the target table
            parquet_url_pattern: URL pattern with {} for partition ID
            num_partitions: Number of parquet partitions to load
            columns: List of column names
            timestamp_cols: Columns containing Unix timestamps
            date_cols: Columns containing dates as days since epoch
            parallel_connections: Number of parallel connections

        Returns:
            True if data loaded successfully
        """
        effective_timestamp_cols = timestamp_cols or set()
        effective_date_cols = date_cols or set()
        nodes = self._get_nodes()
        num_nodes = len(nodes)
        self._log(f"Starting exarrow-rs parallel import with {num_nodes} node(s)...")
        self._log(f"  Loading {num_partitions} files into {schema}.{table_name}")
        try:
            self._log("Step 1: Distributing parquet files to node(s)...")
            if not self._distribute_parquet_files(
                nodes, parquet_url_pattern, num_partitions
            ):
                self._log("Failed to distribute parquet files")
                return False
            self._log("Step 2: Creating staging table...")
            staging_table = f"{table_name}_staging"
            conn = self._system._get_connection(compression=False)
            try:
                conn.execute(f"OPEN SCHEMA {schema}")
                self._create_staging_table(
                    conn,
                    table_name,
                    staging_table,
                    columns,
                    effective_timestamp_cols,
                    effective_date_cols,
                )
                self._log("Step 3: Loading data via parallel import...")
                if not self._execute_parallel_import(
                    conn,
                    nodes,
                    schema,
                    staging_table,
                    columns,
                    num_partitions,
                    parallel_connections,
                ):
                    raise RuntimeError("Parallel import failed")
                result = conn.execute(f"SELECT COUNT(*) FROM {staging_table}")
                staged_rows = result.fetchone()[0]
                self._log(f"  Staged {staged_rows:,} rows")
                self._log("Step 4: Transforming timestamps and dates...")
                transform_sql = self._build_transform_sql(
                    table_name,
                    staging_table,
                    columns,
                    effective_timestamp_cols,
                    effective_date_cols,
                )
                conn.execute(transform_sql)
                result = conn.execute(f"SELECT COUNT(*) FROM {table_name}")
                final_rows = result.fetchone()[0]
                self._log(f"  Transformed {final_rows:,} rows into {table_name}")
                conn.execute(f"DROP TABLE IF EXISTS {staging_table}")
                self._log("  Staging table dropped")
                self._log(f"✓ Loaded {final_rows:,} rows via exarrow-rs")
                return True
            finally:
                conn.close()
        except Exception as e:
            self._log(f"Exarrow-rs loading failed: {e}")
            try:
                cleanup_conn = self._system._get_connection(compression=False)
                staging = f"{schema}.{table_name}_staging"
                cleanup_conn.execute(f"DROP TABLE IF EXISTS {staging}")
                cleanup_conn.close()
            except Exception:
                pass
            return False
        finally:
            self._cleanup_parquet_files(nodes)

    def _get_nodes(self) -> list[Any]:
        """Get list of nodes (cloud instance managers) to use.

        Returns:
            List of CloudInstanceManager objects, or a single-element list
            with None for local execution
        """
        if (
            self._system._cloud_instance_managers
            and len(self._system._cloud_instance_managers) > 0
        ):
            return self._system._cloud_instance_managers
        elif self._system._cloud_instance_manager:
            return [self._system._cloud_instance_manager]
        else:
            return [None]

    def _distribute_parquet_files(
        self, nodes: list[Any], url_pattern: str, num_partitions: int
    ) -> bool:
        """Download and distribute parquet files across nodes.

        Each node gets an equal share of files to process.

        Args:
            nodes: List of CloudInstanceManager objects
            url_pattern: URL pattern with {} for partition ID
            num_partitions: Total number of partitions

        Returns:
            True if successful
        """
        num_nodes = len(nodes)
        files_per_node = num_partitions // num_nodes
        remainder = num_partitions % num_nodes
        for idx, node in enumerate(nodes):
            start_file = idx * files_per_node + min(idx, remainder)
            end_file = start_file + files_per_node + (1 if idx < remainder else 0)
            file_count = end_file - start_file
            node_label = f"Node {idx}" if node else "Local"
            self._log(
                f"  {node_label}: Downloading files {start_file}-{end_file - 1} ({file_count} files)"
            )
            if node is None:
                if not self._download_parquet_files_local(
                    url_pattern, start_file, end_file
                ):
                    return False
            elif not self._download_parquet_files_remote(
                node, url_pattern, start_file, end_file
            ):
                return False
        return True

    def _download_parquet_files_local(
        self, url_pattern: str, start_file: int, end_file: int
    ) -> bool:
        """Download parquet files locally using wget with retry logic.

        Args:
            url_pattern: URL pattern with {} for partition ID
            start_file: Starting file index (inclusive)
            end_file: Ending file index (exclusive)

        Returns:
            True if successful
        """
        import time

        cache_dir = Path(self._parquet_cache_dir)
        cache_dir.mkdir(parents=True, exist_ok=True)
        total_files = end_file - start_file
        downloaded = 0
        max_retries = 3
        for i in range(start_file, end_file):
            url = url_pattern.format(i)
            local_path = cache_dir / f"hits_{i}.parquet"
            if local_path.exists() and local_path.stat().st_size > 0:
                downloaded += 1
                continue
            for attempt in range(max_retries):
                try:
                    result = subprocess.run(
                        [
                            "wget",
                            "--user-agent=benchkit/1.0",
                            "--timeout=60",
                            "--tries=2",
                            "-O",
                            str(local_path),
                            url,
                        ],
                        capture_output=True,
                        timeout=180,
                    )
                    if result.returncode == 0:
                        downloaded += 1
                        break
                    else:
                        if local_path.exists():
                            local_path.unlink()
                        err = result.stderr.decode() if result.stderr else ""
                        if attempt < max_retries - 1:
                            self._log(f"    Retry {attempt + 1}/{max_retries} for {i}")
                            time.sleep(2**attempt)
                        else:
                            last_err = err[-300:] if len(err) > 300 else err
                            self._log(
                                f"    wget exit {result.returncode} for {i}: {last_err}"
                            )
                            return False
                except subprocess.TimeoutExpired:
                    if local_path.exists():
                        local_path.unlink()
                    if attempt < max_retries - 1:
                        self._log(f"    Timeout on partition {i}, retrying...")
                        time.sleep(2**attempt)
                    else:
                        self._log(f"    Timeout downloading partition {i}")
                        return False
                except Exception as e:
                    if local_path.exists():
                        local_path.unlink()
                    self._log(f"    Failed to download partition {i}: {e}")
                    return False
            if downloaded % 10 == 0:
                self._log(f"    Downloaded {downloaded}/{total_files} files...")
            time.sleep(0.1)
        return True

    def _download_parquet_files_remote(
        self,
        node: CloudInstanceManager,
        url_pattern: str,
        start_file: int,
        end_file: int,
    ) -> bool:
        """Download parquet files on a remote node.

        Args:
            node: CloudInstanceManager for the target node
            url_pattern: URL pattern with {} for partition ID
            start_file: Starting file index (inclusive)
            end_file: Ending file index (exclusive)

        Returns:
            True if successful
        """
        node.run_remote_command(f"mkdir -p {self._parquet_cache_dir}", debug=False)
        download_script = f"""#!/bin/bash\ncd {self._parquet_cache_dir}\nfor i in $(seq {start_file} {end_file - 1}); do\n    url="{url_pattern.replace('{}', '$i')}"\n    file="hits_$i.parquet"\n    if [ ! -f "$file" ]; then\n        wget -q --user-agent="benchkit/1.0" "$url" -O "$file" &\n    fi\ndone\nwait\necho "Downloaded files {start_file}-{end_file - 1}"\n"""
        result = node.run_remote_command(download_script, timeout=1800, debug=False)
        return bool(result.get("success", False))

    def _execute_parallel_import(
        self,
        conn: Any,
        nodes: list[Any],
        schema: str,
        staging_table: str,
        columns: list[str],
        num_partitions: int,
        parallel_connections: int,
    ) -> bool:
        """Execute parallel import using pyexasol's HTTP transport.

        This uses pyexasol's import_from_callback feature with multiple
        parallel connections. Each connection streams data from a parquet
        file through a callback function.

        Args:
            conn: pyexasol connection
            nodes: List of nodes with parquet files
            schema: Target schema
            staging_table: Staging table name
            columns: Column names
            num_partitions: Number of parquet files
            parallel_connections: Max parallel connections

        Returns:
            True if successful
        """
        try:
            import pyarrow.parquet as pq
        except ImportError:
            self._log("pyarrow not installed, cannot load Parquet files")
            return False
        num_nodes = len(nodes)
        files_per_node = num_partitions // num_nodes
        remainder = num_partitions % num_nodes
        total_rows = 0
        batch_size = 100000
        for idx, node in enumerate(nodes):
            start_file = idx * files_per_node + min(idx, remainder)
            end_file = start_file + files_per_node + (1 if idx < remainder else 0)
            node_label = f"Node {idx}" if node else "Local"
            for file_idx in range(start_file, end_file):
                pq_filename = f"hits_{file_idx}.parquet"
                parquet_path = Path(self._parquet_cache_dir) / pq_filename
                if not parquet_path.exists():
                    self._log(f"    Warning: Parquet file not found: {parquet_path}")
                    continue
                pq_file = pq.ParquetFile(parquet_path)
                file_rows = 0
                for batch in pq_file.iter_batches(batch_size=batch_size):
                    batch_dict = batch.to_pydict()
                    num_rows = len(batch_dict[columns[0]])
                    data = [
                        tuple(batch_dict[col][i] for col in columns)
                        for i in range(num_rows)
                    ]
                    conn.import_from_iterable(data, table=staging_table)
                    file_rows += len(data)
                    total_rows += len(data)
                if file_rows > 0:
                    self._log(
                        f"    {node_label}: partition {file_idx} ({file_rows:,} rows)"
                    )
        self._log(f"  Total rows loaded: {total_rows:,}")
        return total_rows > 0

    def _create_staging_table(
        self,
        conn: Any,
        source_table: str,
        staging_table: str,
        columns: list[str],
        timestamp_columns: set[str],
        date_columns: set[str],
    ) -> None:
        """Create staging table with raw integer types for timestamp/date columns.

        Args:
            conn: Database connection
            source_table: Original table to get column definitions from
            staging_table: Name for the staging table
            columns: List of column names
            timestamp_columns: Columns that need timestamp transformation
            date_columns: Columns that need date transformation
        """
        result = conn.execute(
            f"SELECT COLUMN_NAME, COLUMN_TYPE FROM EXA_ALL_COLUMNS WHERE COLUMN_TABLE = UPPER('{source_table}') ORDER BY COLUMN_ORDINAL_POSITION"
        )
        col_defs = {row[0]: row[1] for row in result}
        staging_cols = []
        for col in columns:
            col_upper = col.upper()
            if col in timestamp_columns:
                staging_cols.append(f'"{col}" DECIMAL(18,0)')
            elif col in date_columns:
                staging_cols.append(f'"{col}" DECIMAL(10,0)')
            elif col_upper in col_defs:
                col_type = col_defs[col_upper]
                if col_type.upper().startswith("CHAR("):
                    col_type = "VARCHAR(100)"
                staging_cols.append(f'"{col}" {col_type}')
            else:
                staging_cols.append(f'"{col}" VARCHAR(2000000)')
        ddl = f"CREATE TABLE {staging_table} ({', '.join(staging_cols)})"
        conn.execute(f"DROP TABLE IF EXISTS {staging_table}")
        conn.execute(ddl)

    def _build_transform_sql(
        self,
        target_table: str,
        staging_table: str,
        columns: list[str],
        timestamp_columns: set[str],
        date_columns: set[str],
    ) -> str:
        """Build INSERT SELECT with SQL transformations for timestamps/dates.

        Args:
            target_table: Final target table
            staging_table: Staging table with raw data
            columns: List of column names
            timestamp_columns: Columns needing timestamp transformation
            date_columns: Columns needing date transformation

        Returns:
            SQL statement for transformation
        """
        select_cols = []
        for col in columns:
            if col in timestamp_columns:
                select_cols.append(f'FROM_POSIX_TIME("{col}") AS "{col}"')
            elif col in date_columns:
                select_cols.append(
                    f'''ADD_DAYS(DATE '1970-01-01', "{col}") AS "{col}"'''
                )
            else:
                select_cols.append(f'"{col}"')
        return f"\n            INSERT INTO {target_table}\n            SELECT {', '.join(select_cols)}\n            FROM {staging_table}\n        "

    def _cleanup_parquet_files(self, nodes: list[Any]) -> None:
        """Clean up downloaded parquet files from nodes.

        Args:
            nodes: List of nodes to clean up
        """
        for node in nodes:
            if node is None:
                cache_dir = Path(self._parquet_cache_dir)
                if cache_dir.exists():
                    shutil.rmtree(cache_dir, ignore_errors=True)
            else:
                node.run_remote_command(
                    f"rm -rf {self._parquet_cache_dir}", debug=False
                )


def load_via_pyexasol_http_transport(
    system: ExasolSystem,
    table_name: str,
    schema: str,
    columns: list[str],
    parquet_paths: list[Path],
    timestamp_cols: set[str] | None = None,
    date_cols: set[str] | None = None,
    num_parallel: int = 8,
) -> bool:
    """Load parquet files using pyexasol's HTTP transport for true parallelism.

    This function uses pyexasol's export_to_callback/import_from_callback
    for parallel data transfer, avoiding the CSV proxy overhead entirely.

    Args:
        system: ExasolSystem instance
        table_name: Target table name
        schema: Schema name
        columns: Column names
        parquet_paths: List of parquet file paths
        timestamp_cols: Timestamp columns
        date_cols: Date columns
        num_parallel: Number of parallel HTTP connections

    Returns:
        True if successful
    """
    try:
        import pyarrow.parquet as pq
    except ImportError:
        system._log("pyarrow not installed")
        return False
    effective_timestamp_cols = timestamp_cols or set()
    effective_date_cols = date_cols or set()
    conn = None
    staging_table = f"{table_name}_staging"
    try:
        conn = system._get_connection(compression=False)
        conn.execute(f"OPEN SCHEMA {schema}")
        loader = ExarrowLoader(system)
        loader._create_staging_table(
            conn,
            table_name,
            staging_table,
            columns,
            effective_timestamp_cols,
            effective_date_cols,
        )

        def parquet_reader_callback(file_path: Path) -> Any:
            """Generator that yields rows from a parquet file."""
            pq_file = pq.ParquetFile(file_path)
            for batch in pq_file.iter_batches(batch_size=100000):
                batch_dict = batch.to_pydict()
                num_rows = len(batch_dict[columns[0]])
                for i in range(num_rows):
                    yield tuple(batch_dict[col][i] for col in columns)

        total_rows = 0
        for pq_path in parquet_paths:
            if not pq_path.exists():
                system._log(f"Warning: Parquet file not found: {pq_path}")
                continue
            data_gen = parquet_reader_callback(pq_path)
            conn.import_from_iterable(data_gen, table=staging_table)
            pq_file = pq.ParquetFile(pq_path)
            file_rows = pq_file.metadata.num_rows
            total_rows += file_rows
            system._log(f"  Loaded {pq_path.name}: {file_rows:,} rows")
        system._log(f"  Total staged: {total_rows:,} rows")
        transform_sql = loader._build_transform_sql(
            table_name,
            staging_table,
            columns,
            effective_timestamp_cols,
            effective_date_cols,
        )
        conn.execute(transform_sql)
        result = conn.execute(f"SELECT COUNT(*) FROM {table_name}")
        final_rows = result.fetchone()[0]
        conn.execute(f"DROP TABLE IF EXISTS {staging_table}")
        system._log(f"✓ Loaded {final_rows:,} rows into {table_name}")
        return True
    except Exception as e:
        system._log(f"HTTP transport loading failed: {e}")
        if conn:
            try:
                conn.execute(f"DROP TABLE IF EXISTS {staging_table}")
            except Exception:
                pass
        return False
    finally:
        if conn:
            conn.close()
