from __future__ import annotations

"""Exarrow-rs binary management for high-performance Exasol data loading.

This module handles downloading, caching, and managing the exarrow-rs binary,
which provides fast parallel parquet import via Exasol's HTTP tunneling protocol.

exarrow-rs is an ADBC-compatible database driver for Exasol written in Rust that
leverages Apache Arrow for efficient columnar data operations. It supports:
- Parallel HTTP connections for bulk data import
- Parquet to CSV streaming conversion
- Schema inference for automatic table creation

Reference: https://github.com/exasol-labs/exarrow-rs
"""
import hashlib
import platform
import shutil
import stat
import subprocess
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from benchkit.infra.manager import CloudInstanceManager
DEFAULT_EXARROW_VERSION = "0.5.2"
CACHE_DIR = Path.home() / ".cache" / "benchkit" / "exarrow-rs"
RELEASE_URL_PATTERN = "https://github.com/exasol-labs/exarrow-rs/releases/download/v{version}/exarrow-{platform}"
PLATFORM_MAP = {
    ("Linux", "x86_64"): "linux-x86_64",
    ("Linux", "aarch64"): "linux-aarch64",
    ("Darwin", "x86_64"): "darwin-x86_64",
    ("Darwin", "arm64"): "darwin-aarch64",
}


class ExarrowBinaryManager:
    """Manages exarrow-rs binary download and deployment.

    Since exarrow-rs is primarily a Rust library (not a standalone CLI), this
    manager provides two approaches:

    1. If pre-built binaries are available from GitHub releases, download them
    2. Otherwise, build from source using cargo (requires Rust toolchain)

    For benchkit, we use exarrow-rs as a Python library via the ADBC interface,
    which is available through the `adbc-driver-exasol` package. This provides
    the parallel import functionality we need without requiring a separate binary.
    """

    def __init__(
        self, version: str = DEFAULT_EXARROW_VERSION, cache_dir: Path | None = None
    ):
        """Initialize the binary manager.

        Args:
            version: exarrow-rs version to use
            cache_dir: Custom cache directory (default: ~/.cache/benchkit/exarrow-rs)
        """
        self.version = version
        self.cache_dir = cache_dir or CACHE_DIR
        self._platform = self._detect_platform()

    def _detect_platform(self) -> str:
        """Detect the current platform for binary selection.

        Returns:
            Platform string like 'linux-x86_64'
        """
        system = platform.system()
        machine = platform.machine()
        platform_key = (system, machine)
        if platform_key in PLATFORM_MAP:
            return PLATFORM_MAP[platform_key]
        if system == "Linux" and machine in ("amd64", "AMD64"):
            return "linux-x86_64"
        if system == "Darwin" and machine in ("arm64", "ARM64"):
            return "darwin-aarch64"
        raise RuntimeError(
            f"Unsupported platform: {system}/{machine}. Supported: {list(PLATFORM_MAP.values())}"
        )

    def get_binary_path(self) -> Path:
        """Return path to the exarrow-rs binary.

        Returns:
            Path to the binary (may not exist yet)
        """
        return self.cache_dir / self.version / f"exarrow-{self._platform}"

    def ensure_binary(self) -> Path:
        """Download exarrow-rs binary if not present, return path.

        Returns:
            Path to the usable binary

        Raises:
            RuntimeError: If binary cannot be obtained
        """
        binary_path = self.get_binary_path()
        if binary_path.exists() and self._is_executable(binary_path):
            return binary_path
        binary_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            return self._download_binary(binary_path)
        except Exception as download_err:
            try:
                return self._build_from_source(binary_path)
            except Exception as build_err:
                raise RuntimeError(
                    f"Failed to obtain exarrow-rs binary:\n  Download error: {download_err}\n  Build error: {build_err}"
                ) from build_err

    def _download_binary(self, target_path: Path) -> Path:
        """Download pre-built binary from GitHub releases.

        Args:
            target_path: Where to save the binary

        Returns:
            Path to the downloaded binary
        """
        import urllib.request

        url = RELEASE_URL_PATTERN.format(version=self.version, platform=self._platform)
        with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
            tmp_path = Path(tmp_file.name)
        try:
            urllib.request.urlretrieve(url, tmp_path)
            tmp_path.chmod(tmp_path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP)
            shutil.move(tmp_path, target_path)
            return target_path
        except Exception:
            if tmp_path.exists():
                tmp_path.unlink()
            raise

    def _build_from_source(self, target_path: Path) -> Path:
        """Build exarrow-rs from source using cargo.

        This requires the Rust toolchain to be installed.

        Args:
            target_path: Where to save the built binary

        Returns:
            Path to the built binary
        """
        cargo_check = subprocess.run(
            ["cargo", "--version"], capture_output=True, text=True
        )
        if cargo_check.returncode != 0:
            raise RuntimeError(
                "Rust toolchain not found. Install from https://rustup.rs/ or download pre-built exarrow-rs binary."
            )
        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            clone_result = subprocess.run(
                [
                    "git",
                    "clone",
                    "--depth=1",
                    f"--branch=v{self.version}",
                    "https://github.com/exasol-labs/exarrow-rs.git",
                    str(tmp_path / "exarrow-rs"),
                ],
                capture_output=True,
                text=True,
                timeout=120,
            )
            if clone_result.returncode != 0:
                raise RuntimeError(f"Failed to clone exarrow-rs: {clone_result.stderr}")
            build_result = subprocess.run(
                ["cargo", "build", "--release"],
                cwd=tmp_path / "exarrow-rs",
                capture_output=True,
                text=True,
                timeout=600,
            )
            if build_result.returncode != 0:
                raise RuntimeError(f"Failed to build exarrow-rs: {build_result.stderr}")
            binary_name = "exarrow"
            built_binary = tmp_path / "exarrow-rs" / "target" / "release" / binary_name
            if not built_binary.exists():
                raise RuntimeError(f"Built binary not found at {built_binary}")
            shutil.copy2(built_binary, target_path)
            target_path.chmod(target_path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP)
            return target_path

    def _is_executable(self, path: Path) -> bool:
        """Check if a file is executable.

        Args:
            path: Path to check

        Returns:
            True if file exists and is executable
        """
        if not path.exists():
            return False
        return bool(path.stat().st_mode & stat.S_IXUSR)

    def verify_checksum(self, binary_path: Path, expected_sha256: str) -> bool:
        """Verify SHA256 checksum of a binary.

        Args:
            binary_path: Path to the binary
            expected_sha256: Expected SHA256 hash (hex string)

        Returns:
            True if checksum matches
        """
        sha256_hash = hashlib.sha256()
        with open(binary_path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                sha256_hash.update(chunk)
        actual_hash = sha256_hash.hexdigest()
        return actual_hash.lower() == expected_sha256.lower()

    def deploy_to_node(
        self, instance_manager: CloudInstanceManager, remote_path: str = "/tmp/exarrow"
    ) -> bool:
        """Deploy exarrow-rs binary to a remote node via SSH.

        Args:
            instance_manager: CloudInstanceManager for the target node
            remote_path: Where to place the binary on the remote node

        Returns:
            True if deployment successful
        """
        local_binary = self.ensure_binary()
        if not instance_manager.copy_file_to_instance(local_binary, remote_path):
            return False
        chmod_result = instance_manager.run_remote_command(
            f"chmod +x {remote_path}", debug=False
        )
        return bool(chmod_result.get("success", False))


def ensure_exarrow_python_deps() -> bool:
    """Ensure Python dependencies for exarrow-rs ADBC interface are installed.

    The exarrow-rs library can be accessed via Python through the ADBC
    (Arrow Database Connectivity) interface, which provides the same
    parallel import capabilities.

    Returns:
        True if dependencies are available
    """
    import sys

    required_packages = ["adbc-driver-manager", "pyarrow"]
    missing = []
    for pkg in required_packages:
        try:
            __import__(pkg.replace("-", "_"))
        except ImportError:
            missing.append(pkg)
    if missing:
        install_cmd = [sys.executable, "-m", "pip", "install", "-q"] + missing
        result = subprocess.run(install_cmd, capture_output=True, timeout=120)
        return result.returncode == 0
    return True


def get_exarrow_import_command(
    host: str,
    port: int,
    user: str,
    password: str,
    schema: str,
    table: str,
    parquet_files: list[str],
    parallel_connections: int = 100,
) -> list[str]:
    """Build exarrow-rs CLI command for parallel parquet import.

    Note: This function generates the command for the exarrow CLI tool.
    If the CLI is not available, use the Python ADBC interface instead.

    Args:
        host: Exasol host address
        port: Exasol port
        user: Database username
        password: Database password
        schema: Target schema name
        table: Target table name
        parquet_files: List of parquet file paths
        parallel_connections: Number of parallel HTTP connections

    Returns:
        Command list suitable for subprocess.run()
    """
    conn_str = f"exasol://{user}:{password}@{host}:{port}/{schema}"
    cmd = [
        "exarrow",
        "import",
        "--connection",
        conn_str,
        "--table",
        table,
        "--format",
        "parquet",
        "--parallel",
        str(parallel_connections),
    ]
    for pq_file in parquet_files:
        cmd.extend(["--file", pq_file])
    return cmd
