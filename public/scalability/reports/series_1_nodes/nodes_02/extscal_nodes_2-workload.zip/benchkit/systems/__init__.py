"""Database system implementations."""

from typing import Any

from .base import SystemUnderTest
from .clickhouse import ClickHouseSystem
from .exasol import ExasolSystem
from .starrocks import StarrocksSystem
from .trino import TrinoSystem

SYSTEM_IMPLEMENTATIONS = {
    "clickhouse": ClickHouseSystem,
    "exasol": ExasolSystem,
    "starrocks": StarrocksSystem,
    "trino": TrinoSystem,
}


def _lazy_import_system(kind: str) -> type[SystemUnderTest]:
    """Lazy import of system class.

    In the minimal package, all configured systems are already imported,
    so this is a simple lookup in SYSTEM_IMPLEMENTATIONS.
    """
    if kind not in SYSTEM_IMPLEMENTATIONS:
        raise ValueError(f"Unknown system kind: {kind}")
    return SYSTEM_IMPLEMENTATIONS[kind]


def create_system(
    config: dict, output_callback: Any = None, workload_config: dict | None = None
) -> SystemUnderTest:
    """Create a system instance from configuration."""
    kind = config.get("kind")
    if kind not in SYSTEM_IMPLEMENTATIONS:
        available = ", ".join(SYSTEM_IMPLEMENTATIONS.keys())
        raise ValueError(f"Unsupported system: {kind}. Available: {available}")
    return SYSTEM_IMPLEMENTATIONS[kind](
        config, output_callback=output_callback, workload_config=workload_config
    )


__all__ = [
    "SystemUnderTest",
    "create_system",
    "SYSTEM_IMPLEMENTATIONS",
    "_lazy_import_system",
]
