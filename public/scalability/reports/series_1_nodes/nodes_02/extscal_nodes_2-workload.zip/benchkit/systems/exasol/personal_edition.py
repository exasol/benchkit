from __future__ import annotations

"""Exasol Personal Edition - Self-Managed Deployment.

This module provides the ExasolPersonalEdition class for managing
Exasol Personal Edition deployments via the 'exasol' CLI tool.
"""
