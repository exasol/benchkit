from __future__ import annotations

"""Parquet-to-CSV streaming proxy for fast database loading.

This module provides functions to start a CSV proxy server that streams parquet
files as CSV, enabling database systems to use native HTTP IMPORT for fast
bulk loading without Python serialization overhead.

Architecture:
    Remote parquet files (e.g., ClickHouse datasets)
            | (HTTP via DuckDB httpfs)
    CSV Proxy Server (localhost:8765)
        /hits_0.csv -> DuckDB streams parquet->CSV
        /hits_1.csv -> DuckDB streams parquet->CSV
            | (localhost HTTP)
    Database IMPORT FROM CSV AT 'http://localhost:8765/'
        FILE 'hits_0.csv' FILE 'hits_1.csv' ...

The proxy is generic and works with any parquet URL pattern that includes
a partition number placeholder (e.g., "http://example.com/data_{}.parquet").
"""
import base64
import subprocess
import tempfile
import time
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from benchkit.infra.manager import CloudInstanceManager


def _render_proxy_script(
    parquet_url_pattern: str,
    port: int,
    max_concurrent: int = 4,
    local_parquet_path: str | None = None,
    num_partitions: int = 100,
    rows_per_partition: int = 1000000,
) -> str:
    """Render the CSV proxy script with the given parameters.

    The template is embedded directly to work in both development and
    deployed packages (where template files aren't available).

    Args:
        parquet_url_pattern: URL pattern with {} placeholder for partition ID
            Example: "https://example.com/data_{}.parquet"
        port: TCP port for the proxy server
        max_concurrent: Maximum concurrent parquet loads (controls memory usage)
        local_parquet_path: Optional path to local parquet file (faster than remote)
        num_partitions: Number of partitions for local file mode
        rows_per_partition: Rows per partition for local file mode

    Returns:
        Rendered Python script as string
    """
    local_path_str = f'"{local_parquet_path}"' if local_parquet_path else "None"
    return f'''#!/usr/bin/env python3\n"""Parquet-to-CSV streaming proxy server.\n\nThis server streams parquet files as CSV for database bulk loading via HTTP IMPORT.\nDuckDB reads parquet (local or remote) and converts to CSV on-the-fly.\n\nGenerated with parameters:\n- parquet_url_pattern: {parquet_url_pattern}\n- local_parquet_path: {local_parquet_path}\n- port: {port}\n"""\n\nimport io\nimport sys\nimport time\nimport threading\nfrom http.server import BaseHTTPRequestHandler, ThreadingHTTPServer\n\n# Configuration\nPARQUET_URL_PATTERN = "{parquet_url_pattern}"\nLOCAL_PARQUET_PATH = {local_path_str}  # If set, use local file instead of remote\nROWS_PER_PARTITION = {rows_per_partition}\nNUM_PARTITIONS = {num_partitions}\nPORT = {port}\n\n# Limit concurrent parquet loads to control memory usage\nMAX_CONCURRENT_LOADS = {max_concurrent}\n_load_semaphore = threading.Semaphore(MAX_CONCURRENT_LOADS)\n\n# Progress tracking\nBATCH_SIZE = 50000\nLOG_INTERVAL_ROWS = 1000000  # Log every 1M rows\n\n\nclass ParquetCSVHandler(BaseHTTPRequestHandler):\n    """HTTP handler that streams parquet files as CSV via DuckDB."""\n\n    def log_message(self, *args):\n        """Suppress HTTP access logs."""\n        pass\n\n    def do_GET(self):\n        """Handle GET requests for CSV files.\n\n        Expected path format: /prefix_N.csv where N is the partition ID.\n        Example: /hits_42.csv -> fetches partition 42\n        """\n        import duckdb\n\n        # Parse path to extract partition ID\n        # Supports patterns like /hits_42.csv, /part_0.csv, etc.\n        path = self.path.lstrip("/")\n        if not path.endswith(".csv"):\n            self.send_error(404, "Expected .csv extension")\n            return\n\n        # Extract partition ID from filename (last number before .csv)\n        basename = path[:-4]  # Remove .csv\n        # Find the partition number (after last underscore or hyphen)\n        for sep in ["_", "-"]:\n            if sep in basename:\n                try:\n                    partition_id = int(basename.rsplit(sep, 1)[1])\n                    break\n                except (ValueError, IndexError):\n                    continue\n        else:\n            # Try parsing the whole basename as a number\n            try:\n                partition_id = int(basename)\n            except ValueError:\n                self.send_error(400, f"Cannot extract partition ID from: {{path}}")\n                return\n\n        # Acquire semaphore to limit concurrent parquet loads (memory control)\n        _load_semaphore.acquire()\n        try:\n            # Set up DuckDB\n            conn = duckdb.connect(":memory:")\n\n            # Choose data source: local file (faster) or remote URL\n            if LOCAL_PARQUET_PATH:\n                # Local file mode: use LIMIT/OFFSET to partition\n                offset = partition_id * ROWS_PER_PARTITION\n                query = f"SELECT * FROM read_parquet('{{LOCAL_PARQUET_PATH}}') LIMIT {{ROWS_PER_PARTITION}} OFFSET {{offset}}"\n            else:\n                # Remote mode: fetch partitioned file via httpfs\n                conn.execute("INSTALL httpfs; LOAD httpfs;")\n                parquet_url = PARQUET_URL_PATTERN.format(partition_id)\n                query = f"SELECT * FROM read_parquet('{{parquet_url}}')"\n\n            # Execute query\n            result = conn.execute(query)\n            if result.description is None:\n                self.send_error(500, "No columns returned from parquet file")\n                return\n            columns = [desc[0] for desc in result.description]\n\n            # Send HTTP headers with chunked transfer encoding for streaming\n            self.send_response(200)\n            self.send_header("Content-Type", "text/csv; charset=utf-8")\n            self.send_header("Transfer-Encoding", "chunked")\n            self.end_headers()\n\n            def send_chunk(data):\n                """Send data as HTTP chunk."""\n                self.wfile.write(f"{{len(data):x}}\\r\\n".encode("ascii"))\n                self.wfile.write(data)\n                self.wfile.write(b"\\r\\n")\n                self.wfile.flush()\n\n            # Write CSV header\n            send_chunk((",".join(columns) + "\\n").encode("utf-8"))\n\n            # Stream data in batches with progress logging\n            start_time = time.time()\n            total_rows = 0\n            total_bytes = 0\n            last_log_rows = 0\n\n            print(f"[partition {{partition_id}}] Starting transfer...", flush=True)\n\n            while True:\n                batch = result.fetchmany(BATCH_SIZE)\n                if not batch:\n                    break\n\n                buf = io.StringIO()\n                for row in batch:\n                    # Simple CSV escaping: remove commas, quotes, newlines from values\n                    # This is sufficient for numeric/simple string data\n                    line = ",".join(\n                        ""\n                        if v is None\n                        else str(v).replace(",", "").replace('"', "").replace("\\n", " ")\n                        for v in row\n                    )\n                    buf.write(line + "\\n")\n\n                chunk_data = buf.getvalue().encode("utf-8")\n                chunk_bytes = len(chunk_data)\n                send_chunk(chunk_data)\n\n                total_rows += len(batch)\n                total_bytes += chunk_bytes\n\n                # Log progress every LOG_INTERVAL_ROWS rows\n                if total_rows - last_log_rows >= LOG_INTERVAL_ROWS:\n                    elapsed = time.time() - start_time\n                    rate_mb = (total_bytes / 1024 / 1024) / elapsed if elapsed > 0 else 0\n                    rate_rows = total_rows / elapsed if elapsed > 0 else 0\n                    print(\n                        f"[partition {{partition_id}}] {{total_rows:,}} rows, "\n                        f"{{total_bytes / 1024 / 1024:.1f}} MB sent "\n                        f"({{rate_mb:.1f}} MB/s, {{rate_rows:,.0f}} rows/s)",\n                        flush=True,\n                    )\n                    last_log_rows = total_rows\n\n            # End chunked transfer (zero-length chunk)\n            send_chunk(b"")\n            conn.close()\n\n            # Final summary\n            elapsed = time.time() - start_time\n            rate_mb = (total_bytes / 1024 / 1024) / elapsed if elapsed > 0 else 0\n            print(\n                f"[partition {{partition_id}}] COMPLETE: {{total_rows:,}} rows, "\n                f"{{total_bytes / 1024 / 1024:.1f}} MB in {{elapsed:.1f}}s "\n                f"({{rate_mb:.1f}} MB/s)",\n                flush=True,\n            )\n\n        except Exception as e:\n            print(f"[partition {{partition_id}}] ERROR: {{e}}", flush=True)\n            try:\n                self.send_error(500, f"Error: {{e}}")\n            except Exception:\n                pass\n        finally:\n            _load_semaphore.release()\n\n\ndef main():\n    """Start the CSV proxy server."""\n    print(f"Starting CSV proxy on port {{PORT}}...")\n    print(f"Parquet URL pattern: {{PARQUET_URL_PATTERN}}")\n    server = ThreadingHTTPServer(("0.0.0.0", PORT), ParquetCSVHandler)\n    server.serve_forever()\n\n\nif __name__ == "__main__":\n    main()\n'''


def start_csv_proxy_local(
    parquet_url_pattern: str,
    port: int = 8765,
    max_concurrent: int = 4,
    local_parquet_path: str | None = None,
    num_partitions: int = 100,
    rows_per_partition: int = 1000000,
    log_callback: Any | None = None,
) -> subprocess.Popen[bytes]:
    """Start the CSV proxy server locally as a subprocess.

    The proxy runs as a separate process and streams parquet files as CSV
    for database HTTP IMPORT operations.

    Args:
        parquet_url_pattern: URL pattern with {} placeholder for partition ID
        port: TCP port to listen on (default: 8765)
        max_concurrent: Maximum concurrent parquet loads (controls memory)
        local_parquet_path: Optional path to local parquet file (faster than remote)
        num_partitions: Number of partitions for local file mode
        rows_per_partition: Rows per partition for local file mode
        log_callback: Optional callback for logging messages

    Returns:
        subprocess.Popen instance (call .terminate() to stop)
    """

    def _log(msg: str) -> None:
        if log_callback:
            log_callback(msg)
        else:
            print(msg)

    import sys

    _log("  Ensuring DuckDB is installed...")
    install_result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "-q", "duckdb"],
        capture_output=True,
        timeout=120,
    )
    if install_result.returncode != 0:
        _log("  Warning: DuckDB installation may have failed")
    script_content = _render_proxy_script(
        parquet_url_pattern,
        port,
        max_concurrent,
        local_parquet_path,
        num_partitions,
        rows_per_partition,
    )
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as tmp_file:
        tmp_file.write(script_content)
        script_path = tmp_file.name
    _log(f"  Starting local CSV proxy on port {port}...")
    log_file_path = tempfile.mktemp(suffix="_proxy.log")
    with open(log_file_path, "w") as log_file:
        process = subprocess.Popen(
            [sys.executable, "-u", script_path],
            stdout=log_file,
            stderr=subprocess.STDOUT,
        )
    time.sleep(1)
    if process.poll() is not None:
        try:
            with open(log_file_path) as f:
                log_content = f.read()
        except Exception:
            log_content = ""
        raise RuntimeError(f"CSV proxy failed to start: {log_content}")
    _log(f"  CSV proxy started (PID: {process.pid})")
    _log(f"  Proxy log: {log_file_path}")
    process.log_file_path = log_file_path
    return process


def start_csv_proxy_on_nodes(
    cloud_managers: list[CloudInstanceManager],
    parquet_url_pattern: str,
    port: int = 8765,
    log_callback: Any | None = None,
) -> None:
    """Start CSV proxy on all cluster nodes via SSH.

    Deploys the rendered proxy script to each node and starts it as a
    background process. For multinode clusters, each node runs its own
    proxy, allowing parallel data fetching from the source.

    Args:
        cloud_managers: List of CloudInstanceManager for each node
        parquet_url_pattern: URL pattern with {} placeholder for partition ID
        port: TCP port for the proxy (default: 8765)
        log_callback: Optional callback for logging messages
    """

    def _log(msg: str) -> None:
        if log_callback:
            log_callback(msg)
        else:
            print(msg)

    script_content = _render_proxy_script(parquet_url_pattern, port)
    script_b64 = base64.b64encode(script_content.encode()).decode()
    for idx, mgr in enumerate(cloud_managers):
        _log(f"  Node {idx}: Installing DuckDB and deploying CSV proxy...")
        install_result = mgr.run_remote_command(
            "pip install -q duckdb 2>/dev/null || pip3 install -q duckdb 2>/dev/null",
            debug=False,
        )
        if not install_result.get("success", False):
            _log(f"  Node {idx}: Warning - DuckDB installation may have issues")
        deploy_cmd = f"\necho '{script_b64}' | base64 -d > /tmp/csv_proxy.py\nchmod +x /tmp/csv_proxy.py\n"
        mgr.run_remote_command(deploy_cmd, debug=False)
        start_cmd = "nohup python3 /tmp/csv_proxy.py > /tmp/csv_proxy.log 2>&1 &"
        mgr.run_remote_command(start_cmd, debug=False)
        _log(f"  Node {idx}: CSV proxy started on port {port}")


def stop_csv_proxy_on_nodes(
    cloud_managers: list[CloudInstanceManager], log_callback: Any | None = None
) -> None:
    """Stop CSV proxy on all cluster nodes.

    Args:
        cloud_managers: List of CloudInstanceManager for each node
        log_callback: Optional callback for logging messages
    """

    def _log(msg: str) -> None:
        if log_callback:
            log_callback(msg)
        else:
            print(msg)

    for idx, mgr in enumerate(cloud_managers):
        result = mgr.run_remote_command(
            "pkill -f 'python.*csv_proxy.py' || true", debug=False
        )
        if result.get("success", False):
            _log(f"  Node {idx}: CSV proxy stopped")


def wait_for_proxy_ready(
    port: int = 8765, timeout: float = 30.0, log_callback: Any | None = None
) -> bool:
    """Wait for the local CSV proxy to be ready to accept connections.

    Args:
        port: TCP port the proxy is listening on
        timeout: Maximum time to wait in seconds
        log_callback: Optional callback for logging messages

    Returns:
        True if proxy is ready, False if timeout
    """
    import socket

    def _log(msg: str) -> None:
        if log_callback:
            log_callback(msg)
        else:
            print(msg)

    start_time = time.time()
    while time.time() - start_time < timeout:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            result = sock.connect_ex(("127.0.0.1", port))
            sock.close()
            if result == 0:
                return True
        except Exception:
            pass
        time.sleep(0.5)
    _log(f"  Warning: CSV proxy not ready after {timeout}s")
    return False


def print_proxy_log(
    process: subprocess.Popen[bytes], log_callback: Any | None = None
) -> None:
    """Print the CSV proxy log contents.

    Call this after the proxy has finished or been terminated to see
    the progress and completion messages.

    Args:
        process: The Popen object returned by start_csv_proxy_local
        log_callback: Optional callback for logging messages
    """

    def _log(msg: str) -> None:
        if log_callback:
            log_callback(msg)
        else:
            print(msg)

    log_path = getattr(process, "log_file_path", None)
    if not log_path:
        return
    try:
        with open(log_path) as f:
            content = f.read()
        if content.strip():
            _log("  CSV proxy output:")
            for line in content.strip().split("\n"):
                _log(f"    {line}")
    except Exception as e:
        _log(f"  Could not read proxy log: {e}")
