from __future__ import annotations

"""Exasol cluster management using c4 and confd_client.

This module handles cluster management operations like getting play IDs,
executing confd_client commands, installing licenses, and configuring
database parameters.
"""
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .system import ExasolSystem


class ExasolClusterManager:
    """Handles Exasol cluster management operations.

    This class encapsulates operations that interact with the Exasol cluster
    via the c4 tool and confd_client commands.
    """

    def __init__(self, system: ExasolSystem):
        """Initialize the cluster manager.

        Args:
            system: Parent ExasolSystem instance for shared state access
        """
        self._system = system

    def _log(self, message: str) -> None:
        """Log a message using the parent system's logger."""
        self._system._log(message)

    def get_cluster_play_id(self) -> str | None:
        """Get the cluster play_id from c4 ps command.

        Returns:
            The play_id string, or None if not found
        """
        system = self._system
        ps_result = system.execute_command(
            "c4 ps",
            timeout=30,
            description="Get cluster play ID for confd_client operations",
            category="cluster_management",
        )
        if ps_result["success"]:
            lines = ps_result.get("stdout", "").strip().split("\n")
            if len(lines) >= 2:
                play_id: str = lines[1].split()[1]
                system.record_setup_note(f"Found cluster play ID: {play_id}")
                return play_id
            else:
                system.record_setup_note(
                    "⚠ Warning: Could not parse play ID from c4 ps output"
                )
                return None
        else:
            system.record_setup_note(
                f"⚠ Warning: Failed to get cluster info: {ps_result.get('stderr', 'Unknown error')}"
            )
            return None
