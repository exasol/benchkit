from __future__ import annotations

"""Minimal multi-file HTTP server for streaming parquet as CSV on demand.

Uses only Python stdlib at startup. pyarrow is imported lazily on the
first actual request from Exasol, so idle server processes consume
almost no memory.

Key memory optimisation: uses pyarrow.csv.write_csv() to convert Arrow
batches directly to CSV bytes — pandas is never imported.  Column
selection is pushed down to the parquet reader so only needed columns
are decoded.  Batches are small (10 000 rows) to bound peak memory
when many concurrent threads serve different files.

Supports serving multiple parquet files from a directory, routed by URL
path (e.g., /hits_0.csv serves hits_0.parquet). This allows a small
number of server processes to serve many files, avoiding the memory
overhead of one process per file.

Usage:
    # Single file mode:
    python http_csv_server.py --file /path/to/data.parquet --port 8000

    # Directory mode (serves files by URL path):
    python http_csv_server.py --dir /path/to/parquet_dir --port 8000
"""
import argparse
import io
import os
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn

_file_path: str = ""
_dir_path: str = ""
_columns: list[str] | None = None


class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    """HTTPServer that handles each request in a new thread."""

    daemon_threads = True


class CSVHandler(BaseHTTPRequestHandler):
    """Streams parquet file as CSV. Imports pyarrow only on first GET."""

    def do_GET(self) -> None:
        if _dir_path:
            requested = self.path.strip("/")
            base = requested.rsplit(".", 1)[0] if "." in requested else requested
            parquet_path = os.path.join(_dir_path, base + ".parquet")
            if not os.path.exists(parquet_path):
                self.send_error(404, f"File not found: {base}.parquet")
                return
        else:
            parquet_path = _file_path
        try:
            import pyarrow.csv as pa_csv
            import pyarrow.parquet as pq
        except ImportError:
            self.send_error(500, "pyarrow not installed")
            return
        self.send_response(200)
        self.send_header("Content-Type", "text/csv")
        self.end_headers()
        write_opts = pa_csv.WriteOptions(include_header=False)
        pq_file = pq.ParquetFile(parquet_path)
        for batch in pq_file.iter_batches(batch_size=10000, columns=_columns):
            buf = io.BytesIO()
            pa_csv.write_csv(batch, buf, write_options=write_opts)
            self.wfile.write(buf.getvalue())

    def log_message(self, format: str, *args: object) -> None:
        """Suppress default stderr request logging."""


def main() -> None:
    global _file_path, _dir_path, _columns
    parser = argparse.ArgumentParser(description="Serve parquet as CSV via HTTP")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--file", "-f", help="Single parquet file path")
    group.add_argument("--dir", "-d", help="Directory of parquet files")
    parser.add_argument(
        "--port", "-p", type=int, required=True, help="Port to listen on"
    )
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind to")
    parser.add_argument(
        "--columns", "-c", help="Comma-separated column names (optional)"
    )
    args = parser.parse_args()
    if args.file:
        _file_path = args.file
    if args.dir:
        _dir_path = args.dir
    _columns = args.columns.split(",") if args.columns else None
    server = ThreadingHTTPServer((args.host, args.port), CSVHandler)
    print(f"READY:{args.port}", flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
