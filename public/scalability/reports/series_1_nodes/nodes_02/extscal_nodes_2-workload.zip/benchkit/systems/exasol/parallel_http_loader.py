from __future__ import annotations

"""Parallel HTTP-based parquet loader for Exasol.

This module provides high-performance parallel data loading by:
1. Starting multiple HTTP servers (one per parquet file) on each node
2. Each server streams parquet data as CSV
3. Exasol IMPORT with multiple AT clauses pulls from all servers in parallel

Architecture:
┌─────────────────────────────────────────────────────────────────┐
│                    Benchmark Runner (Coordinator)                │
│                                                                  │
│  1. Distribute parquet files to nodes via SSH/SCP               │
│  2. Start HTTP servers on each node (one per file)              │
│  3. Build IMPORT SQL with all server URLs (AT clauses)          │
│  4. Execute single IMPORT - Exasol pulls from all in parallel   │
└─────────────────────────────────────────────────────────────────┘
"""
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

if TYPE_CHECKING:
    from benchkit.infra.manager import CloudInstanceManager

    from .system import ExasolSystem
CLICKBENCH_PARQUET_URL_PATTERN = (
    "https://datasets.clickhouse.com/hits_compatible/athena_partitioned/hits_{}.parquet"
)


class ParallelHttpLoader:
    """High-performance parallel parquet loader using HTTP servers.

    Uses a distributed architecture that works for single-node (1 node)
    and multi-node (N nodes) deployments. Each parquet file gets its own
    HTTP server, and Exasol imports from all servers in parallel.
    """

    def __init__(self, system: ExasolSystem, cache_dir: str | None = None):
        """Initialize the loader.

        Args:
            system: Parent ExasolSystem instance
            cache_dir: Directory to store downloaded parquet files
        """
        self._system = system
        self._parquet_cache_dir = cache_dir or "/tmp/benchkit_parquet"
        self._base_port = 8000
        self._server_processes: list[
            tuple[Any, subprocess.Popen[bytes] | dict[str, Any]]
        ] = []

    def _log(self, message: str) -> None:
        """Log a message using the parent system's logger."""
        self._system._log(message)

    @staticmethod
    def _get_local_ip() -> str:
        """Get the machine's routable private IP address.

        Uses a UDP socket trick to find the IP the OS would use to route
        traffic, without actually sending any data. Required because the
        c4 local play has its own network namespace — 127.0.0.1 from inside
        Exasol does not reach the host's loopback.
        """
        import socket

        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip: str = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"

    def load_parquet_files_distributed(
        self,
        table_name: str,
        schema: str,
        parquet_url_pattern: str,
        num_partitions: int,
        columns: list[str],
        timestamp_cols: set[str] | None = None,
        date_cols: set[str] | None = None,
        parallel_connections: int = 100,
        max_http_servers: int | None = None,
    ) -> bool:
        """Load parquet files via distributed HTTP servers.

        Workflow:
        1. Distribute parquet files across node(s) via SSH
        2. Create staging table with raw types
        3. Start HTTP servers (one per file) on all nodes
        4. Execute single IMPORT with all AT clauses (parallel pull)
        5. Transform timestamps/dates via SQL INSERT SELECT
        6. Drop staging table

        Args:
            table_name: Target table name (must already exist)
            schema: Schema name containing the target table
            parquet_url_pattern: URL pattern with {} for partition ID
            num_partitions: Number of parquet partitions to load
            columns: List of column names
            timestamp_cols: Columns containing Unix timestamps
            date_cols: Columns containing dates as days since epoch
            parallel_connections: Number of parallel connections (unused, for API compat)
            max_http_servers: Maximum HTTP servers per node (default: 16, use load_workers in config)

        Returns:
            True if data loaded successfully
        """
        effective_timestamp_cols = timestamp_cols or set()
        effective_date_cols = date_cols or set()
        nodes = self._get_nodes()
        num_nodes = len(nodes)
        self._log(f"Starting parallel HTTP import with {num_nodes} node(s)...")
        self._log(f"  Loading {num_partitions} files into {schema}.{table_name}")
        try:
            self._log("Step 1: Distributing parquet files to node(s)...")
            if not self._distribute_parquet_files(
                nodes, parquet_url_pattern, num_partitions
            ):
                self._log("Failed to distribute parquet files")
                return False
            self._log("Step 2: Creating staging table...")
            staging_table = f"{table_name}_staging"
            conn = self._system._get_connection(compression=False)
            try:
                conn.execute(f"OPEN SCHEMA {schema}")
                self._create_staging_table(
                    conn,
                    table_name,
                    staging_table,
                    columns,
                    effective_timestamp_cols,
                    effective_date_cols,
                )
                effective_max_servers = max_http_servers if max_http_servers else 16
                self._log(
                    f"Step 3: Loading data via parallel HTTP import (max {effective_max_servers} servers per node)..."
                )
                if not self._execute_parallel_import(
                    conn,
                    nodes,
                    schema,
                    staging_table,
                    columns,
                    num_partitions,
                    max_http_servers=effective_max_servers,
                ):
                    raise RuntimeError("Parallel import failed")
                result = conn.execute(f"SELECT COUNT(*) FROM {staging_table}")
                staged_rows = result.fetchone()[0]
                self._log(f"  Staged {staged_rows:,} rows")
                self._log("Step 4: Transforming timestamps and dates...")
                transform_sql = self._build_transform_sql(
                    table_name,
                    staging_table,
                    columns,
                    effective_timestamp_cols,
                    effective_date_cols,
                )
                conn.execute(transform_sql)
                result = conn.execute(f"SELECT COUNT(*) FROM {table_name}")
                final_rows = result.fetchone()[0]
                self._log(f"  Transformed {final_rows:,} rows into {table_name}")
                conn.execute(f"DROP TABLE IF EXISTS {staging_table}")
                self._log("  Staging table dropped")
                self._log(f"✓ Loaded {final_rows:,} rows via parallel HTTP import")
                return True
            finally:
                conn.close()
        except Exception as e:
            self._log(f"Parallel HTTP loading failed: {e}")
            try:
                cleanup_conn = self._system._get_connection(compression=False)
                staging = f"{schema}.{table_name}_staging"
                cleanup_conn.execute(f"DROP TABLE IF EXISTS {staging}")
                cleanup_conn.close()
            except Exception:
                pass
            return False
        finally:
            self._stop_all_servers()
            self._cleanup_parquet_files(nodes)

    def _get_nodes(self) -> list[Any]:
        """Get list of nodes (cloud instance managers) to use.

        Returns:
            List of CloudInstanceManager objects, or a single-element list
            with None for local execution
        """
        if (
            self._system._cloud_instance_managers
            and len(self._system._cloud_instance_managers) > 0
        ):
            return self._system._cloud_instance_managers
        elif self._system._cloud_instance_manager:
            return [self._system._cloud_instance_manager]
        else:
            return [None]

    def _distribute_parquet_files(
        self, nodes: list[Any], url_pattern: str, num_partitions: int
    ) -> bool:
        """Download and distribute parquet files across nodes.

        Each node gets an equal share of files to process.

        Args:
            nodes: List of CloudInstanceManager objects
            url_pattern: URL pattern with {} for partition ID
            num_partitions: Total number of partitions

        Returns:
            True if successful
        """
        num_nodes = len(nodes)
        files_per_node = num_partitions // num_nodes
        remainder = num_partitions % num_nodes
        for idx, node in enumerate(nodes):
            start_file = idx * files_per_node + min(idx, remainder)
            end_file = start_file + files_per_node + (1 if idx < remainder else 0)
            file_count = end_file - start_file
            node_label = f"Node {idx}" if node else "Local"
            self._log(
                f"  {node_label}: Downloading files {start_file}-{end_file - 1} ({file_count} files)"
            )
            if node is None:
                if not self._download_parquet_files_local(
                    url_pattern, start_file, end_file
                ):
                    return False
            elif not self._download_parquet_files_remote(
                node, url_pattern, start_file, end_file
            ):
                return False
        return True

    def _download_parquet_files_local(
        self, url_pattern: str, start_file: int, end_file: int
    ) -> bool:
        """Download parquet files locally using wget with retry logic."""
        cache_dir = Path(self._parquet_cache_dir)
        cache_dir.mkdir(parents=True, exist_ok=True)
        total_files = end_file - start_file
        downloaded = 0
        max_retries = 3
        for i in range(start_file, end_file):
            url = url_pattern.format(i)
            local_path = cache_dir / f"hits_{i}.parquet"
            if local_path.exists() and local_path.stat().st_size > 0:
                downloaded += 1
                continue
            for attempt in range(max_retries):
                try:
                    result = subprocess.run(
                        [
                            "wget",
                            "-q",
                            "--user-agent=benchkit/1.0",
                            "--timeout=60",
                            "--tries=3",
                            "--retry-connrefused",
                            "--waitretry=5",
                            "-O",
                            str(local_path),
                            url,
                        ],
                        capture_output=True,
                        timeout=180,
                    )
                    if result.returncode == 0:
                        downloaded += 1
                        break
                    else:
                        if local_path.exists():
                            local_path.unlink()
                        if attempt < max_retries - 1:
                            self._log(f"    Retry {attempt + 1}/{max_retries} for {i}")
                            time.sleep(2**attempt)
                        else:
                            self._log(f"    Failed to download partition {i}")
                            return False
                except subprocess.TimeoutExpired:
                    if local_path.exists():
                        local_path.unlink()
                    if attempt < max_retries - 1:
                        time.sleep(2**attempt)
                    else:
                        self._log(f"    Timeout downloading partition {i}")
                        return False
            if downloaded % 10 == 0:
                self._log(f"    Downloaded {downloaded}/{total_files} files...")
            time.sleep(0.1)
        return True

    def _download_parquet_files_remote(
        self,
        node: CloudInstanceManager,
        url_pattern: str,
        start_file: int,
        end_file: int,
    ) -> bool:
        """Download parquet files on a remote node."""
        node.run_remote_command(f"mkdir -p {self._parquet_cache_dir}", debug=False)
        download_script = f"""#!/bin/bash\ncd {self._parquet_cache_dir}\nfor i in $(seq {start_file} {end_file - 1}); do\n    url="{url_pattern.replace('{}', '$i')}"\n    file="hits_$i.parquet"\n    if [ ! -f "$file" ]; then\n        wget -q --tries=3 --retry-connrefused --waitretry=5 --user-agent="benchkit/1.0" "$url" -O "$file" &\n    fi\ndone\nwait\necho "Downloaded files {start_file}-{end_file - 1}"\n"""
        result = node.run_remote_command(download_script, timeout=1800, debug=False)
        return bool(result.get("success", False))

    def _execute_parallel_import(
        self,
        conn: Any,
        nodes: list[Any],
        schema: str,
        staging_table: str,
        columns: list[str],
        num_partitions: int,
        max_http_servers: int = 16,
    ) -> bool:
        """Execute parallel import using HTTP servers.

        This starts one HTTP server per parquet file, then executes a single
        IMPORT statement with multiple AT clauses. Exasol pulls from all
        servers in parallel.

        Args:
            conn: pyexasol connection
            nodes: List of nodes with parquet files
            schema: Target schema
            staging_table: Staging table name
            columns: Column names
            num_partitions: Number of parquet files
            max_http_servers: Maximum HTTP servers per node (default: 16)

        Returns:
            True if successful
        """
        num_nodes = len(nodes)
        files_per_node = num_partitions // num_nodes
        remainder = num_partitions % num_nodes
        server_urls: list[str] = []
        columns_arg = ",".join(columns)
        max_servers_per_node = min(max_http_servers, num_partitions)
        try:
            for node_idx, node in enumerate(nodes):
                start_file = node_idx * files_per_node + min(node_idx, remainder)
                end_file = (
                    start_file + files_per_node + (1 if node_idx < remainder else 0)
                )
                node_files = end_file - start_file
                if node is None:
                    host_ip = self._get_local_ip()
                else:
                    host_ip = node.private_ip
                n_servers = min(max_servers_per_node, node_files)
                self._log(
                    f"  Starting {n_servers} HTTP servers on {('local' if node is None else f'node {node_idx}')} (serving {node_files} files)..."
                )
                node_ports: list[int] = []
                for s_idx in range(n_servers):
                    port = self._base_port + node_idx * max_servers_per_node + s_idx
                    server_handle: subprocess.Popen[bytes] | dict[str, Any]
                    if node is None:
                        server_handle = self._start_local_server_dir(
                            self._parquet_cache_dir, port, columns_arg
                        )
                    else:
                        server_handle = self._start_remote_server_dir(
                            node, self._parquet_cache_dir, port, columns_arg
                        )
                    self._server_processes.append((node, server_handle))
                    node_ports.append(port)
                for file_idx in range(start_file, end_file):
                    port = node_ports[file_idx % n_servers]
                    server_urls.append(f"http://{host_ip}:{port}/hits_{file_idx}.csv")
            self._log(
                f"  Waiting for {len(self._server_processes)} servers to be ready..."
            )
            time.sleep(3)
            alive_count = 0
            dead_count = 0
            for _node, proc_handle in self._server_processes:
                if isinstance(proc_handle, subprocess.Popen):
                    rc = proc_handle.poll()
                    if rc is None:
                        alive_count += 1
                    else:
                        dead_count += 1
                        if dead_count <= 3:
                            try:
                                out = (
                                    cast(bytes, proc_handle.stdout.read(2000)).decode(
                                        errors="replace"
                                    )
                                    if proc_handle.stdout
                                    else ""
                                )
                            except Exception:
                                out = "<unreadable>"
                            self._log(
                                f"  ⚠ Server process exited with code {rc}: {out}"
                            )
                else:
                    alive_count += 1
            self._log(f"  Server status: {alive_count} alive, {dead_count} dead")
            if dead_count > 0 and alive_count == 0:
                raise RuntimeError(
                    f"All {dead_count} HTTP server processes crashed on startup"
                )
            at_clauses = "\n".join(

                    f"  AT '{url.rsplit('/', 1)[0]}/' FILE '{url.rsplit('/', 1)[1]}'"
                    for url in server_urls

            )
            import_sql = f"\n                IMPORT INTO {schema}.{staging_table}\n                FROM CSV\n                {at_clauses}\n                COLUMN SEPARATOR = ','\n                SKIP = 0\n            "
            self._log(
                f"  Executing IMPORT with {len(server_urls)} AT clauses across {alive_count} servers..."
            )
            conn.execute(import_sql)
            self._log("  Import completed successfully")
            return True
        except Exception as e:
            self._log(f"  Parallel import error: {e}")
            return False

    def _start_local_server_dir(
        self, parquet_dir: str, port: int, columns: str
    ) -> subprocess.Popen[bytes]:
        """Start a local directory-mode HTTP CSV server."""
        server_script = Path(__file__).parent / "http_csv_server.py"
        proc = subprocess.Popen(
            [
                sys.executable,
                str(server_script),
                "--dir",
                parquet_dir,
                "--port",
                str(port),
                "--columns",
                columns,
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        return proc

    def _start_remote_server_dir(
        self, node: CloudInstanceManager, parquet_dir: str, port: int, columns: str
    ) -> dict[str, Any]:
        """Start a remote directory-mode HTTP CSV server via SSH.

        Returns a dict with info for stopping later.
        """
        server_script = Path(__file__).parent / "http_csv_server.py"
        server_content = server_script.read_text()
        import base64

        script_b64 = base64.b64encode(server_content.encode()).decode()
        deploy_cmd = f"echo '{script_b64}' | base64 -d > /tmp/http_csv_server.py"
        node.run_remote_command(deploy_cmd, debug=False)
        start_cmd = f"nohup python3 /tmp/http_csv_server.py --dir {parquet_dir} --port {port} --columns {columns} > /tmp/http_server_{port}.log 2>&1 &"
        node.run_remote_command(start_cmd, debug=False)
        return {"node": node, "port": port}

    def _stop_all_servers(self) -> None:
        """Stop all HTTP servers."""
        for node, handle in self._server_processes:
            try:
                if isinstance(handle, subprocess.Popen):
                    handle.terminate()
                    handle.wait(timeout=5)
                elif isinstance(handle, dict):
                    port = handle.get("port")
                    if port and node is not None:
                        node.run_remote_command(
                            f"pkill -f 'http_csv_server.py.*--port {port}' || true",
                            debug=False,
                        )
            except Exception:
                pass
        self._server_processes.clear()

    def _create_staging_table(
        self,
        conn: Any,
        source_table: str,
        staging_table: str,
        columns: list[str],
        timestamp_columns: set[str],
        date_columns: set[str],
    ) -> None:
        """Create staging table with raw integer types for timestamp/date columns."""
        result = conn.execute(
            f"SELECT COLUMN_NAME, COLUMN_TYPE FROM EXA_ALL_COLUMNS WHERE COLUMN_TABLE = UPPER('{source_table}') ORDER BY COLUMN_ORDINAL_POSITION"
        )
        col_defs = {row[0]: row[1] for row in result}
        staging_cols = []
        for col in columns:
            col_upper = col.upper()
            if col in timestamp_columns:
                staging_cols.append(f'"{col}" DECIMAL(18,0)')
            elif col in date_columns:
                staging_cols.append(f'"{col}" DECIMAL(10,0)')
            elif col_upper in col_defs:
                col_type = col_defs[col_upper]
                if col_type.upper().startswith("CHAR("):
                    col_type = "VARCHAR(100)"
                staging_cols.append(f'"{col}" {col_type}')
            else:
                staging_cols.append(f'"{col}" VARCHAR(2000000)')
        ddl = f"CREATE TABLE {staging_table} ({', '.join(staging_cols)})"
        conn.execute(f"DROP TABLE IF EXISTS {staging_table}")
        conn.execute(ddl)

    def _build_transform_sql(
        self,
        target_table: str,
        staging_table: str,
        columns: list[str],
        timestamp_columns: set[str],
        date_columns: set[str],
    ) -> str:
        """Build INSERT SELECT with SQL transformations for timestamps/dates."""
        select_cols = []
        for col in columns:
            if col in timestamp_columns:
                select_cols.append(f'FROM_POSIX_TIME("{col}") AS "{col}"')
            elif col in date_columns:
                select_cols.append(
                    f'''ADD_DAYS(DATE '1970-01-01', "{col}") AS "{col}"'''
                )
            else:
                select_cols.append(f'"{col}"')
        return f"\n            INSERT INTO {target_table}\n            SELECT {', '.join(select_cols)}\n            FROM {staging_table}\n        "

    def _cleanup_parquet_files(self, nodes: list[Any]) -> None:
        """Clean up downloaded parquet files from nodes."""
        for node in nodes:
            if node is None:
                cache_dir = Path(self._parquet_cache_dir)
                if cache_dir.exists():
                    shutil.rmtree(cache_dir, ignore_errors=True)
            else:
                node.run_remote_command(
                    f"rm -rf {self._parquet_cache_dir}", debug=False
                )
