"""Minimal exasol system implementation for workload execution."""

from .system import ExasolSystem

__all__ = ["ExasolSystem"]
