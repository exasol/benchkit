"""Base classes for database systems under test."""

import re
from abc import ABC, abstractmethod
from collections.abc import Callable, Iterable
from datetime import timedelta
from pathlib import Path
from typing import Any, Literal

from benchkit.common import DataFormat

from ..util import safe_command

TableOperation = Literal["DEFAULT", "OPTIMIZE TABLE", "MATERIALIZE STATISTICS"]


class SystemUnderTest(ABC):
    """Abstract base class for database systems under test."""

    SUPPORTS_MULTINODE: bool = False
    SUPPORTS_STREAMLOAD: bool = False
    SUPPORTS_EXTERNAL_TABLES: bool = False

    def __init__(
        self,
        config: dict[str, Any],
        output_callback: Callable[[str], None] | None = None,
        workload_config: dict[str, Any] | None = None,
    ):
        self.name = config["name"]
        self.kind = config["kind"]
        self.version = config["version"]
        if "setup" not in config:
            raise ValueError(
                f"System config for '{self.name}' is missing 'setup' section"
            )
        if config["setup"] is None:
            raise ValueError(
                f"System config for '{self.name}' has None 'setup' section"
            )
        self.setup_config = config["setup"]
        self.data_dir: Path | None = Path(
            self.setup_config.get("data_dir", f"/data/{self.name}")
        )
        self.config = config
        self._connection = None
        self._is_running = False
        project_id = config.get("project_id", "")
        self.container_name = (
            f"{self.kind}_{project_id}_{self.name}"
            if project_id
            else f"{self.kind}_{self.name}"
        )
        self._output_callback = output_callback
        self.workload_config = workload_config or {}
        self.schema: str | None = None
        self.setup_commands: list[dict[str, Any]] = []
        self.installation_notes: list[str] = []
        self.node_count: int = self.setup_config.get("node_count", 1)
        assert self.node_count >= 1, "node_count must be positive"
        self._cloud_instance_manager: Any = None
        self._cloud_instance_managers: list[Any] = []
        self._external_host: str | None = None

    def _log(self, message: str) -> None:
        """
        Thread-safe logging that respects parallel execution context.

        Use this method instead of print() to ensure correct system name tagging
        when systems are being installed/configured in parallel.

        When output_callback is set (e.g., by BenchmarkRunner during parallel execution),
        output is routed directly to the ParallelExecutor's task buffer, bypassing
        the thread-unsafe contextlib.redirect_stdout mechanism. This prevents the
        race condition where output from one system could get tagged with another
        system's name.

        Args:
            message: Message to log

        Note:
            - Always use _log() instead of print() in system implementations
            - When output_callback is None, falls back to print() (sequential execution)
            - The callback is automatically set by BenchmarkRunner._get_system_for_context()
              when running in parallel mode
        """
        if self._output_callback:
            self._output_callback(message)
        else:
            print(message)

    def _install_docker(self) -> bool:
        """Install using Docker. Override in subclasses or use _install_docker_common()."""
        raise NotImplementedError("Subclass must implement _install_docker()")

    def _install_native(self) -> bool:
        """Install natively. Override in subclasses."""
        raise NotImplementedError("Subclass must implement _install_native()")

    def _verify_preinstalled(self) -> bool:
        """Verify preinstalled system is accessible. Default: check health."""
        return self.is_healthy()

    @abstractmethod
    def is_healthy(self, quiet: bool = False) -> bool:
        """
        Check if the database system is running and healthy.

        Returns:
            True if system is healthy, False otherwise
        """
        pass

    @abstractmethod
    def create_schema(self, schema_name: str) -> bool:
        """
        Create a database schema/database.

        Args:
            schema_name: Name of the schema to create

        Returns:
            True if creation successful, False otherwise
        """
        pass

    def get_data_generation_directory(self, workload: Any) -> Path | None:
        """Get directory for data generation. Uses /data/generated if use_additional_disk is set."""
        explicit_data_dir = self.setup_config.get("data_dir")
        if explicit_data_dir:
            return Path(
                str(explicit_data_dir), "generated", workload.safe_display_name()
            )
        if self.setup_config.get("use_additional_disk", False):
            tpch_gen_dir = "/data/generated"
            self.execute_command(
                f"sudo mkdir -p {tpch_gen_dir} && sudo chown -R $(whoami):$(whoami) {tpch_gen_dir}",
                record=False,
            )
            return Path(tpch_gen_dir, workload.safe_display_name())
        return None

    def get_storage_backend(self) -> Any:
        """Get the storage backend configured for this system.

        For systems that support external tables (SUPPORTS_EXTERNAL_TABLES=True),
        this returns the storage backend (LocalStorage or S3Storage) used for
        storing workload data.

        Returns:
            StorageBackend instance or None if not applicable

        Override in subclasses that support external tables.
        """
        return None

    def ensure_storage_permissions(self) -> bool:
        """Ensure storage directory has correct permissions for table creation.

        For systems that use external tables (like Trino with Hive metastore),
        the storage directories may need specific permissions to allow both
        the data upload process and the metastore to write.

        This is called AFTER data upload but BEFORE table creation.

        Returns:
            True if permissions are correct, False on failure.

        Override in subclasses that need special permission handling.
        """
        return True

    def get_template_variables(self) -> dict[str, Any]:
        """Return system-specific template variables for SQL template rendering.

        Override in subclasses to provide custom variables like external table
        locations, storage paths, etc. These variables are merged into the
        template context when rendering setup scripts.

        Returns:
            Dictionary of template variable names to values
        """
        return {}

    @abstractmethod
    def load_data(self, table_name: str, data_path: Path, **kwargs: Any) -> bool:
        """
        Load data into a table.

        Args:
            table_name: Name of the target table
            data_path: Path to the data file
            **kwargs: Additional parameters for data loading

        Returns:
            True if loading successful, False otherwise
        """
        pass

    @abstractmethod
    def load_data_from_iterable(
        self,
        table_name: str,
        data_source: Iterable[Any],
        data_format: DataFormat,
        **kwargs: Any,
    ) -> bool:
        """
        Load data into a table.

        Args:
            table_name: Name of the target table
            data_source: An iterable containing row data (could be list[list[Any]] or list[str] or ...)
            data_format: Format of the data, from text-based CSV/TSV/... to structured list/dict/...
            **kwargs: Additional parameters for data loading

        Returns:
            True if loading successful, False otherwise
        """
        pass

    def set_active_schema(self, schema_name: str) -> None:
        """Set the active schema for all subsequent query executions.

        This ensures thread-safe schema handling in multi-stream workloads.
        When set, this schema takes precedence over the instance-level schema
        configuration for all new connections.

        Args:
            schema_name: Name of the schema/database to use for queries
        """
        self._active_schema = schema_name

    @abstractmethod
    def execute_query(
        self,
        query: str,
        query_name: str | None = None,
        return_data: bool = False,
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """
        Execute a SQL query and return timing and result information.

        Args:
            query: SQL query to execute
            query_name: Optional name for the query (for logging)
            return_data: If True, include result data in response (default: False)
            timeout: Optional timeout in seconds for query execution

        Returns:
            Dictionary containing:
            - success: bool
            - elapsed_s: float (execution time in seconds)
            - rows_returned: int (number of rows returned)
            - error: str (error message if failed)
            - query_name: str (name of the query)
            - data: pd.DataFrame (only if return_data=True, query results as DataFrame)
        """
        pass

    @abstractmethod
    def get_system_metrics(self) -> dict[str, Any]:
        """
        Get system-specific performance metrics.

        Returns:
            Dictionary containing system metrics like:
            - memory_usage
            - cache_hit_ratio
            - active_connections
            - etc.
        """
        pass

    @abstractmethod
    def teardown(self) -> bool:
        """
        Clean up and remove the database system.

        Returns:
            True if teardown successful, False otherwise
        """
        pass

    def cleanup_data_directory(self) -> bool:
        """Clean up data directory."""
        if self.data_dir is None:
            return True
        try:
            if self.data_dir.exists():
                import shutil

                shutil.rmtree(self.data_dir)
            return True
        except Exception as e:
            self._log(f"Failed to cleanup data directory {self.data_dir}: {e}")
            return False

    def execute_command(
        self,
        command: str,
        timeout: float | None = None,
        record: bool = True,
        category: str = "setup",
        node_info: str | None = None,
    ) -> dict[str, Any]:
        """Execute a system command safely and optionally record it.

        Commands are executed either locally or remotely depending on whether
        a cloud instance manager is set and _should_execute_remotely() returns True.

        Args:
            command: Command to execute
            timeout: Command timeout in seconds
            record: Whether to record command for report reproduction
            category: Category for organizing commands in report
            node_info: Node information (e.g., "node0", "all nodes", "node1,node2")
        """
        if self._should_execute_remotely():
            return self._execute_remote_command(
                command, timeout, record, category, node_info
            )
        else:
            return self._execute_local_command(
                command, timeout, record, category, node_info
            )

    def _execute_local_command(
        self,
        command: str,
        timeout: float | None = None,
        record: bool = True,
        category: str = "setup",
        node_info: str | None = None,
    ) -> dict[str, Any]:
        """Execute a command locally using safe_command."""
        result = safe_command(command, timeout=timeout)
        if record:
            command_record = {
                "command": command,
                "success": result["success"],
                "description": f"Execute {command.split()[0]} command",
                "category": category,
            }
            if node_info:
                command_record["node_info"] = node_info
            self.setup_commands.append(command_record)
        return result

    def _execute_remote_command(
        self,
        command: str,
        timeout: float | None = None,
        record: bool = True,
        category: str = "setup",
        node_info: str | None = None,
    ) -> dict[str, Any]:
        """Execute a command on remote cloud instance via instance manager."""
        result = self._cloud_instance_manager.run_remote_command(
            command, timeout=int(timeout) if timeout else 300
        )
        if record:
            command_record = {
                "command": self._sanitize_command_for_report(command),
                "success": result.get("success", False),
                "description": f"Execute {command.split()[0]} command on remote system",
                "category": category,
            }
            if node_info:
                command_record["node_info"] = node_info
            self.setup_commands.append(command_record)
        return dict(result)

    def wait_for_health(self, max_attempts: int = 30, delay: float = 2.0) -> bool:
        """
        Wait for the system to become healthy.

        Args:
            max_attempts: Maximum number of health check attempts
            delay: Delay between attempts in seconds

        Returns:
            True if system became healthy, False if timeout
        """
        import time

        for attempt in range(max_attempts):
            quiet = attempt < max_attempts - 1
            if self.is_healthy(quiet=quiet):
                return True
            if attempt < max_attempts - 1:
                time.sleep(delay)
        return False

    def _sanitize_command_for_report(self, command: str) -> str:
        """Replace sensitive information in commands with placeholders for reports."""
        import os

        sensitive_replacements = {}
        if hasattr(self, "setup_config") and self.setup_config:
            if self.setup_config.get("image_password"):
                sensitive_replacements[self.setup_config["image_password"]] = (
                    "<EXASOL_IMAGE_PASSWORD>"
                )
            if self.setup_config.get("db_password"):
                sensitive_replacements[self.setup_config["db_password"]] = (
                    "<EXASOL_DB_PASSWORD>"
                )
            if self.setup_config.get("admin_password"):
                sensitive_replacements[self.setup_config["admin_password"]] = (
                    "<EXASOL_ADMIN_PASSWORD>"
                )
            if self.setup_config.get("password"):
                sensitive_replacements[self.setup_config["password"]] = (
                    "<DATABASE_PASSWORD>"
                )
        sensitive_replacements[os.path.expanduser("~/.ssh/id_rsa")] = "~/.ssh/id_rsa"
        sanitized = command
        for actual_value, placeholder in sensitive_replacements.items():
            sanitized = sanitized.replace(str(actual_value), placeholder)

        sanitized = re.sub(
            "\\b10\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\b", "<PRIVATE_IP>", sanitized
        )
        sanitized = re.sub(
            "\\b172\\.(1[6-9]|2\\d|3[01])\\.\\d{1,3}\\.\\d{1,3}\\b",
            "<PRIVATE_IP>",
            sanitized,
        )
        sanitized = re.sub(
            "\\b192\\.168\\.\\d{1,3}\\.\\d{1,3}\\b", "<PRIVATE_IP>", sanitized
        )
        sanitized = re.sub(
            "(?<![=:@])(?<![a-zA-Z0-9-])(?!127\\.0\\.0\\.1\\b)(?!localhost\\b)\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\b",
            "<PUBLIC_IP>",
            sanitized,
        )
        return sanitized

    def __str__(self) -> str:
        return f"{self.kind} {self.version} ({self.name})"

    def __repr__(self) -> str:
        return f"SystemUnderTest(name='{self.name}', kind='{self.kind}', version='{self.version}')"

    @classmethod
    def get_python_dependencies(cls) -> list[str]:
        """Return list of Python packages required by this system."""
        return []

    @staticmethod
    def _resolve_env_var(value: str) -> str:
        """Resolve environment variable placeholders like $VAR_NAME."""
        import os

        if isinstance(value, str) and value.startswith("$"):
            return os.environ.get(value[1:], value)
        return value

    @classmethod
    def _get_connection_defaults(cls) -> dict[str, Any]:
        """Override in subclasses to provide system-specific connection defaults."""
        return {
            "port": None,
            "username": None,
            "password": "",
            "schema_key": "schema",
            "schema": None,
        }

    @classmethod
    def _get_password_key(cls, setup_config: dict[str, Any]) -> str:
        """Override in subclasses if password key varies (e.g., db_password vs password)."""
        return "password"

    @classmethod
    def _extend_connection_info(
        cls, conn_info: dict[str, Any], setup_config: dict[str, Any]
    ) -> None:
        """Override in subclasses to add system-specific connection info."""
        pass

    @classmethod
    def extract_workload_connection_info(
        cls, setup_config: dict[str, Any], for_local_execution: bool = False
    ) -> dict[str, Any]:
        """Extract connection info using template method pattern. Subclasses override hooks."""
        defaults = cls._get_connection_defaults()
        host = (
            "localhost"
            if for_local_execution
            else cls._resolve_env_var(setup_config.get("host", "localhost"))
        )
        password_key = cls._get_password_key(setup_config)
        schema_key = defaults.get("schema_key", "schema")
        conn_info = {
            "host": host,
            "port": setup_config.get("port", defaults["port"]),
            "username": setup_config.get("username", defaults["username"]),
            "password": setup_config.get(password_key, defaults["password"]),
            schema_key: setup_config.get(schema_key, defaults["schema"]),
        }
        if setup_config.get("use_additional_disk", False):
            conn_info["use_additional_disk"] = True
        if setup_config.get("node_count", 1) > 1:
            conn_info["node_count"] = setup_config["node_count"]
        cls._extend_connection_info(conn_info, setup_config)
        return conn_info

    @classmethod
    def get_required_ports(cls) -> dict[str, int]:
        """
        Return ports required by this system for AWS security group configuration.

        Returns:
            Dictionary with port descriptions as keys and port numbers as values
        """
        return {}

    def _get_health_check_host(self) -> str:
        """
        Get the host to use for health checks, preferring external IP for remote systems.

        Priority:
        1. _external_host if explicitly set
        2. public_ip from cloud instance manager if available
        3. self.host as final fallback

        Returns:
            Host string to use for health checks
        """
        health_check_host: str | None = self._external_host
        if not health_check_host and self._cloud_instance_manager:
            health_check_host = getattr(self._cloud_instance_manager, "public_ip", None)
        if not health_check_host:
            health_check_host = getattr(self, "host", "localhost")
        return str(health_check_host) if health_check_host else "localhost"

    def _should_execute_remotely(self) -> bool:
        """
        Check if commands should be executed remotely.

        Override in subclasses if remote execution depends on additional conditions
        (e.g., ClickHouse checks setup_method == "native").

        Returns:
            True if commands should be executed on remote cloud instance
        """
        return self._cloud_instance_manager is not None

    def _parse_memory_size(self, memory_str: str) -> int:
        """
        Parse memory size string like '32g', '1024m' to bytes.

        Args:
            memory_str: Memory size string with optional unit suffix (g, m, k)

        Returns:
            Memory size in bytes
        """
        memory_str = memory_str.lower().strip()
        if memory_str.endswith("g"):
            return int(memory_str[:-1]) * 1024 * 1024 * 1024
        elif memory_str.endswith("m"):
            return int(memory_str[:-1]) * 1024 * 1024
        elif memory_str.endswith("k"):
            return int(memory_str[:-1]) * 1024
        else:
            return int(memory_str)

    def _get_int_config(self, config: dict[str, Any], key: str, default: int) -> int:
        """
        Safely get an integer value from config, handling both string and int inputs.

        Args:
            config: Configuration dictionary
            key: Key to look up
            default: Default value if key not present

        Returns:
            Integer value (converted from string if necessary)
        """
        value = config.get(key, default)
        if isinstance(value, str):
            return int(value)
        return int(value)

    def _resolve_ip_addresses(self, ip_config: str) -> str:
        """
        Resolve IP address placeholders with actual values from infrastructure.

        Handles environment variable substitution (e.g., $EXASOL_PUBLIC_IP)
        and InfraManager-based resolution.

        Args:
            ip_config: IP address string or environment variable placeholder

        Returns:
            Resolved IP address string
        """
        import os

        if not ip_config:
            return "localhost"
        if ip_config.startswith("$"):
            env_var = ip_config[1:]
            try:
                from benchkit.infra.manager import InfraManager

                project_id = self.config.get("project_id", "")
                resolved = InfraManager.resolve_ip_from_infrastructure(
                    env_var, self.name, project_id
                )
                if resolved:
                    return str(resolved)
            except ImportError:
                pass
            return os.environ.get(env_var, ip_config)
        return ip_config

    def estimate_execution_time(
        self, operation: TableOperation, data_size_gb: float
    ) -> timedelta:
        """
        Calculate an estimated (pessimistic) execution time for the given operation,
        based on system properties and table size.

        The default implementation returns a fixed value of 5 minutes

        Args:
            operation: The operation to take place
            data_size_gb: estimated size of data to operate on
        """
        return timedelta(minutes=5)

    def split_sql_statements(self, sql: str) -> list[str]:
        """
        Split SQL script into individual statements.
        Method is not static in case some system uses different syntax for splitting

        Handles:
        - Semicolon-separated statements
        - SQL comments (-- and /* */)
        - Empty lines

        Returns:
            List of individual SQL statements
        """
        statements = []
        current_statement = []
        in_comment = False
        for line in sql.split("\n"):
            stripped = line.strip()
            if stripped.startswith("--"):
                continue
            if "/*" in stripped:
                in_comment = True
            if "*/" in stripped:
                in_comment = False
                continue
            if in_comment:
                continue
            if not stripped:
                continue
            if stripped.endswith(";"):
                current_statement.append(stripped[:-1])
                statements.append("\n".join(current_statement))
                current_statement = []
            else:
                current_statement.append(stripped)
        if current_statement:
            statements.append("\n".join(current_statement))
        return statements


def get_system_class(system_kind: str) -> type | None:
    """
    Dynamically import and return the system class for the given system kind.

    Args:
        system_kind: The system identifier (e.g., 'exasol', 'clickhouse', 'postgres')

    Returns:
        The system class if found, None otherwise
    """
    import importlib
    import inspect

    class_name = f"{system_kind.capitalize()}System"
    module_name = f"benchkit.systems.{system_kind}"
    try:
        module = importlib.import_module(module_name)
        if hasattr(module, class_name):
            cls = getattr(module, class_name)
            return cls if isinstance(cls, type) else None
        else:
            for attr_name in dir(module):
                attr = getattr(module, attr_name)
                if (
                    inspect.isclass(attr)
                    and issubclass(attr, SystemUnderTest)
                    and (attr != SystemUnderTest)
                    and hasattr(attr, "get_python_dependencies")
                ):
                    return attr
            return None
    except ImportError:
        return None
