from __future__ import annotations

"""Exasol native installer using c4 tool.

This module handles native installation of Exasol clusters using the c4 tool.
It is excluded from benchmark packages as it's only needed for infrastructure setup.
"""
from pathlib import Path
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from .system import ExasolSystem

class ExasolNativeInstaller:
    """Handles native Exasol installation via c4 cluster tool.

    This class encapsulates the complex c4-based installation process,
    including multinode cluster setup, SSH key distribution, and storage
    configuration.
    """

    def __init__(self, system: ExasolSystem):
        """Initialize the native installer.

        Args:
            system: Parent ExasolSystem instance for shared state access
        """
        self._system = system

    def _log(self, message: str) -> None:
        """Log a message using the parent system's logger."""
        self._system._log(message)

    def _handle_license_file(self) -> str | None:
        """Handle license file if specified.

        Returns:
            Remote path to license file, or None if not specified
        """
        system = self._system
        if not system.license_file or not Path(system.license_file).exists():
            return None
        system.record_setup_note(f'Using Exasol license file: {system.license_file}')
        if system._cloud_instance_manager:
            remote_license_path = '/tmp/exasol.license'
            system.record_setup_note(f'Copying license file to remote system: {remote_license_path}')
            if not system._cloud_instance_manager.copy_file_to_instance(Path(system.license_file), remote_license_path):
                self._log('Failed to copy license file to remote instance')
                return None
            return remote_license_path
        else:
            return str(system.license_file)

    def _setup_exasol_user(self) -> bool:
        """Create exasol user on all nodes.

        Returns:
            True if successful
        """
        system = self._system
        if not system.execute_command_on_all_nodes('sudo useradd -m -s /bin/bash exasol || true', description='Create Exasol system user', category='user_setup'):
            self._log('Warning: Failed to create exasol user on some nodes')
        if not system.execute_command_on_all_nodes('sudo usermod -aG sudo exasol || true', description='Add exasol user to sudo group', category='user_setup'):
            self._log('Warning: Failed to add exasol to sudo group on some nodes')
        if not system.execute_command_on_all_nodes('sudo sed -i "/%sudo/s/) ALL$/) NOPASSWD: ALL/" /etc/sudoers', description='Configuring passwordless sudo on all nodes'):
            self._log('Warning: Failed to configure passwordless sudo on some nodes')
        system.record_setup_command('sudo passwd exasol', 'Set password for exasol user (interactive)', 'user_setup')
        return True

    def _setup_storage(self, storage_disk_size: str) -> tuple[bool, str, str | None]:
        """Setup storage disk for Exasol.

        Args:
            storage_disk_size: Size of storage disk

        Returns:
            Tuple of (use_additional_disk, storage_disk_path, data_dir)
        """
        system = self._system
        use_additional_disk = system.setup_config.get('use_additional_disk', False)
        if use_additional_disk:
            if system._exasol_raw_partition:
                actual_device_path = system._exasol_raw_partition
                storage_disk_path = system._create_storage_symlink(actual_device_path)
                system.data_device = storage_disk_path
                system.record_setup_note(f'Using partitioned raw disk: {actual_device_path} (via {storage_disk_path})')
                self._log(f'✓ Using pre-partitioned raw disk for Exasol: {actual_device_path} (via {storage_disk_path})')
                return (True, storage_disk_path, None)
            else:
                detected_disk = system._detect_exasol_disk(allow_mounted=True)
                if detected_disk:
                    devices = system._detect_storage_devices(skip_root=True)
                    device_info = next((d for d in devices if d['path'] == detected_disk), None)
                    if device_info and device_info['mounted_at']:
                        self._log(f"Disk {detected_disk} is mounted at {device_info['mounted_at']}, unmounting...")
                        if not system._unmount_disk(detected_disk):
                            self._log(f'Error: Could not unmount {detected_disk}')
                            use_additional_disk = False
                    if use_additional_disk:
                        storage_disk_path = system._create_storage_symlink(detected_disk)
                        system.data_device = storage_disk_path
                        system.record_setup_command(f'lsblk {detected_disk}', f'Using additional disk: {detected_disk} (via {storage_disk_path})', 'storage_setup')
                        system.record_setup_note(f'Using additional disk: {detected_disk} (via {storage_disk_path})')
                        return (True, storage_disk_path, None)
                else:
                    self._log('Warning: No suitable additional disk found, falling back to file storage')
                    use_additional_disk = False
        return self._setup_loopback_storage(storage_disk_size)

    def _setup_loopback_storage(self, storage_disk_size: str) -> tuple[bool, str, str | None]:
        """Setup loopback device storage as fallback.

        Args:
            storage_disk_size: Size of storage file

        Returns:
            Tuple of (use_additional_disk=False, storage_disk_path, data_dir)
        """
        system = self._system
        data_dir = system.setup_config.get('data_dir', '/tmp/exasol_storage')
        storage_file_path = f'{data_dir}/storage_disk1'
        exasol_storage_link = '/dev/exasol.storage'
        if not system.execute_command_on_all_nodes(f'sudo mkdir -p {data_dir}', description='Create Exasol data directory', category='storage_setup'):
            self._log('Failed to create data directory on some nodes')
            return (False, '', None)
        if not system.execute_command_on_all_nodes(f'sudo truncate -s {storage_disk_size} {storage_file_path}', description=f'Create {storage_disk_size} storage disk file', category='storage_setup'):
            self._log('Failed to create storage file on some nodes')
            return (False, '', None)
        system.execute_command_on_all_nodes(f'sudo chown -R exasol:exasol {data_dir}', description='Set ownership of data directory to exasol user', category='storage_setup')
        system.execute_command_on_all_nodes(f'sudo losetup -d $(losetup -j {storage_file_path} | cut -d: -f1) 2>/dev/null || true', description='Detaching existing loopback on all nodes')
        system.execute_command_on_all_nodes(f'sudo rm -f {exasol_storage_link}', description='Removing old symlink on all nodes')
        losetup_cmd = f'LOOP_DEV=$(sudo losetup --find --show {storage_file_path}) && sudo ln -sf $LOOP_DEV {exasol_storage_link} && echo $LOOP_DEV'
        if not system.execute_command_on_all_nodes(losetup_cmd, description=f'Setup loopback device for storage file with symlink {exasol_storage_link}', category='storage_setup'):
            self._log('Failed to setup loopback device on some nodes')
            return (False, '', None)
        system.execute_command_on_all_nodes(f'ls -la {exasol_storage_link} && sudo losetup -a | grep {storage_file_path}', description='Verifying loopback setup on all nodes')
        system.data_device = f'{storage_file_path} (via {exasol_storage_link})'
        return (False, exasol_storage_link, data_dir)

    def _download_c4(self, c4_version: str) -> bool:
        """Download the c4 tool.

        Args:
            c4_version: Version of c4 to download

        Returns:
            True if successful
        """
        system = self._system
        c4_url = f'https://x-up.s3.amazonaws.com/releases/c4/linux/x86_64/{c4_version}/c4'
        result = system.execute_command(f'wget -q --tries=3 --retry-connrefused --waitretry=5 {c4_url} -O c4 && chmod +x c4', description=f'Download c4 cluster management tool v{c4_version}', category='tool_setup')
        if not result['success']:
            self._log(f"Failed to download c4: {result['stderr']}")
            return False
        self._log(f'✓ Downloaded c4 v{c4_version}')
        return True

    def _setup_ssh_keys(self, host_addrs: str, host_external_addrs: str) -> bool:
        """Setup SSH keys for cluster communication.

        Args:
            host_addrs: Space-separated list of private IPs
            host_external_addrs: Space-separated list of public IPs

        Returns:
            True if successful
        """
        system = self._system
        system.record_setup_command('ssh-keygen -t rsa -b 2048 -f ~/.ssh/id_rsa -N ""', 'Generate SSH key pair for cluster communication', 'ssh_setup')
        system.execute_command('test -e ~/.ssh/id_rsa || ssh-keygen -t rsa -b 2048 -f ~/.ssh/id_rsa -N ""', record=False)
        pub_key_result = system.execute_command('cat ~/.ssh/id_rsa.pub', record=False)
        if not pub_key_result['success']:
            self._log('Failed to read SSH public key')
            return False
        pub_key = pub_key_result['stdout'].strip()
        self._log(f'Distributing SSH key to all {len(system._cloud_instance_managers)} nodes...')
        setup_cmd = f"sudo mkdir -p ~exasol/.ssh && echo '{pub_key}' | sudo tee ~exasol/.ssh/authorized_keys > /dev/null && sudo chown -R exasol:exasol ~exasol/.ssh && sudo chmod 700 ~exasol/.ssh && sudo chmod 600 ~exasol/.ssh/authorized_keys"
        if not system.execute_command_on_all_nodes(setup_cmd, description='Distribute ubuntu SSH key to exasol user', category='ssh_setup'):
            self._log('Failed to distribute SSH key to all nodes')
            return False
        self._log('Testing SSH connectivity to all nodes...')
        host_list = host_addrs.split()
        for (idx, host) in enumerate(host_list):
            result = system.execute_command(f'ssh -o StrictHostKeyChecking=no exasol@{host} sudo uptime', record=False)
            if result['success']:
                self._log(f'  ✓ SSH connectivity confirmed to node {idx} ({host})')
            else:
                self._log(f'  ✗ Failed SSH connectivity to node {idx} ({host})')
                return False
        self._setup_localhost_ssh()
        self._setup_exasol_ssh(host_addrs, host_external_addrs)
        return True

    def _setup_localhost_ssh(self) -> None:
        """Setup ubuntu→exasol@localhost SSH access on all nodes."""
        system = self._system
        self._log('Setting up ubuntu→exasol@localhost SSH access on all nodes...')
        localhost_ssh_cmd = 'ssh-keyscan -H localhost >> ~/.ssh/known_hosts 2>/dev/null || true\nssh-keyscan -H 127.0.0.1 >> ~/.ssh/known_hosts 2>/dev/null || true\nmkdir -p ~/.ssh\ntouch ~/.ssh/config\ngrep -q "Host localhost" ~/.ssh/config 2>/dev/null || cat >> ~/.ssh/config << \'SSHEOF\'\n\nHost localhost 127.0.0.1\n    StrictHostKeyChecking no\n    UserKnownHostsFile /dev/null\n    LogLevel ERROR\nSSHEOF\nchmod 600 ~/.ssh/config'
        system.execute_command_on_all_nodes(localhost_ssh_cmd, description='Configure localhost SSH access to exasol user', category='ssh_setup')
        for (idx, mgr) in enumerate(system._cloud_instance_managers):
            test_result = mgr.run_remote_command("ssh -o BatchMode=yes exasol@localhost 'echo ok' 2>/dev/null", timeout=30)
            if test_result.get('success') and 'ok' in test_result.get('stdout', ''):
                self._log(f'  ✓ SSH ubuntu→exasol@localhost verified on node {idx}')
            else:
                self._log(f'  ⚠ SSH ubuntu→exasol@localhost verification failed on node {idx}')

    def _setup_exasol_ssh(self, host_addrs: str, host_external_addrs: str) -> None:
        """Setup exasol→exasol SSH access on all nodes."""
        system = self._system
        self._log('Setting up exasol→exasol SSH access on all nodes...')
        keygen_cmd = 'sudo -u exasol bash -c \'mkdir -p ~/.ssh && chmod 700 ~/.ssh && if [ ! -f ~/.ssh/id_rsa ]; then ssh-keygen -t rsa -b 2048 -f ~/.ssh/id_rsa -N "" -q; fi\''
        system.execute_command_on_all_nodes(keygen_cmd, description='Generate SSH key pair for exasol user', category='ssh_setup')
        exasol_pub_keys = []
        for (_idx, mgr) in enumerate(system._cloud_instance_managers):
            result = mgr.run_remote_command('sudo cat ~exasol/.ssh/id_rsa.pub', timeout=30)
            if result.get('success'):
                key = result.get('stdout', '').strip()
                if key:
                    exasol_pub_keys.append(key)
        self._log(f'Distributing {len(exasol_pub_keys)} exasol keys to all nodes...')
        for (_idx, mgr) in enumerate(system._cloud_instance_managers):
            for pub_key in exasol_pub_keys:
                add_key_cmd = f"echo '{pub_key}' | sudo tee -a ~exasol/.ssh/authorized_keys > /dev/null"
                mgr.run_remote_command(add_key_cmd, timeout=30)
            mgr.run_remote_command('sudo chown exasol:exasol ~exasol/.ssh/authorized_keys && sudo chmod 600 ~exasol/.ssh/authorized_keys', timeout=30)
        system.record_setup_command("# Collect exasol public keys from all nodes, distribute to all authorized_keys\nsudo cat ~exasol/.ssh/id_rsa.pub  # on each node\necho '<KEY>' | sudo tee -a ~exasol/.ssh/authorized_keys > /dev/null\nsudo chown exasol:exasol ~exasol/.ssh/authorized_keys && sudo chmod 600 ~exasol/.ssh/authorized_keys", 'Cross-distribute exasol SSH keys for cluster communication', 'ssh_setup', f'all_nodes_{len(system._cloud_instance_managers)}')
        all_hosts = ['localhost', '127.0.0.1']
        all_hosts.extend(host_addrs.split())
        all_hosts.extend(host_external_addrs.split())
        hosts_pattern = ' '.join(all_hosts)
        exasol_ssh_config_cmd = f"""sudo -u exasol bash -c '\nmkdir -p ~/.ssh && chmod 700 ~/.ssh\ntouch ~/.ssh/config && chmod 600 ~/.ssh/config\ngrep -q "Host localhost" ~/.ssh/config 2>/dev/null || cat >> ~/.ssh/config << SSHEOF\n\nHost {hosts_pattern}\n    StrictHostKeyChecking no\n    UserKnownHostsFile /dev/null\n    LogLevel ERROR\nSSHEOF\n'"""
        system.execute_command_on_all_nodes(exasol_ssh_config_cmd, description='Configure exasol SSH config for cluster nodes', category='ssh_setup')
        for (idx, mgr) in enumerate(system._cloud_instance_managers):
            test_result = mgr.run_remote_command("sudo -u exasol ssh -o BatchMode=yes exasol@localhost 'echo ok' 2>/dev/null", timeout=30)
            if test_result.get('success') and 'ok' in test_result.get('stdout', ''):
                self._log(f'  ✓ SSH exasol→exasol@localhost verified on node {idx}')
            else:
                self._log(f'  ⚠ SSH exasol→exasol@localhost verification failed on node {idx}')

    def _create_c4_config(self, host_addrs: str, host_external_addrs: str, storage_disk_path: str, image_password: str, db_password: str, admin_password: str, working_copy: str, db_mem_size: int | None, use_additional_disk: bool, data_dir: str | None) -> str | None:
        """Create c4 configuration file.

        Returns:
            Remote path to config file, or None on failure
        """
        system = self._system
        config_content = f'CCC_HOST_ADDRS="{host_addrs}"\nCCC_HOST_EXTERNAL_ADDRS="{host_external_addrs}"\nCCC_HOST_DATADISK={storage_disk_path}\nCCC_HOST_IMAGE_USER=exasol\nCCC_HOST_IMAGE_PASSWORD={image_password}\nCCC_HOST_KEY_PAIR_FILE=id_rsa\nCCC_PLAY_RESERVE_NODES=0\nCCC_PLAY_WORKING_COPY={working_copy}\nCCC_PLAY_DB_PASSWORD={db_password}\nCCC_PLAY_ADMIN_PASSWORD={admin_password}'
        if not use_additional_disk and data_dir:
            config_content += f'\nCCC_PLAY_MOUNTS={data_dir}:{data_dir}'
        if db_mem_size:
            config_content += f'\nCCC_PLAY_DB_MEM_SIZE={db_mem_size}'
        config_content += '\nCCC_ADMINUI_START_SERVER=true'
        system.record_setup_note('C4 Configuration file content:')
        for line in config_content.split('\n'):
            sanitized_line = system._sanitize_command_for_report(line)
            system.record_setup_note(f'  {sanitized_line}')
        remote_config_path = '/tmp/exasol_c4.conf'
        escaped_config = config_content.replace('\\', '\\\\').replace('$', '\\$').replace('`', '\\`').replace('"', '\\"')
        create_config_cmd = f'echo "{escaped_config}" | tee {remote_config_path} > /dev/null'
        result = system.execute_command(create_config_cmd, description='Create c4 configuration file on remote system', category='configuration')
        if not result['success']:
            self._log(f"Failed to create config file on remote system: {result.get('stderr', 'Unknown error')}")
            return None
        return remote_config_path

    def _deploy_cluster(self, remote_config_path: str) -> bool:
        """Deploy Exasol cluster using c4.

        Args:
            remote_config_path: Path to c4 config file

        Returns:
            True if successful
        """
        system = self._system
        result = system.execute_command(f'./c4 host play -i {remote_config_path}', timeout=1800, description='Deploy Exasol cluster using c4', category='cluster_deployment')
        if not result['success']:
            self._log(f"C4 cluster deployment failed: {result['stderr']}")
            return False
        system.record_setup_note('Exasol cluster deployment initiated')
        return True

    def _update_connection_params(self, host_addrs: str, host_external_addrs: str, db_password: str) -> None:
        """Update connection parameters for deployed cluster."""
        system = self._system
        if host_external_addrs and host_external_addrs != 'localhost':
            external_host = host_external_addrs.split()[0]
        else:
            external_host = host_addrs.split()[0]
        if system._cloud_instance_manager:
            system._external_host = external_host
            system.host = 'localhost'
        else:
            system.host = external_host
        system.username = 'sys'
        system.password = db_password
        system.port = 8563
        system.record_setup_note(f'Database will be accessible at: {system.host}:{system.port}')
        system.record_setup_note('Admin UI will be available (if enabled)')

    def _post_deployment_config(self, remote_license_path: str | None, db_redundancy: int | None=None) -> bool:
        """Perform post-deployment configuration.

        Args:
            remote_license_path: Path to license file if specified
            db_redundancy: Desired redundancy level (1=no redundancy)

        Returns:
            True if successful
        """
        system = self._system
        play_id = system._get_cluster_play_id()
        if not play_id:
            self._log('Could not get cluster play ID')
            return False
        self._log(f'Got play ID {play_id}')
        self._log('Cleaning up interfering services...')
        cleanup_success = system._cleanup_disturbing_services(play_id)
        if cleanup_success:
            self._log('✓ Service cleanup completed successfully')
        else:
            self._log('⚠ Service cleanup failed or no services to remove')
        if remote_license_path:
            self._log('Installing license file...')
            system._install_license_file(play_id, remote_license_path)
            self._log('✓ License file installation completed')
        if db_redundancy is not None:
            self._configure_volume_redundancy(play_id, db_redundancy)
        extra_config = system.setup_config.get('extra', {})
        db_params = extra_config.get('db_params', [])
        if db_params:
            self._log(f'Configuring database parameters ({len(db_params)} parameters)...')
            if not system._configure_database_parameters(play_id, db_params):
                self._log('✗ Database parameter configuration failed - installation incomplete')
                return False
            self._log('✓ Database parameter configuration completed')
        if extra_config:
            system.record_setup_note('Additional configuration parameters applied:')
            for (key, value) in extra_config.items():
                if key != 'db_params':
                    system.record_setup_note(f'  {key}: {value}')
        return True

    def _configure_volume_redundancy(self, play_id: str, target_redundancy: int) -> None:
        """Configure data volume redundancy level via ConfD.

        Uses st_volume_decrease_redundancy to reduce redundancy from the
        default (typically 2 for multinode) to the target level.

        Args:
            play_id: The cluster play ID
            target_redundancy: Desired redundancy level (1=no redundancy)
        """
        system = self._system
        node_count = len(system._cloud_instance_managers) if system._cloud_instance_managers else 1
        if node_count <= 1 and target_redundancy == 1:
            self._log('Single-node cluster already has redundancy 1, skipping')
            return
        default_redundancy = min(2, node_count)
        delta = default_redundancy - target_redundancy
        if delta <= 0:
            self._log(f'Volume redundancy already at or below target ({target_redundancy}), skipping')
            return
        self._log(f'Decreasing volume redundancy from {default_redundancy} to {target_redundancy} (delta={delta})...')
        stop_cmd = 'confd_client db_stop db_name: Exasol'
        system._execute_confd_client_command(play_id, stop_cmd, 'Stop database for redundancy change', 'redundancy')
        import time
        time.sleep(5)
        decrease_cmd = f'confd_client st_volume_decrease_redundancy vname: DataVolume1 delta: {delta}'
        result = system._execute_confd_client_command(play_id, decrease_cmd, f'Decrease volume redundancy to {target_redundancy}', 'redundancy')
        if result:
            self._log(f'✓ Volume redundancy set to {target_redundancy}')
        else:
            self._log('⚠ Failed to decrease volume redundancy (may already be at target level)')
        start_cmd = 'confd_client db_start db_name: Exasol'
        system._execute_confd_client_command(play_id, start_cmd, 'Restart database after redundancy change', 'redundancy')
        self._log('Waiting for database to be ready after redundancy change...')
        if system.wait_for_health(max_attempts=60, delay=5.0):
            self._log('✓ Database ready after redundancy change')
        else:
            self._log('⚠ Database not ready after redundancy change, continuing anyway')