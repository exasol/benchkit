from __future__ import annotations

"""ClickHouse database system implementation."""
from collections.abc import Callable, Iterable
from datetime import timedelta
from pathlib import Path
from typing import Any
try:
    import clickhouse_connect
except ModuleNotFoundError:
    pass
from benchkit.common import DataFormat
from ..util import Timer
from .base import SystemUnderTest, TableOperation

class ClickHouseSystem(SystemUnderTest):
    """ClickHouse database system implementation."""
    SUPPORTS_MULTINODE = True
    LOAD_TIMEOUT_MULTIPLIER = 1.0

    @classmethod
    def get_python_dependencies(cls) -> list[str]:
        """Return Python packages required by ClickHouse system."""
        return ['clickhouse-connect>=0.6.0']

    def get_storage_config(self) -> tuple[str | None, str]:
        """Return ClickHouse-specific storage configuration.

        ClickHouse uses /data/clickhouse subdirectory with clickhouse user ownership.
        """
        return ('/data/clickhouse', 'clickhouse:clickhouse')

    @classmethod
    def _get_connection_defaults(cls) -> dict[str, Any]:
        return {'port': 8123, 'username': 'default', 'password': '', 'schema_key': 'database', 'schema': 'benchmark'}

    @classmethod
    def _extend_connection_info(cls, conn_info: dict[str, Any], setup_config: dict[str, Any]) -> None:
        if 'extra' in setup_config:
            conn_info['extra'] = setup_config['extra']

    @classmethod
    def get_required_ports(cls) -> dict[str, int]:
        """Return ports required by ClickHouse system."""
        return {'ClickHouse HTTP': 8123, 'ClickHouse Native': 9000, 'ClickHouse MySQL': 9004, 'ClickHouse PostgreSQL': 9005}

    def __init__(self, config: dict[str, Any], output_callback: Callable[[str], None] | None=None, workload_config: dict[str, Any] | None=None):
        super().__init__(config, output_callback, workload_config)
        self.setup_method = self.setup_config.get('method', 'docker')
        project_id = config.get('project_id', '')
        if project_id:
            self.container_name = f'clickhouse_{project_id}_{self.name}'
        else:
            self.container_name = f'clickhouse_{self.name}'
        self.config_profile = (self.setup_config.get('extra') or {}).get('config_profile', 'default')
        self.http_port = 8123
        self.native_port = 9000
        raw_host = self.setup_config.get('host', 'localhost')
        resolved_host = self._resolve_ip_addresses(raw_host)
        if ',' in resolved_host:
            self.host = resolved_host.split(',')[0].strip()
        else:
            self.host = resolved_host
        self.port = self.setup_config.get('port', 8123)
        self.username = self.setup_config.get('username', 'default')
        self.password = self.setup_config.get('password', '')
        self.database = self.setup_config.get('database', 'benchmark')
        self._client = None
        self.cluster_name = 'benchmark_cluster'

    def _get_client(self) -> Any:
        """Get a client connection to ClickHouse database using clickhouse-connect."""
        if clickhouse_connect is None:
            return None
        return clickhouse_connect.get_client(host=self.host, port=self.port, username=self.username, password=self.password, database=self.database, interface='http', secure=False)

    def _should_execute_remotely(self) -> bool:
        """ClickHouse only executes remotely for native installations."""
        return self._cloud_instance_manager is not None and self.setup_method == 'native'

    def is_healthy(self, quiet: bool=False) -> bool:
        """Check if ClickHouse is running and accepting connections."""
        try:
            health_check_host = self._get_health_check_host()
            if clickhouse_connect is None:
                self._log('Warning: clickhouse-connect not available, falling back to curl/client')
                if self.setup_method == 'docker':
                    result = self.execute_command(f'curl -s http://localhost:{self.http_port}/ --max-time 5', timeout=10.0)
                    return bool(result.get('success', False)) and 'Ok.' in result['stdout']
                else:
                    password_arg = f'--password={self.password} ' if self.password else ''
                    result = self.execute_command(f"clickhouse-client --user={self.username} {password_arg}--query 'SELECT 1' --format TSV", timeout=10.0)
                    return bool(result.get('success', False)) and '1' in result['stdout']
            client = clickhouse_connect.get_client(host=health_check_host, port=self.port, username=self.username, password=self.password, database='default', interface='http', secure=False)
            result = client.query('SELECT 1')
            client.close()
            return True
        except Exception as e:
            if not quiet:
                import traceback
                self._log(f'Health check failed: {type(e).__name__}: {e}')
                self._log(f'Full traceback:\n{traceback.format_exc()}')
            return False

    def create_schema(self, schema_name: str) -> bool:
        """Create a database in ClickHouse.

        For multinode clusters, uses ON CLUSTER to create the database on all nodes.
        """
        original_database = self.database
        self.database = 'default'
        try:
            node_count = self.setup_config.get('node_count', 1) if self.setup_config else 1
            is_multinode = node_count > 1 or (self._cloud_instance_managers and len(self._cloud_instance_managers) > 1)
            if is_multinode:
                sql = f"CREATE DATABASE IF NOT EXISTS {schema_name} ON CLUSTER '{self.cluster_name}'"
                self._log(f"Creating database '{schema_name}' on all cluster nodes...")
            else:
                sql = f'CREATE DATABASE IF NOT EXISTS {schema_name}'
            result = self.execute_query(sql, query_name=f'create_database_{schema_name}')
            success = bool(result.get('success', False))
            if success:
                self.database = schema_name
                self._log(f'✓ Using database: {schema_name}')
            else:
                error = result.get('error', 'Unknown error')
                self._log(f"✗ Failed to create database '{schema_name}': {error}")
        except Exception as e:
            self.database = original_database
            self._log(f"✗ Failed to create database '{schema_name}': {e}")
            return False
        return success

    def load_data(self, table_name: str, data_path: Path, **kwargs: Any) -> bool:
        """Load data into ClickHouse table using native clickhouse-client for optimal performance."""
        schema_name = kwargs.get('schema', 'default')
        data_format = kwargs.get('format', 'tbl')
        try:
            self._log(f'Loading {data_path} into {table_name} (format: {data_format})...')
            password_arg = f'--password={self.password} ' if self.password else ''
            client_args = f'clickhouse-client --user={self.username} {password_arg}'
            if data_format == 'tsv':
                import_cmd = f'cat {data_path} | {client_args}--query="INSERT INTO {schema_name}.{table_name} FORMAT TabSeparated"'
            elif data_format == 'parquet':
                import_cmd = f'cat {data_path} | {client_args}--query="INSERT INTO {schema_name}.{table_name} FORMAT Parquet"'
            else:
                import_cmd = f"""sed 's/|$//' {data_path} | {client_args}--query="INSERT INTO {schema_name}.{table_name} FORMAT CSV" --format_csv_delimiter='|'"""
            result = self.execute_command(import_cmd, timeout=self._get_data_loading_timeout(), record=False)
            if not result.get('success', False):
                self._log(f"Failed to load data: {result.get('stderr', 'Unknown error')}")
                return False
            if clickhouse_connect is None:
                count_cmd = f'{client_args}--query="SELECT COUNT(*) FROM {schema_name}.{table_name} FORMAT TSV"'
                count_result = self.execute_command(count_cmd, timeout=60.0, record=False)
                if count_result.get('success', False):
                    row_count = int(count_result.get('stdout', '0').strip())
                else:
                    self._log('Warning: Could not verify row count')
                    return True
            else:
                client = self._get_client()
                if client:
                    count_result = client.query(f'SELECT COUNT(*) FROM {schema_name}.{table_name}')
                    row_count = count_result.result_rows[0][0]
                else:
                    self._log('Warning: Could not verify row count')
                    return True
            self._log(f'Successfully loaded {row_count:,} rows into {table_name}')
            return True
        except Exception as e:
            self._log(f'Failed to load data into {table_name}: {e}')
            return False

    def load_data_from_iterable(self, table_name: str, data_source: Iterable[Any], data_format: DataFormat, **kwargs: Any) -> bool:
        raise NotImplementedError('clickhouse.load_data_from_iterable')

    def execute_query(self, query: str, query_name: str | None=None, return_data: bool=False, timeout: int | None=None) -> dict[str, Any]:
        """Execute a SQL query in ClickHouse using clickhouse-connect.

        Args:
            query: SQL query to execute
            query_name: Optional name for the query (for logging)
            return_data: If True, return query results as DataFrame
            timeout: Optional timeout in seconds (default: 300 for regular queries,
                    uses dynamic calculation for OPTIMIZE operations)
        """
        from ..debug import debug_print
        if not query_name:
            query_name = 'unnamed_query'
        query = query.rstrip().rstrip(';')
        if timeout is None:
            timeout = 300
        send_receive_timeout = timeout
        try:
            debug_print(f'Executing query: {query_name}')
            if len(query) > 200:
                debug_print(f'SQL: {query[:200]}...')
            else:
                debug_print(f'SQL: {query}')
            with Timer(f'Query {query_name}') as timer:
                if clickhouse_connect is None:
                    self._log('Warning: clickhouse-connect not available, falling back to client')
                    return self._execute_query_fallback(query, query_name, timer, return_data)
                database_to_use = getattr(self, '_active_schema', None) or self.database
                client = clickhouse_connect.get_client(host=self.host, port=self.port, username=self.username, password=self.password, database=database_to_use, interface='http', secure=False, send_receive_timeout=send_receive_timeout)
                try:
                    query_stripped = query.strip()
                    while query_stripped.startswith('--'):
                        newline_pos = query_stripped.find('\n')
                        if newline_pos == -1:
                            query_stripped = ''
                            break
                        query_stripped = query_stripped[newline_pos + 1:].strip()
                    if query_stripped.upper().startswith(('SELECT', 'WITH', 'SHOW', 'DESCRIBE')):
                        result = client.query(query)
                        rows_returned = result.row_count if hasattr(result, 'row_count') else len(result.result_rows)
                        if return_data:
                            import pandas as pd
                            df = pd.DataFrame(result.result_rows, columns=result.column_names)
                        else:
                            df = None
                    else:
                        client.command(query)
                        rows_returned = 0
                        df = None
                    response: dict[str, Any] = {'success': True, 'elapsed_s': timer.elapsed, 'rows_returned': rows_returned, 'query_name': query_name, 'error': None}
                    if return_data and df is not None:
                        response['data'] = df
                    return response
                finally:
                    client.close()
        except Exception as e:
            return {'success': False, 'elapsed_s': timer.elapsed if 'timer' in locals() else 0, 'rows_returned': 0, 'query_name': query_name, 'error': str(e)}

    def _execute_query_fallback(self, query: str, query_name: str, timer: Any, return_data: bool=False) -> dict[str, Any]:
        """Fallback query execution using clickhouse-client when clickhouse-connect is not available."""
        if return_data:
            self._log('Warning: return_data not supported in fallback mode, data will not be returned')
        try:
            password_arg = f'--password={self.password} ' if self.password else ''
            if self.setup_method == 'docker':
                cmd = f"docker exec {self.container_name} clickhouse-client --user={self.username} {password_arg}--database={self.database} --query='{query}' --format=TabSeparated"
            else:
                cmd = f"clickhouse-client --user={self.username} {password_arg}--database={self.database} --query='{query}' --format=TabSeparated"
            result = self.execute_command(cmd, timeout=self._get_query_execution_timeout())
            if result['success']:
                rows_returned = self._count_result_rows(result['stdout'])
                return {'success': True, 'elapsed_s': timer.elapsed, 'rows_returned': rows_returned, 'query_name': query_name, 'error': None}
            else:
                return {'success': False, 'elapsed_s': timer.elapsed, 'rows_returned': 0, 'query_name': query_name, 'error': result['stderr']}
        except Exception as e:
            return {'success': False, 'elapsed_s': timer.elapsed, 'rows_returned': 0, 'query_name': query_name, 'error': str(e)}

    def _count_result_rows(self, output: str) -> int:
        """Count number of rows in query result."""
        if not output.strip():
            return 0
        return len([line for line in output.strip().split('\n') if line.strip()])

    def get_system_metrics(self) -> dict[str, Any]:
        """Get ClickHouse-specific performance metrics using clickhouse-connect."""
        metrics: dict[str, Any] = {}
        try:
            if clickhouse_connect is None:
                metrics['warning'] = 'clickhouse-connect not available, limited metrics'
                return metrics
            system_queries = {'query_count': 'SELECT count() FROM system.processes', 'memory_usage': 'SELECT formatReadableSize(sum(memory_usage)) FROM system.processes', 'disk_usage': 'SELECT formatReadableSize(sum(bytes_on_disk)) FROM system.parts', 'cache_stats': "SELECT * FROM system.events WHERE event LIKE '%Cache%'"}
            for (metric_name, query) in system_queries.items():
                result = self.execute_query(query, query_name=f'metrics_{metric_name}')
                if result['success']:
                    metrics[metric_name] = {'query_time': result['elapsed_s'], 'rows': result['rows_returned']}
        except Exception as e:
            metrics['error'] = str(e)
        return metrics

    def get_table_sizes(self, schema: str, table_names: list[str]) -> dict[str, dict[str, Any]]:
        """Query ClickHouse for table storage sizes.

        Uses system.parts table to get:
        - data_compressed_bytes: Actual storage size (compressed)
        - data_uncompressed_bytes: Logical/uncompressed size

        Args:
            schema: Database name containing the tables
            table_names: List of table names to query

        Returns:
            Dict mapping table names to size info with raw_bytes, stored_bytes,
            row_count, and compression_ratio.
        """
        sizes: dict[str, dict[str, Any]] = {}
        try:
            tables_str = ', '.join((f"'{t}'" for t in table_names))
            query = f"\n                SELECT\n                    table,\n                    sum(data_compressed_bytes) AS stored_bytes,\n                    sum(data_uncompressed_bytes) AS raw_bytes,\n                    sum(rows) AS row_count\n                FROM system.parts\n                WHERE database = '{schema}'\n                  AND table IN ({tables_str})\n                  AND active = 1\n                GROUP BY table\n            "
            result = self.execute_query(query, query_name='get_table_sizes', return_data=True)
            if result.get('success') and 'data' in result:
                df = result['data']
                for (_, row) in df.iterrows():
                    table_name = str(row['table']).lower()
                    raw_bytes = int(row['raw_bytes']) if row['raw_bytes'] else 0
                    stored_bytes = int(row['stored_bytes']) if row['stored_bytes'] else 0
                    row_count = int(row['row_count']) if row['row_count'] else 0
                    sizes[table_name] = {'raw_bytes': raw_bytes, 'stored_bytes': stored_bytes, 'row_count': row_count, 'compression_ratio': raw_bytes / stored_bytes if stored_bytes > 0 else 0.0}
        except Exception as e:
            self._log(f'Warning: Failed to get table sizes: {e}')
        return sizes

    def teardown(self) -> bool:
        """Clean up ClickHouse installation."""
        success = True
        if self.setup_method == 'docker':
            stop_result = self.execute_command(f'docker stop {self.container_name} || true')
            remove_result = self.execute_command(f'docker rm {self.container_name} || true')
            success = stop_result['success'] and remove_result['success']
        elif self.setup_config.get('stop_service_on_teardown', False):
            self.execute_command('sudo systemctl stop clickhouse-server')
        if self.setup_config.get('cleanup_data', False):
            success = success and self.cleanup_data_directory()
        return success

    def estimate_execution_time(self, operation: TableOperation, data_size_gb: float) -> timedelta:
        estimate: timedelta
        if operation == 'OPTIMIZE TABLE':
            estimate = timedelta(minutes=data_size_gb / self.node_count)
            return max(timedelta(minutes=5), min(timedelta(hours=2), estimate))
        elif operation == 'MATERIALIZE STATISTICS':
            estimate = timedelta(minutes=0.5 * data_size_gb / self.node_count)
            return max(timedelta(minutes=5), min(timedelta(hours=1), estimate))
        return super().estimate_execution_time(operation, data_size_gb)