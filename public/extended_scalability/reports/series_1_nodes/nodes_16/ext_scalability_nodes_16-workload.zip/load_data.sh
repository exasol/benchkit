#!/bin/bash
# Data Loading script for ext_scalability_nodes_16
# This script loads data into pre-configured systems (Phase 2)
set -e

# Parse command line arguments
SYSTEM_NAME=""
DEBUG_FLAG=""

while [[ $# -gt 0 ]]; do
    case $1 in
        --debug)
            DEBUG_FLAG="--debug"
            shift
            ;;
        *)
            if [ -z "$SYSTEM_NAME" ]; then
                SYSTEM_NAME="$1"
            fi
            shift
            ;;
    esac
done

# Auto-detect system if not provided
if [ -z "$SYSTEM_NAME" ]; then
    # Auto-detect system based on what's running locally
    if systemctl is-active --quiet c4_cloud_command 2>/dev/null || pgrep -f "c4" >/dev/null 2>&1; then
        SYSTEM_NAME="exasol"
    elif systemctl is-active --quiet clickhouse-server 2>/dev/null || pgrep -f "clickhouse" >/dev/null 2>&1; then
        SYSTEM_NAME="clickhouse"
    else
        echo "Error: Could not auto-detect system. Please specify system name as parameter."
        echo "Usage: $0 [system_name] [--debug]"
        echo "Available systems: exasol, clickhouse, trino, starrocks"
        exit 1
    fi
fi

echo "=== Data Loading: ext_scalability_nodes_16 ==="
echo "Loading data for system: $SYSTEM_NAME"
echo ""

# Install dependencies if needed
if [ ! -d "venv" ]; then
    echo "Setting up Python virtual environment..."
    python3 -m venv venv
fi

source venv/bin/activate
pip install -q -r requirements.txt

echo ""
echo "Loading data for $SYSTEM_NAME..."

python -m benchkit load --config config.yaml --system "$SYSTEM_NAME" $DEBUG_FLAG

echo ""
echo "=== Data Loading Completed ==="
echo "Load completion marker saved in results/ext_scalability_nodes_16/"
